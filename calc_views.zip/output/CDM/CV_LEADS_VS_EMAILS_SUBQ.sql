CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_CV_LEADS_VS_EMAILS_SUBQ" AS
SELECT
  "INITIATIVE_ID",
  "CAMPAIGN_ID",
  "COUNTRY",
  "LEADS",
  "CONTACT_KEY"
FROM (
  SELECT
    "CONTACT_KEY",
    "INITIATIVE_ID",
    "CAMPAIGN_ID",
    "COUNTRY",
    "LEADS"
  FROM (
    SELECT
      input_0."CONTACT_KEY",
      input_1."INITIATIVE_ID",
      input_1."CAMPAIGN_ID",
      input_1."COUNTRY",
      'TOTAL_LEADS' AS "LEADS"
    FROM (
      SELECT
        "ZZ1_CAMPAIGN_ID_MIA",
        "IA_TYPE",
        "CONTACT_KEY"
      FROM "OW_SEDA_S".TABLEAU_INTERACTION
    ) AS input_0
    LEFT OUTER JOIN (
      SELECT
        "ZZ1_CAMPAIGN_ID_MIA" AS "CAMPAIGN_ID",
        "INITIATIVE_ID",
        "COUNTRY"
      FROM "OW_SEDA_S".TABLEAU_CI
    ) AS input_1
      ON input_0."ZZ1_CAMPAIGN_ID_MIA" = input_1."CAMPAIGN_ID"
  ) AS Join_1
  UNION ALL
  SELECT
    "CONTACT_KEY",
    "INITIATIVE_ID",
    "CAMPAIGN_ID",
    "COUNTRY",
    "LEADS"
  FROM (
    SELECT
      input_0."INITIATIVE_ID",
      input_0."CAMPAIGN_ID",
      input_0."COUNTRY",
      input_0."CONTACT_KEY",
      'WITH_BROADLOG_LEADS' AS "LEADS"
    FROM (
      SELECT
        input_0."CONTACT_KEY",
        input_1."INITIATIVE_ID",
        input_1."CAMPAIGN_ID",
        input_1."COUNTRY",
        'TOTAL_LEADS' AS "LEADS"
      FROM (
        SELECT
          "ZZ1_CAMPAIGN_ID_MIA",
          "IA_TYPE",
          "CONTACT_KEY"
        FROM "OW_SEDA_S".TABLEAU_INTERACTION
      ) AS input_0
      LEFT OUTER JOIN (
        SELECT
          "ZZ1_CAMPAIGN_ID_MIA" AS "CAMPAIGN_ID",
          "INITIATIVE_ID",
          "COUNTRY"
        FROM "OW_SEDA_S".TABLEAU_CI
      ) AS input_1
        ON input_0."ZZ1_CAMPAIGN_ID_MIA" = input_1."CAMPAIGN_ID"
    ) AS input_0
    INNER JOIN (
      SELECT
        "CONTACT_KEY",
        "DELIVERED_COUNT"
      FROM "OW_SEDA_S".TABLEAU_SAM_RECIPIENT
    ) AS input_1
      ON input_0."CONTACT_KEY" = input_1."CONTACT_KEY"
  ) AS Join_2
) AS Union_1
GROUP BY
  "INITIATIVE_ID",
  "CAMPAIGN_ID",
  "COUNTRY",
  "LEADS",
  "CONTACT_KEY"