CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_CV_DELIVERIES_RESULT" AS
SELECT
  "DELIVERY_NAME",
  "CAMPAIGN_NAME",
  "CHANNEL",
  "STATUS",
  "ERRORS",
  "OPT_OUT",
  "PERSONS_CLICKED",
  "PROCESSED",
  "NUMBER_DISTINCT_CLICKS",
  "RECIPIENTS_OPENED",
  "SENT",
  "SUCCESS",
  "CONTACT_DATE",
  "NEW_QUARANTINES",
  "SUB",
  "COUNTRY" AS "COUNTRY_CODE",
  "COUNTRY_NAME"
FROM (
  SELECT
    input_0."DELIVERY_NAME",
    input_0."CAMPAIGN_NAME",
    input_0."CHANNEL",
    input_0."STATUS",
    input_0."ERRORS",
    input_0."OPT_OUT",
    input_0."PERSONS_CLICKED",
    input_0."PROCESSED",
    input_0."NUMBER_DISTINCT_CLICKS",
    input_0."RECIPIENTS_OPENED",
    input_0."SENT",
    input_0."SUCCESS",
    input_0."CONTACT_DATE",
    input_0."NEW_QUARANTINES",
    input_0."COUNTRY_NAME",
    input_1."SUB",
    input_1."COUNTRY"
  FROM (
    SELECT
      input_0."DELIVERY_NAME",
      input_0."CHANNEL",
      input_0."STATUS",
      input_0."ERRORS",
      input_0."OPT_OUT",
      input_0."PERSONS_CLICKED",
      input_0."PROCESSED",
      input_0."NUMBER_DISTINCT_CLICKS",
      input_0."RECIPIENTS_OPENED",
      input_0."SENT",
      input_0."SUCCESS",
      input_0."CONTACT_DATE",
      input_0."NEW_QUARANTINES",
      input_0."COUNTRY_NAME",
      input_1."CAMPAIGN_NAME"
    FROM (
      SELECT
        "CAMPAIGN_ID",
        "LABEL" AS "DELIVERY_NAME",
        "CHANNEL",
        "STATUS",
        "ERRORS",
        "OPT_OUT",
        "PERSONS_CLICKED",
        "PROCESSED",
        "NUMBER_DISTINCT_CLICKS",
        "RECIPIENTS_OPENED",
        "SENT",
        "SUCCESS",
        "CONTACT_DATE",
        "NEW_QUARANTINES",
        "COUNTRY_CODE" AS "COUNTRY_NAME"
      FROM "OW_SEDA_S".TABLEAU_DELIVERIES
    ) AS input_0
    INNER JOIN (
      SELECT
        "PRIMARY_KEY",
        "LABEL" AS "CAMPAIGN_NAME"
      FROM "OW_SEDA_S".TABLEAU_OPERATION
    ) AS input_1
      ON input_0."CAMPAIGN_ID" = input_1."PRIMARY_KEY"
  ) AS input_0
  INNER JOIN (
    SELECT
      "COUNTRY",
      "SUB",
      "COUNTRY_NAME"
    FROM "OW_SEDA_S".TABLEAU_COUNTRY_SUB
  ) AS input_1
    ON input_0."COUNTRY_NAME" = input_1."COUNTRY_NAME"
) AS Join_2