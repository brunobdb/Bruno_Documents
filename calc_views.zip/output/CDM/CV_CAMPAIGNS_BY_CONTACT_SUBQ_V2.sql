CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_CV_CAMPAIGNS_BY_CONTACT_SUBQ_V2" AS
SELECT
  "COUNTRY_CODE" AS "COUNTRY",
  "LABEL",
  "CONTACT_KEY",
  "INTERACTION_NUMBER"
FROM (
  SELECT
    input_0."COUNTRY_CODE",
    input_0."LABEL",
    input_0."CONTACT_KEY" AS "INTERACTION_NUMBER",
    "INTERACTION_NUMBER" AS "CONTACT_KEY"
  FROM (
    SELECT
      input_0."CONTACT_KEY",
      input_0."COUNTRY_CODE",
      input_1."LABEL"
    FROM (
      SELECT
        input_0."CAMPAIGN_ID",
        input_0."COUNTRY_CODE",
        input_1."CONTACT_KEY"
      FROM (
        SELECT
          "PRIMARY_KEY",
          "COUNTRY_CODE",
          "CAMPAIGN_ID"
        FROM "OW_SEDA_S".TABLEAU_DELIVERIES
      ) AS input_0
      INNER JOIN (
        SELECT
          "DELIVERY_ID",
          "CONTACT_KEY"
        FROM "OW_SEDA_S".TABLEAU_BROADLOG_RCP
      ) AS input_1
        ON input_0."PRIMARY_KEY" = input_1."DELIVERY_ID"
    ) AS input_0
    INNER JOIN (
      SELECT
        "PRIMARY_KEY",
        "LABEL"
      FROM "OW_SEDA_S".TABLEAU_OPERATION
    ) AS input_1
      ON input_0."CAMPAIGN_ID" = input_1."PRIMARY_KEY"
  ) AS input_0
  INNER JOIN (
    SELECT
      "CONTACT_KEY"
    FROM "OW_SEDA_S".TABLEAU_TRACKING_LOG_RCP
  ) AS input_1
    ON input_0."CONTACT_KEY" = input_1."CONTACT_KEY"
) AS Join_3
GROUP BY
  "COUNTRY_CODE",
  "LABEL",
  "CONTACT_KEY",
  "INTERACTION_NUMBER"