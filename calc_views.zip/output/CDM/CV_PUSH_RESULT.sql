CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_CV_PUSH_RESULT" AS
SELECT
  "CONTACT_DATE",
  "COUNTRY_CODE",
  "SUB",
  "COUNTRY_NAME",
  "DELIVERY_NAME",
  "CAMPAIGN_NAME",
  "ACTION",
  "STATUS",
  "AMOUNT"
FROM (
  SELECT
    input_0."COUNTRY_CODE" AS "COUNTRY_NAME",
    input_0."CONTACT_DATE",
    input_0."DELIVERY_NAME",
    input_0."CAMPAIGN_NAME",
    input_0."ACTION",
    input_0."STATUS",
    input_1."SUB",
    input_1."COUNTRY" AS "COUNTRY_CODE",
    'X' AS "AMOUNT"
  FROM (
    SELECT
      input_0."COUNTRY_CODE",
      input_0."CONTACT_DATE",
      input_0."DELIVERY_NAME",
      input_0."CAMPAIGN_NAME",
      input_1."STATUS",
      input_1."ACTION"
    FROM (
      SELECT
        input_0."COUNTRY_CODE",
        input_0."CONTACT_DATE",
        input_0."DELIVERY_NAME",
        input_0."PRIMARY_KEY",
        input_1."CAMPAIGN_NAME"
      FROM (
        SELECT
          "CONTACT_DATE",
          "COUNTRY_CODE",
          "CAMPAIGN_ID",
          "CHANNEL",
          "LABEL" AS "DELIVERY_NAME",
          "PRIMARY_KEY"
        FROM "OW_SEDA_S".TABLEAU_DELIVERIES
      ) AS input_0
      INNER JOIN (
        SELECT
          "PRIMARY_KEY",
          "LABEL" AS "CAMPAIGN_NAME"
        FROM "OW_SEDA_S".TABLEAU_OPERATION
      ) AS input_1
        ON input_0."CAMPAIGN_ID" = input_1."PRIMARY_KEY"
    ) AS input_0
    INNER JOIN (
      SELECT
        "ACTION",
        "STATUS",
        "DELIVERY_ID"
      FROM "OW_SEDA_S".TABLEAU_PPMT_RESPONSE
    ) AS input_1
      ON input_0."PRIMARY_KEY" = input_1."DELIVERY_ID"
  ) AS input_0
  INNER JOIN (
    SELECT
      "COUNTRY",
      "SUB",
      "COUNTRY_NAME"
    FROM "OW_SEDA_S".TABLEAU_COUNTRY_SUB
  ) AS input_1
    ON input_0."COUNTRY_CODE" = input_1."COUNTRY_NAME"
) AS Join_3
GROUP BY
  "CONTACT_DATE",
  "COUNTRY_CODE",
  "SUB",
  "COUNTRY_NAME",
  "DELIVERY_NAME",
  "CAMPAIGN_NAME",
  "ACTION",
  "STATUS",
  "AMOUNT"