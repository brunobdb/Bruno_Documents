CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_CV_PROD_RET" AS
SELECT
  "COUNTRY" AS "COUNTRY_CODE",
  "SUB",
  "COUNTRY_NAME",
  "COUNT_DISC",
  "REGDATE",
  "CAT2_NM",
  "MKT_NM",
  "ACCOUNT",
  "ASAP_REGION",
  "CONTACT_KEY"
FROM (
  SELECT
    input_0."COUNT_DISC",
    input_0."CONTACT_KEY",
    input_0."REGDATE",
    input_0."CAT2_NM",
    input_0."MKT_NM",
    input_0."ACCOUNT",
    input_0."ASAP_REGION",
    input_1."COUNTRY",
    input_1."SUB",
    input_1."COUNTRY_NAME"
  FROM (
    SELECT
      input_0."ASAP_REGION",
      input_0."ACCOUNT",
      input_0."COUNTRY",
      input_0."REGDATE",
      input_0."CONTACT_KEY",
      input_0."COUNT_DISC",
      input_1."MKT_NM",
      input_1."CAT2_NM"
    FROM (
      SELECT
        input_0."OBJECT_ID",
        input_0."ASAP_REGION",
        input_0."ACCOUNT",
        input_0."REGDATE",
        input_1."COUNTRY",
        input_1."CONTACT_KEY",
        input_1."COUNT_DISC"
      FROM (
        SELECT
          "CONTACT_KEY",
          "OBJECT_ID",
          "ASAP_REGION",
          "ACCOUNT",
          "ZZ1_FST_REG_DT_MIA",
          SUBSTR(CAST("ZZ1_FST_REG_DT_MIA" AS VARCHAR), 1, 6) AS "REGDATE"
        FROM "OW_SEDA_S".TABLEAU_INTERACTION
      ) AS input_0
      INNER JOIN (
        SELECT
          "CONTACT_KEY",
          "COUNTRY",
          "CONTACT_KEY" AS "COUNT_DISC"
        FROM "OW_SEDA_S".TABLEAU_CONTACT_INFO
      ) AS input_1
        ON input_0."CONTACT_KEY" = input_1."CONTACT_KEY"
    ) AS input_0
    LEFT OUTER JOIN (
      SELECT
        "ITEM_SKU",
        "MKT_NM",
        "CAT2_NM"
      FROM "OW_SEDA_S".TABLEAU_PRODUCT_MASTER
    ) AS input_1
      ON input_0."OBJECT_ID" = input_1."ITEM_SKU"
  ) AS input_0
  INNER JOIN (
    SELECT
      "COUNTRY",
      "SUB",
      "COUNTRY_NAME"
    FROM "OW_SEDA_S".TABLEAU_COUNTRY_SUB
  ) AS input_1
    ON input_0."COUNTRY" = input_1."COUNTRY"
) AS Join_3
GROUP BY
  "COUNTRY",
  "SUB",
  "COUNTRY_NAME",
  "COUNT_DISC",
  "REGDATE",
  "CAT2_NM",
  "MKT_NM",
  "ACCOUNT",
  "ASAP_REGION",
  "CONTACT_KEY"