-- Migrated from HANA Calculation View: OW_SEDA_S.VIEWCV_CV_CK_NO_INTERACTION
-- Description: CV_CK_NO_INTERACTION

CREATE OR REPLACE PROCEDURE OW_SEDA_S.load_VIEWCV_CV_CK_NO_INTERACTION()
LANGUAGE PLvSQL AS $$
BEGIN

  -- Layer 0: 22 nodes

  -- Node: Join_1
  PERFORM DROP TABLE IF EXISTS "layer_0_Join_1" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Join_1" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."CONTACT_KEY",
    input_0."TYPE_COUNT",
    input_1."COUNTRY"
  FROM (
    SELECT
      "CONTACT_KEY",
      "DELIVERED_COUNT",
      "OPENED_COUNT",
      CASE
        WHEN "DELIVERED_COUNT" = '0'
        THEN 'DO NOT RECEIVE'
        ELSE CASE WHEN "OPENED_COUNT" = '0' THEN 'WITHOUT INTERACTION' ELSE 'OUTRO' END
      END AS "TYPE_COUNT"
    FROM "OW_SEDA_S".TABLEAU_SAM_RECIPIENT
  ) AS input_0
  INNER JOIN (
    SELECT
      "CONTACT_KEY",
      "COUNTRY"
    FROM "OW_SEDA_S".TABLEAU_CONTACT_INFO
  ) AS input_1
    ON input_0."CONTACT_KEY" = input_1."CONTACT_KEY"
  )
     ORDER BY "CONTACT_KEY"
    SEGMENTED BY HASH("CONTACT_KEY") ALL NODES
  ;

  -- Node: Aggregation_1
  PERFORM DROP TABLE IF EXISTS "layer_0_Aggregation_1" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Aggregation_1" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    "CONTACT_KEY",
    "REG_DATE"
  FROM (
    SELECT
      "CONTACT_KEY",
      "REG_DATE"
    FROM "OW_SEDA_S".TABLEAU_ORIGIN
  ) AS Projection_3
  GROUP BY
    "CONTACT_KEY",
    "REG_DATE"
  )
     ORDER BY "CONTACT_KEY", "REG_DATE"
    SEGMENTED BY HASH("CONTACT_KEY") ALL NODES
  ;

  -- Node: Join_2
  PERFORM DROP TABLE IF EXISTS "layer_0_Join_2" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Join_2" ON COMMIT PRESERVE ROWS AS 
  SELECT
    input_0."CONTACT_KEY",
    input_0."TYPE_COUNT",
    input_0."COUNTRY",
    input_1."REG_DATE"
  FROM "layer_0_Join_1" AS input_0
  INNER JOIN "layer_0_Aggregation_1" AS input_1
    ON input_0."CONTACT_KEY" = input_1."CONTACT_KEY"
  ;

  -- Node: Union_1
  PERFORM DROP TABLE IF EXISTS "layer_0_Union_1" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Union_1" ON COMMIT PRESERVE ROWS AS 
  SELECT
    "CONTACT_KEY",
    "COUNTRY",
    "TYPE_COUNT",
    "REG_DATE"
  FROM (
    SELECT
      "CONTACT_KEY",
      "COUNTRY",
      "REG_DATE",
      'TOTAL CONTACT' AS "TYPE_COUNT"
    FROM "layer_0_Join_2"
  ) AS Projection_5
  UNION ALL
  SELECT
    "CONTACT_KEY",
    "COUNTRY",
    "TYPE_COUNT",
    "REG_DATE"
  FROM (
    SELECT
      "CONTACT_KEY",
      "TYPE_COUNT",
      "COUNTRY",
      "REG_DATE"
    FROM "layer_0_Join_2"
  ) AS Projection_4
  ;

  -- Node: Aggregation
  PERFORM DROP TABLE IF EXISTS "layer_0_Aggregation" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Aggregation" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    "COUNTRY",
    "TYPE_COUNT",
    "REG_DATE",
    "AMOUNT"
  FROM (
    SELECT
      "CONTACT_KEY",
      "COUNTRY",
      "TYPE_COUNT",
      "REG_DATE" AS "REG_DATE_ORIG",
      "TYPE_COUNT" AS "AMOUNT",
      LEFT(REPLACE(CAST("REG_DATE_ORIG" AS VARCHAR), '.', ''), 6) AS "REG_DATE"
    FROM "layer_0_Union_1"
  ) AS Projection_6
  GROUP BY
    "COUNTRY",
    "TYPE_COUNT",
    "REG_DATE",
    "AMOUNT"
  )
     ORDER BY "COUNTRY", "TYPE_COUNT", "REG_DATE", "AMOUNT"
    SEGMENTED BY HASH("COUNTRY", "TYPE_COUNT", "REG_DATE", "AMOUNT") ALL NODES
  ;

  -- Materialize final result
  PERFORM CREATE TABLE IF NOT EXISTS OW_SEDA_S.VIEWCV_CV_CK_NO_INTERACTION AS
    SELECT * FROM "layer_0_Aggregation" WHERE 1=0;
  PERFORM TRUNCATE TABLE OW_SEDA_S.VIEWCV_CV_CK_NO_INTERACTION;
  PERFORM INSERT INTO OW_SEDA_S.VIEWCV_CV_CK_NO_INTERACTION
  SELECT * FROM "layer_0_Aggregation";

  PERFORM COMMIT;
  RAISE NOTICE 'Successfully loaded OW_SEDA_S.VIEWCV_CV_CK_NO_INTERACTION';

END;
$$;