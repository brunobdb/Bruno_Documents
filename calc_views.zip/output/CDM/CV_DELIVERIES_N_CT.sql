CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_CV_DELIVERIES_N_CT" AS
SELECT
  "COUNTRY_NAME",
  "SUB",
  "COUNTRY" AS "COUNTRY_CODE",
  "CAMPAIGN_NAME",
  "DELIVERY_NAME",
  "PRIMARY_KEY" AS "DELIVERY_ID",
  "AMOUNT"
FROM (
  SELECT
    input_0."DELIVERY_NAME",
    input_0."COUNTRY_NAME",
    input_0."AMOUNT",
    input_0."CAMPAIGN_NAME",
    input_0."PRIMARY_KEY",
    input_1."SUB",
    input_1."COUNTRY"
  FROM (
    SELECT
      input_0."DELIVERY_NAME",
      input_0."COUNTRY_NAME",
      input_0."AMOUNT",
      input_0."PRIMARY_KEY",
      input_1."CAMPAIGN_NAME"
    FROM (
      SELECT
        "LABEL" AS "DELIVERY_NAME",
        "CAMPAIGN_ID",
        "COUNTRY_CODE" AS "COUNTRY_NAME",
        "SENT" AS "AMOUNT",
        "PRIMARY_KEY"
      FROM "OW_SEDA_S".TABLEAU_DELIVERIES
    ) AS input_0
    INNER JOIN (
      SELECT
        "LABEL" AS "CAMPAIGN_NAME",
        "PRIMARY_KEY"
      FROM "OW_SEDA_S".TABLEAU_OPERATION
    ) AS input_1
      ON input_0."CAMPAIGN_ID" = input_1."PRIMARY_KEY"
  ) AS input_0
  INNER JOIN (
    SELECT
      "COUNTRY",
      "SUB",
      "COUNTRY_NAME"
    FROM "OW_SEDA_S".TABLEAU_COUNTRY_SUB
  ) AS input_1
    ON input_0."COUNTRY_NAME" = input_1."COUNTRY_NAME"
) AS Join_2
GROUP BY
  "COUNTRY_NAME",
  "SUB",
  "COUNTRY",
  "CAMPAIGN_NAME",
  "DELIVERY_NAME",
  "PRIMARY_KEY",
  "AMOUNT"