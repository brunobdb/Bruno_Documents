CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_CV_ORIGIN_COUNT" AS
SELECT
  "SUB",
  "COUNTRY",
  "COUNTRY_NAME",
  "ID_ORIGIN",
  "COUNT"
FROM (
  SELECT
    input_0."ID_ORIGIN",
    input_1."COUNTRY_NAME",
    input_1."COUNTRY",
    input_1."SUB",
    'X' AS "COUNT"
  FROM (
    SELECT
      input_0."COUNTRY",
      input_1."ID_ORIGIN"
    FROM (
      SELECT
        "COUNTRY",
        "CONTACT_KEY"
      FROM "OW_SEDA_S".TABLEAU_CONTACT_INFO
    ) AS input_0
    INNER JOIN (
      SELECT
        "ID_ORIGIN",
        "CONTACT_KEY"
      FROM "OW_SEDA_S".TABLEAU_ORIGIN
    ) AS input_1
      ON input_0."CONTACT_KEY" = input_1."CONTACT_KEY"
  ) AS input_0
  INNER JOIN (
    SELECT
      "COUNTRY",
      "SUB",
      "COUNTRY_NAME"
    FROM "OW_SEDA_S".TABLEAU_COUNTRY_SUB
  ) AS input_1
    ON input_0."COUNTRY" = input_1."COUNTRY"
) AS Join_2
GROUP BY
  "SUB",
  "COUNTRY",
  "COUNTRY_NAME",
  "ID_ORIGIN",
  "COUNT"