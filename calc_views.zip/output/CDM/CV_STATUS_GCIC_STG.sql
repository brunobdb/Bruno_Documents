CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_CV_STATUS_GCIC_STG" AS
SELECT
  "COUNTRY" AS "COUNTRY_CODE",
  "COUNTRY_NAME",
  "SUB",
  "CK",
  "IA_TYPE",
  "MKT_NM",
  "CAT1_NM",
  "CAT2_NM",
  "REGDATE",
  "TOTAL"
FROM (
  SELECT
    input_0."TOTAL",
    input_0."CK",
    input_0."IA_TYPE",
    input_0."MKT_NM",
    input_0."CAT1_NM",
    input_0."CAT2_NM",
    input_0."REGDATE",
    input_1."COUNTRY",
    input_1."COUNTRY_NAME",
    input_1."SUB"
  FROM (
    SELECT
      input_0."REGDATE",
      input_0."IA_TYPE",
      input_0."CK",
      input_0."COUNTRY",
      input_1."CAT2_NM",
      input_1."CAT1_NM",
      input_1."MKT_NM",
      'X' AS "TOTAL"
    FROM (
      SELECT
        input_0."OBJECT_ID",
        input_0."REGDATE",
        input_0."IA_TYPE",
        input_0."CK",
        input_1."COUNTRY"
      FROM (
        SELECT
          "OBJECT_ID",
          "ZZ1_FST_REG_DT_MIA",
          "IA_TYPE",
          "CONTACT_KEY",
          SUBSTR(CAST("ZZ1_FST_REG_DT_MIA" AS VARCHAR), 1, 6) AS "REGDATE",
          "CONTACT_KEY" AS "CK"
        FROM "OW_SEDA_S".TABLEAU_INTERACTION
      ) AS input_0
      INNER JOIN (
        SELECT
          "COUNTRY",
          "CONTACT_KEY"
        FROM "OW_SEDA_S".TABLEAU_CONTACT_INFO_STG
      ) AS input_1
        ON input_0."CONTACT_KEY" = input_1."CONTACT_KEY"
    ) AS input_0
    LEFT OUTER JOIN (
      SELECT
        "ITEM_SKU",
        "MKT_NM",
        "CAT1_NM",
        "CAT2_NM"
      FROM "OW_SEDA_S".TABLEAU_PRODUCT_MASTER
    ) AS input_1
      ON input_0."OBJECT_ID" = input_1."ITEM_SKU"
  ) AS input_0
  INNER JOIN (
    SELECT
      "COUNTRY",
      "SUB",
      "COUNTRY_NAME"
    FROM "OW_SEDA_S".TABLEAU_COUNTRY_SUB
  ) AS input_1
    ON input_0."COUNTRY" = input_1."COUNTRY"
) AS Join_3
GROUP BY
  "COUNTRY",
  "COUNTRY_NAME",
  "SUB",
  "CK",
  "IA_TYPE",
  "MKT_NM",
  "CAT1_NM",
  "CAT2_NM",
  "REGDATE",
  "TOTAL"