-- Migrated from HANA Calculation View: OW_SEDA_S.VIEWCV_CV_LEADS
-- Description: CV_LEADS_RESULTS

CREATE OR REPLACE PROCEDURE OW_SEDA_S.load_VIEWCV_CV_LEADS()
LANGUAGE PLvSQL AS $$
BEGIN

  -- Layer 0: 22 nodes

  -- Node: Projection_1
  PERFORM DROP TABLE IF EXISTS "layer_0_Projection_1" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Projection_1" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    "ZZ1_CAMPAIGN_ID_MIA",
    "CONTACT_KEY",
    "ZZ1_CREA_DT3_MIA",
    "IA_TYPE",
    SUBSTR(CAST("ZZ1_CREA_DT3_MIA" AS VARCHAR), 1, 6) AS "FST_DATE",
    SUBSTR(CAST("ZZ1_CREA_DT3_MIA" AS VARCHAR), 1, 6) AS "LAST_DATE"
  FROM (
    SELECT
      "ZZ1_CAMPAIGN_ID_MIA",
      "CONTACT_KEY",
      "ZZ1_CREA_DT3_MIA",
      "IA_TYPE",
      "ZZ1_FST_REG_DT_MIA"
    FROM "OW_SEDA_S".TABLEAU_INTERACTION
  ) AS I
  )
     ORDER BY "ZZ1_CAMPAIGN_ID_MIA"
    SEGMENTED BY HASH("ZZ1_CAMPAIGN_ID_MIA") ALL NODES
  ;

  -- Node: Join_1
  PERFORM DROP TABLE IF EXISTS "layer_0_Join_1" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Join_1" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."INITIATIVE_ID",
    input_0."COUNTRY",
    input_1."CONTACT_KEY",
    input_1."ZZ1_CAMPAIGN_ID_MIA",
    input_1."LAST_DATE",
    input_1."FST_DATE"
  FROM (
    SELECT
      "INITIATIVE_ID",
      "ZZ1_CAMPAIGN_ID_MIA",
      "COUNTRY"
    FROM "OW_SEDA_S".TABLEAU_CI
  ) AS input_0
  INNER JOIN "layer_0_Projection_1" AS input_1
    ON input_0."ZZ1_CAMPAIGN_ID_MIA" = input_1."ZZ1_CAMPAIGN_ID_MIA"
  )
     ORDER BY "CONTACT_KEY"
    SEGMENTED BY HASH("CONTACT_KEY") ALL NODES
  ;

  -- Node: Join_4
  PERFORM DROP TABLE IF EXISTS "layer_0_Join_4" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Join_4" ON COMMIT PRESERVE ROWS AS 
  SELECT
    input_0."INITIATIVE_ID",
    input_0."CONTACT_KEY",
    input_0."ZZ1_CAMPAIGN_ID_MIA",
    input_0."LAST_DATE",
    input_0."FST_DATE",
    input_0."COUNTRY",
    input_1."DELIVERED_COUNT"
  FROM "layer_0_Join_1" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "CONTACT_KEY",
      "DELIVERED_COUNT"
    FROM "OW_SEDA_S".TABLEAU_SAM_RECIPIENT
  ) AS input_1
    ON input_0."CONTACT_KEY" = input_1."CONTACT_KEY"
  ;

  -- Node: Aggregation_1
  PERFORM DROP TABLE IF EXISTS "layer_0_Aggregation_1" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Aggregation_1" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    "INITIATIVE_ID",
    "CONTACT_KEY",
    "ZZ1_CAMPAIGN_ID_MIA",
    "LAST_DATE",
    "FST_DATE",
    "COUNTRY",
    "DELIVERED_COUNT"
  FROM "layer_0_Join_4"
  GROUP BY
    "INITIATIVE_ID",
    "CONTACT_KEY",
    "ZZ1_CAMPAIGN_ID_MIA",
    "LAST_DATE",
    "FST_DATE",
    "COUNTRY",
    "DELIVERED_COUNT"
  )
     ORDER BY "CONTACT_KEY", "INITIATIVE_ID", "ZZ1_CAMPAIGN_ID_MIA", "LAST_DATE", "FST_DATE", "COUNTRY", "DELIVERED_COUNT"
    SEGMENTED BY HASH("CONTACT_KEY") ALL NODES
  ;

  -- Node: Join_2
  PERFORM DROP TABLE IF EXISTS "layer_0_Join_2" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Join_2" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."INITIATIVE_ID",
    input_0."CONTACT_KEY",
    input_0."ZZ1_CAMPAIGN_ID_MIA" AS "ZZ1_CAMPAIGN_ID_MIA_1",
    input_0."LAST_DATE",
    input_0."FST_DATE",
    input_0."COUNTRY",
    input_0."DELIVERED_COUNT",
    input_1."ZZ1_CAMPAIGN_ID_MIA",
    input_1."IA_TYPE",
    input_1."ZZ1_FST_REG_DT_MIA",
    CASE
      WHEN NOT (
        input_1."IA_TYPE" = 'Z_SEDA_PRM'
      )
      OR NOT (
        RIGHT(input_1."IA_TYPE", 3) = '_CI'
      )
      THEN SUBSTR(REPLACE(CAST(input_1."ZZ1_FST_REG_DT_MIA" AS VARCHAR), '.', ''), 1, 6)
      ELSE NULL
    END AS "REG_DATE"
  FROM "layer_0_Aggregation_1" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "ZZ1_CAMPAIGN_ID_MIA",
      "CONTACT_KEY",
      "ZZ1_CREA_DT3_MIA",
      "IA_TYPE",
      "ZZ1_FST_REG_DT_MIA"
    FROM "OW_SEDA_S".TABLEAU_INTERACTION
  ) AS input_1
    ON input_0."CONTACT_KEY" = input_1."CONTACT_KEY"
  )
     ORDER BY "COUNTRY"
    SEGMENTED BY HASH("COUNTRY") ALL NODES
  ;

  -- Node: Join_3
  PERFORM DROP TABLE IF EXISTS "layer_0_Join_3" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Join_3" ON COMMIT PRESERVE ROWS AS 
  SELECT
    input_0."ZZ1_CAMPAIGN_ID_MIA" AS "CAMPAIGN_ID",
    input_0."INITIATIVE_ID",
    input_0."FST_DATE",
    input_0."LAST_DATE",
    input_0."DELIVERED_COUNT",
    input_0."CONTACT_KEY",
    input_0."REG_DATE",
    input_1."COUNTRY_NAME",
    input_1."SUB",
    input_1."COUNTRY" AS "COUNTRY_CODE"
  FROM "layer_0_Join_2" AS input_0
  INNER JOIN (
    SELECT
      "COUNTRY",
      "SUB",
      "COUNTRY_NAME"
    FROM "OW_SEDA_S".TABLEAU_COUNTRY_SUB
  ) AS input_1
    ON input_0."COUNTRY" = input_1."COUNTRY"
  ;

  -- Node: Aggregation
  PERFORM DROP TABLE IF EXISTS "layer_0_Aggregation" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Aggregation" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    "CAMPAIGN_ID",
    "INITIATIVE_ID",
    "FST_DATE",
    "LAST_DATE",
    "REG_DATE",
    "COUNTRY_CODE",
    "COUNTRY_NAME",
    "SUB",
    "DELIVERED_COUNT",
    "CONTACT_KEY" AS "AMOUNT"
  FROM "layer_0_Join_3"
  GROUP BY
    "CAMPAIGN_ID",
    "INITIATIVE_ID",
    "FST_DATE",
    "LAST_DATE",
    "REG_DATE",
    "COUNTRY_CODE",
    "COUNTRY_NAME",
    "SUB",
    "DELIVERED_COUNT",
    "CONTACT_KEY"
  )
     ORDER BY "CAMPAIGN_ID", "INITIATIVE_ID", "FST_DATE", "LAST_DATE", "REG_DATE", "COUNTRY_CODE", "COUNTRY_NAME", "SUB", "DELIVERED_COUNT", "CONTACT_KEY"
    SEGMENTED BY HASH("CAMPAIGN_ID", "INITIATIVE_ID", "FST_DATE", "LAST_DATE") ALL NODES
  ;

  -- Materialize final result
  PERFORM CREATE TABLE IF NOT EXISTS OW_SEDA_S.VIEWCV_CV_LEADS AS
    SELECT * FROM "layer_0_Aggregation" WHERE 1=0;
  PERFORM TRUNCATE TABLE OW_SEDA_S.VIEWCV_CV_LEADS;
  PERFORM INSERT INTO OW_SEDA_S.VIEWCV_CV_LEADS
  SELECT * FROM "layer_0_Aggregation";

  PERFORM COMMIT;
  RAISE NOTICE 'Successfully loaded OW_SEDA_S.VIEWCV_CV_LEADS';

END;
$$;