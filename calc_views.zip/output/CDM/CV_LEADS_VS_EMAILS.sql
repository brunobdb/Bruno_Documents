CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_CV_LEADS_VS_EMAILS" AS
SELECT
  "INITIATIVE_ID",
  "CAMPAIGN_ID",
  "COUNTRY",
  "LEADS",
  "AMOUNT",
  "COUNTRY_NAME",
  "SUB"
FROM (
  SELECT
    input_0."INITIATIVE_ID",
    input_0."CAMPAIGN_ID",
    input_0."COUNTRY",
    input_0."LEADS",
    input_0."AMOUNT",
    input_1."SUB",
    input_1."COUNTRY_NAME"
  FROM (
    SELECT
      "INITIATIVE_ID",
      "CAMPAIGN_ID",
      "COUNTRY",
      "LEADS",
      "AMOUNT"
    FROM OW_SEDA_S.CV_LEADS_VS_EMAILS_SUBQ
  ) AS input_0
  LEFT OUTER JOIN (
    SELECT
      "COUNTRY_NAME",
      "SUB",
      "COUNTRY"
    FROM "OW_SEDA_S".TABLEAU_COUNTRY_SUB
  ) AS input_1
    ON input_0."COUNTRY" = input_1."COUNTRY"
) AS Join_3