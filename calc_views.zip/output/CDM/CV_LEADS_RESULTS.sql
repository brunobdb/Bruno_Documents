CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_CV_LEADS_RESULTS" AS
SELECT
  "REG_DATE",
  "SUB",
  "COUNTRY_NAME",
  "INITIATIVE_ID",
  "LAST_DATE",
  "FST_DATE",
  "COUNTRY",
  "CONTACT_KEY" AS "AMOUNT"
FROM (
  SELECT
    input_0."SUB",
    input_0."COUNTRY_NAME",
    input_0."INITIATIVE_ID",
    input_0."CONTACT_KEY",
    input_0."LAST_DATE",
    input_0."FST_DATE",
    input_0."COUNTRY",
    input_1."ZZ1_CAMPAIGN_ID_MIA",
    input_1."IA_TYPE",
    input_1."ZZ1_FST_REG_DT_MIA",
    CASE
      WHEN input_1."IA_TYPE" <> 'Z_SEDA_PRM' OR RIGHT(input_1."IA_TYPE", 3) <> '_CI'
      THEN SUBSTR(REPLACE(CAST(input_1."ZZ1_FST_REG_DT_MIA" AS VARCHAR), '.', ''), 1, 6)
      ELSE NULL
    END AS "REG_DATE"
  FROM (
    SELECT
      "SUB",
      "COUNTRY_NAME",
      "INITIATIVE_ID",
      "CONTACT_KEY",
      "ZZ1_CAMPAIGN_ID_MIA",
      "LAST_DATE",
      "FST_DATE",
      "COUNTRY"
    FROM (
      SELECT
        input_0."SUB",
        input_0."COUNTRY_NAME",
        input_1."INITIATIVE_ID",
        input_1."CONTACT_KEY",
        input_1."ZZ1_CAMPAIGN_ID_MIA",
        input_1."LAST_DATE",
        input_1."FST_DATE",
        input_1."COUNTRY"
      FROM (
        SELECT
          "COUNTRY",
          "SUB",
          "COUNTRY_NAME"
        FROM "OW_SEDA_S".TABLEAU_COUNTRY_SUB
      ) AS input_0
      INNER JOIN (
        SELECT
          input_0."INITIATIVE_ID",
          input_0."COUNTRY",
          input_1."CONTACT_KEY",
          input_1."ZZ1_CAMPAIGN_ID_MIA",
          input_1."LAST_DATE",
          input_1."FST_DATE"
        FROM (
          SELECT
            "INITIATIVE_ID",
            "ZZ1_CAMPAIGN_ID_MIA",
            "COUNTRY"
          FROM "OW_SEDA_S".TABLEAU_CI
        ) AS input_0
        INNER JOIN (
          SELECT
            "ZZ1_CAMPAIGN_ID_MIA",
            "CONTACT_KEY",
            "ZZ1_CREA_DT3_MIA",
            "IA_TYPE",
            SUBSTR(CAST("ZZ1_CREA_DT3_MIA" AS VARCHAR), 1, 6) AS "FST_DATE",
            SUBSTR(CAST("ZZ1_CREA_DT3_MIA" AS VARCHAR), 1, 6) AS "LAST_DATE"
          FROM (
            SELECT
              "ZZ1_CAMPAIGN_ID_MIA",
              "CONTACT_KEY",
              "ZZ1_CREA_DT3_MIA",
              "IA_TYPE",
              "ZZ1_FST_REG_DT_MIA"
            FROM "OW_SEDA_S".TABLEAU_INTERACTION
          ) AS I
        ) AS input_1
          ON input_0."ZZ1_CAMPAIGN_ID_MIA" = input_1."ZZ1_CAMPAIGN_ID_MIA"
      ) AS input_1
        ON input_0."COUNTRY" = input_1."COUNTRY"
    ) AS Join_4
    GROUP BY
      "SUB",
      "COUNTRY_NAME",
      "INITIATIVE_ID",
      "CONTACT_KEY",
      "ZZ1_CAMPAIGN_ID_MIA",
      "LAST_DATE",
      "FST_DATE",
      "COUNTRY"
  ) AS input_0
  LEFT OUTER JOIN (
    SELECT
      "ZZ1_CAMPAIGN_ID_MIA",
      "CONTACT_KEY",
      "ZZ1_CREA_DT3_MIA",
      "IA_TYPE",
      "ZZ1_FST_REG_DT_MIA"
    FROM "OW_SEDA_S".TABLEAU_INTERACTION
  ) AS input_1
    ON input_0."CONTACT_KEY" = input_1."CONTACT_KEY"
) AS Join_2
GROUP BY
  "REG_DATE",
  "SUB",
  "COUNTRY_NAME",
  "INITIATIVE_ID",
  "LAST_DATE",
  "FST_DATE",
  "COUNTRY",
  "CONTACT_KEY"