CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_CV_CONTACT_INFO" AS
SELECT
  "CONTACT_KEY",
  "SMTP_ADDR2",
  "COUNTRY_NAME",
  "COUNTRY" AS "COUNTRY_CODE",
  "SUB",
  "MKT_NM",
  "CAT2_NM",
  "SEX",
  "REGION",
  "REG_DATE",
  "ZZ1_OPTIN_ENH",
  "BLACKLISTED",
  "AGE",
  "HOLD_TERM_P",
  "LASTBEF_DVC_GP_NM",
  "CHANGE_TERM_P",
  "SMTP_ADDR_FLG",
  "COUNT_CATS",
  "ACTIVE_FLAG",
  "IMEI_FLAG",
  "SMTP_ADDR" AS "COUNT_SMTP_ADDR"
FROM (
  SELECT
    input_0."BLACKLISTED",
    input_0."CONTACT_KEY",
    input_0."SMTP_ADDR",
    input_0."SMTP_ADDR2",
    input_0."SEX",
    input_0."CHANGE_TERM_P",
    input_0."HOLD_TERM_P",
    input_0."REGION",
    input_0."SMTP_ADDR_FLG",
    input_0."ZZ1_OPTIN_ENH",
    input_0."IMEI_FLAG" AS "IMEI_FLAG_ORIG",
    input_0."ACTIVE_FLG" AS "ACTIVE_FLAG_ORIG",
    input_0."AGE",
    input_0."MKT_NM",
    input_0."CAT2_NM",
    input_0."REG_DATE",
    input_0."LASTBEF_DVC_GP_NM",
    input_0."COUNT_CAT",
    input_1."COUNTRY",
    input_1."SUB",
    input_1."COUNTRY_NAME",
    CASE WHEN (
      input_0."COUNT_CAT"
    ) IS NULL THEN 0 ELSE input_0."COUNT_CAT" END AS "COUNT_CATS",
    CASE
      WHEN (
        LEFT("IMEI_FLAG_ORIG", 1) IS NULL
      )
      THEN '0'
      ELSE LEFT("IMEI_FLAG_ORIG", 1)
    END AS "IMEI_FLAG",
    CASE
      WHEN (
        LEFT("ACTIVE_FLAG_ORIG", 1) IS NULL
      )
      THEN '0'
      ELSE LEFT("ACTIVE_FLAG_ORIG", 1)
    END AS "ACTIVE_FLAG"
  FROM (
    SELECT
      input_0."COUNTRY_CODE",
      input_0."CONTACT_KEY",
      input_0."SMTP_ADDR",
      input_0."SMTP_ADDR2",
      input_0."LASTBEF_DVC_GP_NM",
      input_0."SEX",
      input_0."CHANGE_TERM_P",
      input_0."HOLD_TERM_P",
      input_0."REGION",
      input_0."SMTP_ADDR_FLG",
      input_0."ZZ1_OPTIN_ENH",
      input_0."IMEI_FLAG",
      input_0."ACTIVE_FLG",
      input_0."AGE",
      input_0."COUNT_CAT",
      input_0."MKT_NM",
      input_0."CAT2_NM",
      input_0."REG_DATE",
      input_1."BLACKLISTED"
    FROM (
      SELECT
        input_0."COUNTRY" AS "COUNTRY_CODE",
        input_0."CONTACT_KEY",
        input_0."SMTP_ADDR",
        input_0."SMTP_ADDR2",
        input_0."LASTBEF_DVC_GP_NM",
        input_0."SEX",
        input_0."CHANGE_TERM_P",
        input_0."HOLD_TERM_P",
        input_0."REGION",
        input_0."SMTP_ADDR_FLG",
        input_0."ZZ1_OPTIN_ENH",
        input_0."IMEI_FLAG",
        input_0."ACTIVE_FLG",
        input_0."AGE",
        input_0."MKT_NM",
        input_0."CAT2_NM",
        input_0."REG_DATE",
        input_1."COUNT_CAT"
      FROM (
        SELECT
          input_0."COUNTRY",
          input_0."CONTACT_KEY",
          input_0."SMTP_ADDR",
          input_0."SMTP_ADDR2",
          input_0."LASTBEF_DVC_GP_NM",
          input_0."SEX",
          input_0."CHANGE_TERM_P",
          input_0."HOLD_TERM_P",
          input_0."REGION",
          input_0."SMTP_ADDR_FLG",
          input_0."ZZ1_OPTIN_ENH",
          input_0."IMEI_FLAG",
          input_0."ACTIVE_FLG",
          input_0."AGE",
          input_0."LAST_DVC_GP_NM",
          input_0."REG_DATE",
          input_1."MKT_NM",
          input_1."CAT2_NM"
        FROM (
          SELECT
            "CONTACT_KEY",
            "SMTP_ADDR",
            "COUNTRY",
            "LAST_DVC_GP_NM",
            "SEX",
            "LASTBEF_DVC_GP_NM",
            "HOLD_TERM_P",
            "CHANGE_TERM_P",
            "REGION",
            "SMTP_ADDR_FLG",
            "ZZ1_OPTIN_ENH",
            "IMEI_FLAG",
            "ACTIVE_FLG",
            "DATE_OF_BIRTH",
            "ZZ1_REGIST_DT_ENH",
            "SMTP_ADDR" AS "SMTP_ADDR2",
            CAST(LEFT(CAST(NOW() AS VARCHAR), 4) AS INT) - CAST(SUBSTR(CAST("DATE_OF_BIRTH" AS VARCHAR), 1, 4) AS INT) AS "AGE",
            LEFT(REPLACE(CAST("ZZ1_REGIST_DT_ENH" AS VARCHAR), '.', ''), 6) AS "REG_DATE"
          FROM "OW_SEDA_S".TABLEAU_CONTACT_INFO
        ) AS input_0
        LEFT OUTER JOIN (
          SELECT
            "ITEM_SKU",
            "MKT_NM",
            "CAT2_NM"
          FROM "OW_SEDA_S".TABLEAU_PRODUCT_MASTER
        ) AS input_1
          ON input_0."LAST_DVC_GP_NM" = input_1."ITEM_SKU"
      ) AS input_0
      LEFT OUTER JOIN (
        SELECT
          "COUNT_CAT",
          "CONTACT_KEY"
        FROM OW_SEDA_S.CV_CONTACT_INFO_SUBQ
      ) AS input_1
        ON input_0."CONTACT_KEY" = input_1."CONTACT_KEY"
    ) AS input_0
    LEFT OUTER JOIN (
      SELECT
        "CONTACT_KEY",
        CASE WHEN (
          "CONTACT_KEY"
        ) IS NULL THEN 'X' ELSE NULL END AS "BLACKLISTED"
      FROM "OW_SEDA_S".TABLEAU_BLACKLIST
    ) AS input_1
      ON input_0."CONTACT_KEY" = input_1."CONTACT_KEY"
  ) AS input_0
  INNER JOIN (
    SELECT
      "COUNTRY_NAME",
      "SUB",
      "COUNTRY"
    FROM "OW_SEDA_S".TABLEAU_COUNTRY_SUB
  ) AS input_1
    ON input_0."COUNTRY_CODE" = input_1."COUNTRY"
) AS Join_2
GROUP BY
  "CONTACT_KEY",
  "SMTP_ADDR2",
  "COUNTRY_NAME",
  "COUNTRY",
  "SUB",
  "MKT_NM",
  "CAT2_NM",
  "SEX",
  "REGION",
  "REG_DATE",
  "ZZ1_OPTIN_ENH",
  "BLACKLISTED",
  "AGE",
  "HOLD_TERM_P",
  "LASTBEF_DVC_GP_NM",
  "CHANGE_TERM_P",
  "SMTP_ADDR_FLG",
  "COUNT_CATS",
  "ACTIVE_FLAG",
  "IMEI_FLAG",
  "SMTP_ADDR"