CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_CV_ORIGIN_OPTIN" AS
SELECT
  "SUB",
  "ID_ORIGIN",
  "COUNTRY",
  "ZZ1_OPTIN_ENH",
  "REG_DATE",
  "CONTACT_KEY" AS "CONTAGEM"
FROM (
  SELECT
    input_0."ID_ORIGIN",
    input_0."COUNTRY",
    input_0."ZZ1_OPTIN_ENH",
    input_0."CONTACT_KEY",
    input_0."REG_DATE",
    input_1."SUB"
  FROM (
    SELECT
      input_0."ZZ1_OPTIN_ENH",
      input_0."COUNTRY",
      input_0."CONTACT_KEY",
      input_1."ID_ORIGIN",
      input_1."REG_DATE"
    FROM (
      SELECT
        "COUNTRY",
        "CONTACT_KEY",
        "ZZ1_OPTIN_ENH"
      FROM "OW_SEDA_S".TABLEAU_CONTACT_INFO
    ) AS input_0
    INNER JOIN (
      SELECT
        "REG_DATE" AS "REG_DATE_ORIG",
        "CONTACT_KEY",
        "ID_ORIGIN",
        LEFT(CAST("REG_DATE_ORIG" AS VARCHAR), 6) AS "REG_DATE"
      FROM "OW_SEDA_S".TABLEAU_ORIGIN
    ) AS input_1
      ON input_0."CONTACT_KEY" = input_1."CONTACT_KEY"
  ) AS input_0
  INNER JOIN (
    SELECT
      "COUNTRY",
      "SUB"
    FROM "OW_SEDA_S".TABLEAU_COUNTRY_SUB
  ) AS input_1
    ON input_0."COUNTRY" = input_1."COUNTRY"
) AS Join_2
GROUP BY
  "SUB",
  "ID_ORIGIN",
  "COUNTRY",
  "ZZ1_OPTIN_ENH",
  "REG_DATE",
  "CONTACT_KEY"