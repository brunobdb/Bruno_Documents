CREATE OR REPLACE VIEW "SAP"."RULES_PER_VOCAB_AND_OUTPUT" AS
SELECT
  r.ID AS "RULE_ID",
  r.PACKAGE AS "RULE_PACKAGE",
  r.NAME AS "RULE_NAME",
  r.SUFFIX AS "RULE_SUFFIX"
FROM "OW_SEDA_S".NULL AS r /* unsupported HANA package ref */
JOIN (
  SELECT
    PATH_FULL_NAME
  FROM "OW_SEDA_S".NULL /* unsupported HANA package ref */
  WHERE
    SCOPE = (
      SELECT
        SCOPE
      FROM "OW_SEDA_S".NULL /* unsupported HANA package ref */
      WHERE
        PATH_FULL_NAME = NULL /* :vocabulary_full_name */
    )
) AS v
  ON r.VOCABULARY = v.PATH_FULL_NAME
WHERE
  r.SINGLE_CONSUMPTION = 0
  AND (
    r.OUTPUT = NULL /* :output_name */ OR NULL /* :output_name */ = ''
  )
  AND r.STATUS = 'Active'