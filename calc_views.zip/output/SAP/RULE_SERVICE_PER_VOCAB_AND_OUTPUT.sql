CREATE OR REPLACE VIEW "SAP"."RULE_SERVICE_PER_VOCAB_AND_OUTPUT" AS
SELECT
  R.ID AS "RULE_SERVICE_ID",
  R.PACKAGE AS "RULE_SERVICE_PACKAGE",
  R.NAME AS "RULE_SERVICE_NAME",
  R.SUFFIX AS "RULE_SERVICE_SUFFIX"
FROM "OW_SEDA_S".NULL AS R /* unsupported HANA package ref */
JOIN (
  SELECT
    PATH_FULL_NAME
  FROM "OW_SEDA_S".NULL /* unsupported HANA package ref */
  WHERE
    SCOPE = (
      SELECT
        SCOPE
      FROM "OW_SEDA_S".NULL /* unsupported HANA package ref */
      WHERE
        PATH_FULL_NAME = NULL /* :vocabulary_full_name */
    )
) AS V
  ON R.VOCABULARY = V.PATH_FULL_NAME
WHERE
  R.RULE_ASSIGNMENT = 'Manual'
  AND R.SINGLE_CONSUMPTION = 0
  AND R.MARKED_FOR_DELETE <> 1
  AND (
    R.OUTPUT = NULL /* :output_name */ OR R.OUTPUT IS NULL
  )