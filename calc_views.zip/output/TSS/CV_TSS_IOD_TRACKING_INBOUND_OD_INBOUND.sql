-- Migrated from HANA Calculation View: OW_SEDA_S.VIEWCV_CV_TSS_IOD_TRACKING_INBOUND_OD_INBOUND
-- Description: CV_TSS

CREATE OR REPLACE PROCEDURE OW_SEDA_S.load_VIEWCV_CV_TSS_IOD_TRACKING_INBOUND_OD_INBOUND()
LANGUAGE PLvSQL AS $$
BEGIN

  -- Layer 0: 44 nodes

  -- Node: INNER_OD_INBOUND_DETAIL
  PERFORM DROP TABLE IF EXISTS "layer_0_INNER_OD_INBOUND_DETAIL" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_INNER_OD_INBOUND_DETAIL" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."OD_INBOUND_SN_NO",
    input_0."ONE",
    input_0."OD_INBOUND_BL",
    input_0."OD_INBOUND_SO",
    input_0."CONTAINER" AS "OD_INBOUND_CONTAINER",
    input_0."DELIVERY_TYPE",
    input_0."SUB_TRANS_TYPE",
    input_0."WH_ARRIVAL_DATE",
    input_0."INVOICE_NO",
    input_0."SHIPPING_POINT_CD",
    input_0."VESSEL_CD",
    input_0."TRANS_CD",
    input_0."WH_CD",
    input_0."INSERT_DATE",
    input_0."CALESCE_DYNAMIC_OPERATION" AS "DYNAMIC_OPERATION",
    input_1."ITEM_CD",
    input_1."ITEM_NO",
    input_1."UNIT_PRICE",
    input_1."PLANT",
    input_1."STORAGE_LOCATION",
    input_1."ITEM_QTY",
    input_1."UNIT",
    LPAD(input_1."ITEM_NO", 6, '0') AS "OD_INBOUND_DETAIL_LPAD_ITEM_NO"
  FROM (
    SELECT
      "SN_NO" AS "OD_INBOUND_SN_NO",
      "BL" AS "OD_INBOUND_BL",
      "CONTAINER",
      "GS_VENDOR_CD",
      "GS_VENDOR_NM",
      "GS_VENDOR_STREET",
      "GS_VENDOR_AREA",
      "PO_VENDOR_CD",
      "PO_VENDOR_NM",
      "SUB_TRANS_TYPE",
      "SO" AS "OD_INBOUND_SO",
      "INSERT_DATE",
      "INSERT_ID",
      "UPDATE_DATE",
      "UPDATE_ID",
      "CUSTOMS_CHANNEL",
      "INVOICE_NO",
      "VENDOR_COUNTRY",
      "DELIVERY_TYPE",
      "CURRENCY",
      "SHIPPING_POINT_CD",
      "INCOTERM",
      "INCOTERM2",
      "VESSEL_CD",
      "DI_NO",
      "WH_CD",
      "TRANS_CD",
      "WH_ARRIVAL_DATE",
      "REMESSA_NF",
      "REMESSA_NF_SERIE",
      "PARENT_DOCNUM",
      "PARENT_NF",
      "PARENT_NF_SERIE",
      "CHILD_DOCNUM",
      "CHILD_NF",
      "CHILD_NF_SERIE",
      "DYNAMIC_OPERATION",
      1 AS "ONE",
      COALESCE("DYNAMIC_OPERATION", 'N') AS "CALESCE_DYNAMIC_OPERATION"
    FROM "OW_SEDA_S".SDI_TSS_OD_INBOUND
  ) AS input_0
  INNER JOIN "OW_SEDA_S".SDI_TSS_OD_INBOUND_DETAIL AS input_1
    ON input_0."OD_INBOUND_SN_NO" = input_1."SN_NO"
  )
     ORDER BY "OD_INBOUND_SN_NO"
    SEGMENTED BY HASH("OD_INBOUND_SN_NO") ALL NODES
  ;

  -- Node: INNER_TC_INBOUND
  PERFORM DROP TABLE IF EXISTS "layer_0_INNER_TC_INBOUND" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_INNER_TC_INBOUND" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."OD_INBOUND_SN_NO" AS "SN_NO",
    input_0."ONE",
    input_0."ITEM_CD",
    input_0."OD_INBOUND_BL",
    input_0."OD_INBOUND_SO",
    input_0."OD_INBOUND_DETAIL_LPAD_ITEM_NO",
    input_0."OD_INBOUND_SN_NO",
    input_0."OD_INBOUND_CONTAINER",
    input_0."DELIVERY_TYPE",
    input_0."SUB_TRANS_TYPE",
    input_0."WH_ARRIVAL_DATE",
    input_0."INVOICE_NO",
    input_0."SHIPPING_POINT_CD",
    input_0."VESSEL_CD",
    input_0."TRANS_CD",
    input_0."WH_CD",
    input_0."INSERT_DATE",
    input_0."UNIT_PRICE",
    input_0."PLANT",
    input_0."STORAGE_LOCATION",
    input_0."ITEM_QTY",
    input_0."DYNAMIC_OPERATION",
    input_0."UNIT",
    input_1."SCHEDULE_STATUS_CD",
    input_1."SN_NO" AS "TC_INBOUND_SN_NO",
    input_1."REMESSA_NF" AS "NF_EXT_NO",
    input_1."REMESSA_NF_SERIE" AS "NF_SERIES",
    input_1."EMAIL_SEND_YN",
    input_1."EMAIL_LIST",
    input_1."NF_MOTHER_SERIE",
    input_1."NF_MOTHER_NO",
    input_1."ETD_FROM_PORT_DATE",
    input_1."LAST_CANCEL_SCHEDULE_DATE",
    input_1."LAST_SCHEDULE_DATE",
    input_1."MNF_NO",
    input_1."CNH",
    input_1."LICENSE_PLATE",
    input_1."DRIVER_NM",
    input_1."PRIORITY" AS "TC_INBOUND_PRIORITY",
    input_1."TRUCK_TYPE",
    input_1."SEAL_NO",
    input_1."INBOUND_BOOKING",
    input_1."WH_DOCK_DATE_TIME" AS "DOCK_IN",
    input_1."WH_DOCK_OUT_DATE_TIME" AS "DOCK_OUT",
    input_1."WH_GATE_IN_DATE_TIME" AS "GATE_IN",
    input_1."WH_GATE_OUT_DATE_TIME" AS "GATE_OUT",
    input_1."REMESSA_NF",
    input_1."REMESSA_NF_SERIE"
  FROM "layer_0_INNER_OD_INBOUND_DETAIL" AS input_0
  INNER JOIN "OW_SEDA_S".SDI_TSS_TC_INBOUND AS input_1
    ON input_0."OD_INBOUND_SN_NO" = input_1."SN_NO"
  )
     ORDER BY "SCHEDULE_STATUS_CD"
    SEGMENTED BY HASH("SCHEDULE_STATUS_CD") ALL NODES
  ;

  -- Node: LEFT_M_CODE
  PERFORM DROP TABLE IF EXISTS "layer_0_LEFT_M_CODE" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_LEFT_M_CODE" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."ONE",
    input_0."SCHEDULE_STATUS_CD",
    input_0."ITEM_CD",
    input_0."TC_INBOUND_SN_NO",
    input_0."OD_INBOUND_BL",
    input_0."OD_INBOUND_SO",
    input_0."NF_EXT_NO" AS "REMESSA_NF",
    input_0."NF_SERIES" AS "TC_INBOUND_REMESSA_NF_SERIE",
    input_0."OD_INBOUND_DETAIL_LPAD_ITEM_NO",
    input_0."OD_INBOUND_SN_NO",
    input_0."OD_INBOUND_CONTAINER",
    input_0."EMAIL_SEND_YN",
    input_0."EMAIL_LIST",
    input_0."DELIVERY_TYPE",
    input_0."SUB_TRANS_TYPE",
    input_0."WH_ARRIVAL_DATE",
    input_0."INVOICE_NO",
    input_0."SHIPPING_POINT_CD",
    input_0."VESSEL_CD",
    input_0."TRANS_CD",
    input_0."WH_CD",
    input_0."NF_MOTHER_SERIE",
    input_0."NF_MOTHER_NO",
    input_0."ETD_FROM_PORT_DATE",
    input_0."LAST_CANCEL_SCHEDULE_DATE",
    input_0."LAST_SCHEDULE_DATE",
    input_0."NF_EXT_NO",
    input_0."NF_SERIES",
    input_0."INSERT_DATE",
    input_0."UNIT_PRICE",
    input_0."PLANT",
    input_0."STORAGE_LOCATION",
    input_0."MNF_NO",
    input_0."CNH",
    input_0."LICENSE_PLATE",
    input_0."DRIVER_NM",
    input_0."TC_INBOUND_PRIORITY",
    input_0."TRUCK_TYPE",
    input_0."SEAL_NO",
    input_0."ITEM_QTY",
    input_0."INBOUND_BOOKING",
    input_0."DOCK_IN",
    input_0."DOCK_OUT",
    input_0."GATE_IN",
    input_0."GATE_OUT",
    input_0."DYNAMIC_OPERATION",
    input_0."UNIT",
    input_0."REMESSA_NF" AS "REMESSA_NF_1",
    input_0."REMESSA_NF_SERIE",
    input_1."SCHEDULE_STATUS_NM"
  FROM "layer_0_INNER_TC_INBOUND" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "CODE_CD",
      "CODE_TYPE_CD",
      "CODE_NM" AS "SCHEDULE_STATUS_NM"
    FROM "OW_SEDA_S".SDI_TSS_M_CODE
  ) AS input_1
    ON input_0."SCHEDULE_STATUS_CD" = input_1."CODE_CD"
  )
     ORDER BY "ITEM_CD"
    SEGMENTED BY HASH("ITEM_CD") ALL NODES
  ;

  -- Node: LEFT_M_ITEM
  PERFORM DROP TABLE IF EXISTS "layer_0_LEFT_M_ITEM" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_LEFT_M_ITEM" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."TC_INBOUND_SN_NO",
    input_0."OD_INBOUND_BL",
    input_0."OD_INBOUND_SO",
    input_0."ONE",
    input_0."REMESSA_NF",
    input_0."TC_INBOUND_REMESSA_NF_SERIE",
    input_0."OD_INBOUND_DETAIL_LPAD_ITEM_NO",
    input_0."OD_INBOUND_SN_NO",
    input_0."OD_INBOUND_CONTAINER",
    input_0."SCHEDULE_STATUS_NM",
    input_0."EMAIL_SEND_YN",
    input_0."EMAIL_LIST",
    input_0."DELIVERY_TYPE",
    input_0."SUB_TRANS_TYPE",
    input_0."WH_ARRIVAL_DATE",
    input_0."INVOICE_NO",
    input_0."SHIPPING_POINT_CD",
    input_0."VESSEL_CD",
    input_0."TRANS_CD",
    input_0."WH_CD",
    input_0."NF_MOTHER_SERIE",
    input_0."NF_MOTHER_NO",
    input_0."ETD_FROM_PORT_DATE",
    input_0."LAST_CANCEL_SCHEDULE_DATE",
    input_0."LAST_SCHEDULE_DATE",
    input_0."NF_EXT_NO",
    input_0."NF_SERIES",
    input_0."INSERT_DATE",
    input_0."UNIT_PRICE",
    input_0."PLANT",
    input_0."STORAGE_LOCATION",
    input_0."MNF_NO",
    input_0."CNH",
    input_0."LICENSE_PLATE",
    input_0."DRIVER_NM",
    input_0."TC_INBOUND_PRIORITY",
    input_0."TRUCK_TYPE",
    input_0."SEAL_NO",
    input_0."ITEM_CD",
    input_0."ITEM_QTY",
    input_0."INBOUND_BOOKING",
    input_0."DOCK_IN",
    input_0."DOCK_OUT",
    input_0."GATE_IN",
    input_0."GATE_OUT",
    input_0."DYNAMIC_OPERATION",
    input_0."SCHEDULE_STATUS_CD",
    input_0."UNIT",
    input_0."REMESSA_NF_1",
    input_0."REMESSA_NF_SERIE",
    input_1."DIVISION_CD",
    input_1."ITEM_VOLUME",
    input_0."ITEM_QTY" * input_1."ITEM_VOLUME" AS "SUM_ITEM_VOLUME"
  FROM "layer_0_LEFT_M_CODE" AS input_0
  LEFT OUTER JOIN "OW_SEDA_S".ODS_TSS_M_ITEM AS input_1
    ON input_0."ITEM_CD" = input_1."ITEM_CD"
  )
     ORDER BY "TC_INBOUND_SN_NO"
    SEGMENTED BY HASH("TC_INBOUND_SN_NO") ALL NODES
  ;

  -- Node: LEFT_NF_OD_ORDERS_1
  PERFORM DROP TABLE IF EXISTS "layer_0_LEFT_NF_OD_ORDERS_1" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_LEFT_NF_OD_ORDERS_1" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."TC_INBOUND_SN_NO",
    input_0."OD_INBOUND_BL",
    input_0."OD_INBOUND_SO",
    input_0."ONE",
    input_0."REMESSA_NF",
    input_0."OD_INBOUND_DETAIL_LPAD_ITEM_NO",
    input_0."OD_INBOUND_SN_NO",
    input_0."OD_INBOUND_CONTAINER",
    input_0."SCHEDULE_STATUS_NM",
    input_0."EMAIL_SEND_YN",
    input_0."EMAIL_LIST",
    input_0."DELIVERY_TYPE",
    input_0."SUB_TRANS_TYPE",
    input_0."WH_ARRIVAL_DATE",
    input_0."INVOICE_NO",
    input_0."SHIPPING_POINT_CD",
    input_0."VESSEL_CD",
    input_0."TRANS_CD",
    input_0."WH_CD",
    input_0."NF_MOTHER_SERIE",
    input_0."NF_MOTHER_NO",
    input_0."ETD_FROM_PORT_DATE",
    input_0."LAST_CANCEL_SCHEDULE_DATE",
    input_0."LAST_SCHEDULE_DATE",
    input_0."TC_INBOUND_REMESSA_NF_SERIE",
    input_0."NF_EXT_NO",
    input_0."NF_SERIES",
    input_0."INSERT_DATE",
    input_0."DIVISION_CD",
    input_0."UNIT_PRICE",
    input_0."PLANT",
    input_0."STORAGE_LOCATION",
    input_0."MNF_NO",
    input_0."CNH",
    input_0."LICENSE_PLATE",
    input_0."DRIVER_NM",
    input_0."TC_INBOUND_PRIORITY",
    input_0."TRUCK_TYPE",
    input_0."SEAL_NO",
    input_0."ITEM_CD",
    input_0."ITEM_QTY",
    input_0."SUM_ITEM_VOLUME",
    input_0."INBOUND_BOOKING",
    input_0."DOCK_IN",
    input_0."DOCK_OUT",
    input_0."GATE_IN",
    input_0."GATE_OUT",
    input_0."DYNAMIC_OPERATION",
    input_0."SCHEDULE_STATUS_CD",
    input_0."UNIT",
    input_0."REMESSA_NF_1",
    input_0."REMESSA_NF_SERIE",
    input_1."NF_INT_NO",
    input_1."DO_NO" AS "NF_OD_DO_NO"
  FROM "layer_0_LEFT_M_ITEM" AS input_0
  LEFT OUTER JOIN "OW_SEDA_S".SDI_TSS_NF_OD_ORDERS AS input_1
    ON input_0."TC_INBOUND_SN_NO" = input_1."NF_INT_NO"
  )
     ORDER BY "OD_INBOUND_BL"
    SEGMENTED BY HASH("OD_INBOUND_BL") ALL NODES
  ;

  -- Node: LEFT_NF_OD_ORDERS_2
  PERFORM DROP TABLE IF EXISTS "layer_0_LEFT_NF_OD_ORDERS_2" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_LEFT_NF_OD_ORDERS_2" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."OD_INBOUND_BL",
    input_0."OD_INBOUND_SO",
    input_0."ONE",
    input_0."NF_OD_DO_NO",
    input_0."REMESSA_NF",
    input_0."OD_INBOUND_DETAIL_LPAD_ITEM_NO",
    input_0."OD_INBOUND_SN_NO",
    input_0."OD_INBOUND_CONTAINER",
    input_0."SCHEDULE_STATUS_NM",
    input_0."EMAIL_SEND_YN",
    input_0."EMAIL_LIST",
    input_0."DELIVERY_TYPE",
    input_0."SUB_TRANS_TYPE",
    input_0."WH_ARRIVAL_DATE",
    input_0."INVOICE_NO",
    input_0."SHIPPING_POINT_CD",
    input_0."VESSEL_CD",
    input_0."TRANS_CD",
    input_0."WH_CD",
    input_0."NF_MOTHER_SERIE",
    input_0."NF_MOTHER_NO",
    input_0."ETD_FROM_PORT_DATE",
    input_0."LAST_CANCEL_SCHEDULE_DATE",
    input_0."LAST_SCHEDULE_DATE",
    input_0."TC_INBOUND_REMESSA_NF_SERIE",
    input_0."NF_EXT_NO",
    input_0."NF_SERIES",
    input_0."INSERT_DATE",
    input_0."DIVISION_CD",
    input_0."UNIT_PRICE",
    input_0."PLANT",
    input_0."STORAGE_LOCATION",
    input_0."MNF_NO",
    input_0."CNH",
    input_0."LICENSE_PLATE",
    input_0."DRIVER_NM",
    input_0."TC_INBOUND_PRIORITY",
    input_0."TRUCK_TYPE",
    input_0."SEAL_NO",
    input_0."ITEM_CD",
    input_0."ITEM_QTY",
    input_0."SUM_ITEM_VOLUME",
    input_0."INBOUND_BOOKING",
    input_0."DOCK_IN",
    input_0."DOCK_OUT",
    input_0."GATE_IN",
    input_0."GATE_OUT",
    input_0."DYNAMIC_OPERATION",
    input_0."SCHEDULE_STATUS_CD",
    input_0."UNIT",
    input_0."REMESSA_NF_1",
    input_0."REMESSA_NF_SERIE",
    input_1."NF_TOT_AMT1",
    input_1."NF_TOT_AMT2",
    input_1."NF_EXT_NO_PARENT",
    input_1."NF_MOTHER_AMOUNT",
    input_0."OD_INBOUND_SO" AS "OD_INBOUND_DECIMAL_SO",
    CAST("OD_INBOUND_DECIMAL_SO" AS INT) AS "SO_INT_2"
  FROM "layer_0_LEFT_NF_OD_ORDERS_1" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "INBOUND_NF_FLAG",
      "BL" AS "NF_OD_ORDERS_BL",
      "NF_TOT_AMT1",
      "NF_TOT_AMT2",
      "NF_EXT_NO" AS "NF_EXT_NO_PARENT",
      "NF_TOT_AMT1" AS "NF_MOTHER_AMOUNT"
    FROM "OW_SEDA_S".SDI_TSS_NF_OD_ORDERS
  ) AS input_1
    ON input_0."OD_INBOUND_BL" = input_1."NF_OD_ORDERS_BL"
  )
     ORDER BY "SO_INT_2"
    SEGMENTED BY HASH("SO_INT_2") ALL NODES
  ;

  -- Node: LEFT_OD_ORDERS_LOC
  PERFORM DROP TABLE IF EXISTS "layer_0_LEFT_OD_ORDERS_LOC" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_LEFT_OD_ORDERS_LOC" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."OD_INBOUND_SO",
    input_0."OD_INBOUND_DECIMAL_SO",
    input_0."ONE",
    input_0."NF_OD_DO_NO",
    input_0."REMESSA_NF",
    input_0."OD_INBOUND_DETAIL_LPAD_ITEM_NO",
    input_0."OD_INBOUND_SN_NO",
    input_0."OD_INBOUND_CONTAINER",
    input_0."OD_INBOUND_BL",
    input_0."SCHEDULE_STATUS_NM",
    input_0."EMAIL_SEND_YN",
    input_0."EMAIL_LIST",
    input_0."DELIVERY_TYPE",
    input_0."SUB_TRANS_TYPE",
    input_0."WH_ARRIVAL_DATE",
    input_0."INVOICE_NO",
    input_0."SHIPPING_POINT_CD",
    input_0."VESSEL_CD",
    input_0."TRANS_CD",
    input_0."WH_CD",
    input_0."NF_MOTHER_SERIE",
    input_0."NF_MOTHER_NO",
    input_0."ETD_FROM_PORT_DATE",
    input_0."LAST_CANCEL_SCHEDULE_DATE",
    input_0."LAST_SCHEDULE_DATE",
    input_0."TC_INBOUND_REMESSA_NF_SERIE",
    input_0."NF_EXT_NO",
    input_0."NF_SERIES",
    input_0."INSERT_DATE",
    input_0."NF_TOT_AMT1",
    input_0."DIVISION_CD",
    input_0."UNIT_PRICE",
    input_0."PLANT",
    input_0."STORAGE_LOCATION",
    input_0."NF_TOT_AMT2",
    input_0."NF_EXT_NO_PARENT",
    input_0."MNF_NO",
    input_0."CNH",
    input_0."LICENSE_PLATE",
    input_0."DRIVER_NM",
    input_0."TC_INBOUND_PRIORITY",
    input_0."TRUCK_TYPE",
    input_0."SEAL_NO",
    input_0."ITEM_CD",
    input_0."ITEM_QTY",
    input_0."SUM_ITEM_VOLUME",
    input_0."INBOUND_BOOKING",
    input_0."DOCK_IN",
    input_0."DOCK_OUT",
    input_0."GATE_IN",
    input_0."GATE_OUT",
    input_0."DYNAMIC_OPERATION",
    input_0."SCHEDULE_STATUS_CD",
    input_0."NF_MOTHER_AMOUNT",
    input_0."UNIT",
    input_0."REMESSA_NF_1",
    input_0."REMESSA_NF_SERIE",
    input_0."SO_INT_2",
    input_1."SO",
    CAST(input_0."OD_INBOUND_DECIMAL_SO" AS INT) AS "SO_INT"
  FROM "layer_0_LEFT_NF_OD_ORDERS_2" AS input_0
  LEFT OUTER JOIN "OW_SEDA_S".SDI_TSS_OD_ORDERS_LOC AS input_1
    ON input_0."SO_INT_2" = input_1."SO"
  )
     ORDER BY "NF_OD_DO_NO"
    SEGMENTED BY HASH("NF_OD_DO_NO") ALL NODES
  ;

  -- Node: LEFT_OD_ORDERS
  PERFORM DROP TABLE IF EXISTS "layer_0_LEFT_OD_ORDERS" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_LEFT_OD_ORDERS" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."NF_OD_DO_NO",
    input_0."ONE",
    input_0."REMESSA_NF",
    input_0."OD_INBOUND_DETAIL_LPAD_ITEM_NO",
    input_0."OD_INBOUND_SN_NO",
    input_0."OD_INBOUND_CONTAINER",
    input_0."OD_INBOUND_BL",
    input_0."SCHEDULE_STATUS_NM",
    input_0."EMAIL_SEND_YN",
    input_0."EMAIL_LIST",
    input_0."DELIVERY_TYPE",
    input_0."SUB_TRANS_TYPE",
    input_0."WH_ARRIVAL_DATE",
    input_0."INVOICE_NO",
    input_0."SHIPPING_POINT_CD",
    input_0."OD_INBOUND_SO",
    input_0."VESSEL_CD",
    input_0."TRANS_CD",
    input_0."WH_CD",
    input_0."NF_MOTHER_SERIE",
    input_0."NF_MOTHER_NO",
    input_0."ETD_FROM_PORT_DATE",
    input_0."LAST_CANCEL_SCHEDULE_DATE",
    input_0."LAST_SCHEDULE_DATE",
    input_0."TC_INBOUND_REMESSA_NF_SERIE",
    input_0."NF_EXT_NO",
    input_0."NF_SERIES",
    input_0."INSERT_DATE",
    input_0."NF_TOT_AMT1",
    input_0."DIVISION_CD",
    input_0."UNIT_PRICE",
    input_0."PLANT",
    input_0."STORAGE_LOCATION",
    input_0."NF_TOT_AMT2",
    input_0."NF_EXT_NO_PARENT",
    input_0."MNF_NO",
    input_0."CNH",
    input_0."LICENSE_PLATE",
    input_0."DRIVER_NM",
    input_0."TC_INBOUND_PRIORITY",
    input_0."TRUCK_TYPE",
    input_0."SEAL_NO",
    input_0."ITEM_CD",
    input_0."ITEM_QTY",
    input_0."SUM_ITEM_VOLUME",
    input_0."INBOUND_BOOKING",
    input_0."DOCK_IN",
    input_0."DOCK_OUT",
    input_0."GATE_IN",
    input_0."GATE_OUT",
    input_0."DYNAMIC_OPERATION",
    input_0."SCHEDULE_STATUS_CD",
    input_0."NF_MOTHER_AMOUNT",
    input_0."UNIT",
    input_0."REMESSA_NF_1",
    input_0."REMESSA_NF_SERIE",
    input_1."ORDER_NO" AS "OD_ORDERS_ORDER_NO",
    input_1."TRANSPORT_ID"
  FROM "layer_0_LEFT_OD_ORDERS_LOC" AS input_0
  LEFT OUTER JOIN "OW_SEDA_S".SDI_TSS_OD_ORDERS AS input_1
    ON input_0."NF_OD_DO_NO" = input_1."ORDER_NO"
  )
     ORDER BY "NF_OD_DO_NO"
    SEGMENTED BY HASH("NF_OD_DO_NO") ALL NODES
  ;

  -- Node: LEFT_TC_ORDERS
  PERFORM DROP TABLE IF EXISTS "layer_0_LEFT_TC_ORDERS" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_LEFT_TC_ORDERS" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."ONE",
    input_0."REMESSA_NF",
    input_0."OD_INBOUND_DETAIL_LPAD_ITEM_NO",
    input_0."OD_INBOUND_SN_NO",
    input_0."OD_ORDERS_ORDER_NO",
    input_0."OD_INBOUND_CONTAINER",
    input_0."OD_INBOUND_BL",
    input_0."SCHEDULE_STATUS_NM",
    input_0."EMAIL_SEND_YN",
    input_0."EMAIL_LIST",
    input_0."DELIVERY_TYPE",
    input_0."SUB_TRANS_TYPE",
    input_0."WH_ARRIVAL_DATE",
    input_0."INVOICE_NO",
    input_0."SHIPPING_POINT_CD",
    input_0."OD_INBOUND_SO",
    input_0."VESSEL_CD",
    input_0."TRANS_CD",
    input_0."WH_CD",
    input_0."NF_MOTHER_SERIE",
    input_0."NF_MOTHER_NO",
    input_0."ETD_FROM_PORT_DATE",
    input_0."LAST_CANCEL_SCHEDULE_DATE",
    input_0."LAST_SCHEDULE_DATE",
    input_0."TC_INBOUND_REMESSA_NF_SERIE",
    input_0."NF_EXT_NO",
    input_0."NF_SERIES",
    input_0."INSERT_DATE",
    input_0."NF_TOT_AMT1",
    input_0."DIVISION_CD",
    input_0."UNIT_PRICE",
    input_0."PLANT",
    input_0."STORAGE_LOCATION",
    input_0."NF_TOT_AMT2",
    input_0."NF_EXT_NO_PARENT",
    input_0."MNF_NO",
    input_0."CNH",
    input_0."LICENSE_PLATE",
    input_0."DRIVER_NM",
    input_0."TC_INBOUND_PRIORITY",
    input_0."TRUCK_TYPE",
    input_0."SEAL_NO",
    input_0."ITEM_CD",
    input_0."ITEM_QTY",
    input_0."SUM_ITEM_VOLUME",
    input_0."INBOUND_BOOKING",
    input_0."NF_OD_DO_NO",
    input_0."TRANSPORT_ID",
    input_0."DOCK_IN",
    input_0."DOCK_OUT",
    input_0."GATE_IN",
    input_0."GATE_OUT",
    input_0."DYNAMIC_OPERATION",
    input_0."SCHEDULE_STATUS_CD",
    input_0."NF_MOTHER_AMOUNT",
    input_0."UNIT",
    input_0."REMESSA_NF_1",
    input_0."REMESSA_NF_SERIE",
    input_1."IOD_DT",
    input_1."IOD_TIME",
    input_1."IOD_DT" || input_1."IOD_TIME" AS "IOD_DATE"
  FROM "layer_0_LEFT_OD_ORDERS" AS input_0
  LEFT OUTER JOIN "OW_SEDA_S".SDI_TSS_TC_ORDERS AS input_1
    ON input_0."NF_OD_DO_NO" = input_1."ORDER_NO"
  )
     ORDER BY "REMESSA_NF_1", "REMESSA_NF_SERIE"
    SEGMENTED BY HASH("REMESSA_NF_1", "REMESSA_NF_SERIE") ALL NODES
  ;

  -- Node: DISTINCT_PRIORITY
  PERFORM DROP TABLE IF EXISTS "layer_0_DISTINCT_PRIORITY" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_DISTINCT_PRIORITY" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    "CODE_CD",
    "PRIORITY"
  FROM (
    SELECT
      "CODE_CD",
      "PRIORITY",
      ROW_NUMBER() OVER (PARTITION BY "PRIORITY" ORDER BY "CODE_CD" DESC) AS _rn
    FROM (
      SELECT
        "CODE_NM" AS "PRIORITY",
        "CODE_TYPE_CD",
        "CODE_CD"
      FROM "OW_SEDA_S".SDI_TSS_M_CODE
    ) AS _rank_src
  ) AS _ranked
  WHERE
    _rn = 1
  )
     ORDER BY "CODE_CD"
    SEGMENTED BY HASH("CODE_CD") ALL NODES
  ;

  -- Node: DISTINCT_CODE_NM
  PERFORM DROP TABLE IF EXISTS "layer_0_DISTINCT_CODE_NM" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_DISTINCT_CODE_NM" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    "CODE_CD",
    "TRUCK_TYPE_NM"
  FROM (
    SELECT
      "CODE_CD",
      "TRUCK_TYPE_NM",
      ROW_NUMBER() OVER (PARTITION BY "TRUCK_TYPE_NM" ORDER BY "CODE_CD" DESC) AS _rn
    FROM (
      SELECT
        "CODE_CD",
        "CODE_TYPE_CD",
        "CODE_NM" AS "TRUCK_TYPE_NM"
      FROM "OW_SEDA_S".SDI_TSS_M_CODE
    ) AS _rank_src
  ) AS _ranked
  WHERE
    _rn = 1
  )
     ORDER BY "CODE_CD"
    SEGMENTED BY HASH("CODE_CD") ALL NODES
  ;

  -- Layer 1: 7 nodes

  -- Node: LEFT_NF_ORDERS
  PERFORM DROP TABLE IF EXISTS "layer_1_LEFT_NF_ORDERS" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_LEFT_NF_ORDERS" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."REMESSA_NF",
    input_0."ONE",
    input_0."OD_INBOUND_DETAIL_LPAD_ITEM_NO",
    input_0."OD_INBOUND_SN_NO",
    input_0."OD_ORDERS_ORDER_NO",
    input_0."OD_INBOUND_CONTAINER",
    input_0."OD_INBOUND_BL",
    input_0."SCHEDULE_STATUS_NM",
    input_0."EMAIL_SEND_YN",
    input_0."EMAIL_LIST",
    input_0."DELIVERY_TYPE",
    input_0."SUB_TRANS_TYPE",
    input_0."WH_ARRIVAL_DATE",
    input_0."INVOICE_NO",
    input_0."SHIPPING_POINT_CD",
    input_0."OD_INBOUND_SO",
    input_0."VESSEL_CD",
    input_0."TRANS_CD",
    input_0."WH_CD",
    input_0."NF_MOTHER_SERIE",
    input_0."NF_MOTHER_NO",
    input_0."ETD_FROM_PORT_DATE",
    input_0."LAST_CANCEL_SCHEDULE_DATE",
    input_0."LAST_SCHEDULE_DATE",
    input_0."TC_INBOUND_REMESSA_NF_SERIE",
    input_0."NF_EXT_NO",
    input_0."NF_SERIES",
    input_0."INSERT_DATE",
    input_0."NF_TOT_AMT1",
    input_0."DIVISION_CD",
    input_0."UNIT_PRICE",
    input_0."PLANT",
    input_0."STORAGE_LOCATION",
    input_0."NF_TOT_AMT2",
    input_0."NF_EXT_NO_PARENT",
    input_0."MNF_NO",
    input_0."CNH",
    input_0."LICENSE_PLATE",
    input_0."DRIVER_NM",
    input_0."TC_INBOUND_PRIORITY",
    input_0."TRUCK_TYPE",
    input_0."SEAL_NO",
    input_0."ITEM_CD",
    input_0."ITEM_QTY",
    input_0."SUM_ITEM_VOLUME",
    input_0."INBOUND_BOOKING",
    input_0."NF_OD_DO_NO",
    input_0."TRANSPORT_ID",
    input_0."DOCK_IN",
    input_0."DOCK_OUT",
    input_0."GATE_IN",
    input_0."GATE_OUT",
    input_0."IOD_DATE",
    input_0."DYNAMIC_OPERATION",
    input_0."SCHEDULE_STATUS_CD",
    input_0."NF_MOTHER_AMOUNT",
    input_0."UNIT",
    input_1."NF_INT_NO",
    input_1."NF_CHILD_SERIE",
    input_1."NF_CHILD_NO",
    input_1."NF_CHILD_AMOUNT",
    input_1."NF_EXT_NO_CHILD",
    input_1."NF_TOT_AMT2_CHILD"
  FROM "layer_0_LEFT_TC_ORDERS" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "DO_NO",
      "NF_EXT_NO" AS "NF_CHILD_NO",
      "NF_SERIES" AS "NF_CHILD_SERIE",
      "NF_INT_NO",
      "REF_NF_SERIES",
      "NF_TOT_AMT2" AS "NF_CHILD_AMOUNT",
      "NF_EXT_NO" AS "NF_EXT_NO_CHILD",
      "NF_TOT_AMT2" AS "NF_TOT_AMT2_CHILD",
      "NF_EXT_NO",
      "NF_SERIES"
    FROM "OW_SEDA_S".SDI_TSS_NF_OD_ORDERS
  ) AS input_1
    ON input_0."REMESSA_NF_1" = input_1."NF_EXT_NO"
    AND input_0."REMESSA_NF_SERIE" = input_1."NF_SERIES"
  )
     ORDER BY "NF_INT_NO", "OD_INBOUND_DETAIL_LPAD_ITEM_NO"
    SEGMENTED BY HASH("NF_INT_NO", "OD_INBOUND_DETAIL_LPAD_ITEM_NO") ALL NODES
  ;

  -- Node: LEFT_NF_OD_ORDERS_DETAIL
  PERFORM DROP TABLE IF EXISTS "layer_1_LEFT_NF_OD_ORDERS_DETAIL" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_LEFT_NF_OD_ORDERS_DETAIL" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."NF_INT_NO",
    input_0."ONE",
    input_0."OD_INBOUND_SN_NO",
    input_0."OD_ORDERS_ORDER_NO",
    input_0."OD_INBOUND_CONTAINER",
    input_0."OD_INBOUND_BL",
    input_0."SCHEDULE_STATUS_NM",
    input_0."EMAIL_SEND_YN",
    input_0."EMAIL_LIST",
    input_0."DELIVERY_TYPE",
    input_0."SUB_TRANS_TYPE",
    input_0."WH_ARRIVAL_DATE",
    input_0."INVOICE_NO",
    input_0."SHIPPING_POINT_CD",
    input_0."OD_INBOUND_SO",
    input_0."VESSEL_CD",
    input_0."TRANS_CD",
    input_0."WH_CD",
    input_0."NF_MOTHER_SERIE",
    input_0."NF_MOTHER_NO",
    input_0."ETD_FROM_PORT_DATE",
    input_0."LAST_CANCEL_SCHEDULE_DATE",
    input_0."LAST_SCHEDULE_DATE",
    input_0."TC_INBOUND_REMESSA_NF_SERIE",
    input_0."NF_EXT_NO",
    input_0."NF_SERIES",
    input_0."INSERT_DATE",
    input_0."NF_TOT_AMT1",
    input_0."NF_CHILD_SERIE",
    input_0."NF_CHILD_NO",
    input_0."NF_CHILD_AMOUNT",
    input_0."DIVISION_CD",
    input_0."UNIT_PRICE",
    input_0."PLANT",
    input_0."STORAGE_LOCATION",
    input_0."NF_TOT_AMT2",
    input_0."NF_EXT_NO_PARENT",
    input_0."NF_EXT_NO_CHILD",
    input_0."NF_TOT_AMT2_CHILD",
    input_0."MNF_NO",
    input_0."CNH",
    input_0."LICENSE_PLATE",
    input_0."DRIVER_NM",
    input_0."TC_INBOUND_PRIORITY",
    input_0."TRUCK_TYPE",
    input_0."SEAL_NO",
    input_0."ITEM_CD",
    input_0."ITEM_QTY",
    input_0."SUM_ITEM_VOLUME",
    input_0."INBOUND_BOOKING",
    input_0."NF_OD_DO_NO",
    input_0."TRANSPORT_ID",
    input_0."DOCK_IN",
    input_0."DOCK_OUT",
    input_0."GATE_IN",
    input_0."GATE_OUT",
    input_0."IOD_DATE",
    input_0."DYNAMIC_OPERATION",
    input_0."SCHEDULE_STATUS_CD",
    input_0."NF_MOTHER_AMOUNT",
    input_0."UNIT",
    input_0."OD_INBOUND_DETAIL_LPAD_ITEM_NO",
    input_0."REMESSA_NF",
    input_1."UNIT_PRICE_NF",
    input_1."NF_ITEM_NO"
  FROM "layer_1_LEFT_NF_ORDERS" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "NF_INT_NO",
      "NF_ITEM_NO",
      "UNIT_PRICE" AS "UNIT_PRICE_NF"
    FROM "OW_SEDA_S".SDI_TSS_NF_OD_ORDERS_DETAIL
  ) AS input_1
    ON input_0."NF_INT_NO" = input_1."NF_INT_NO"
    AND input_0."OD_INBOUND_DETAIL_LPAD_ITEM_NO" = input_1."NF_ITEM_NO"
  )
     ORDER BY "ONE"
    SEGMENTED BY HASH("ONE") ALL NODES
  ;

  -- Node: LEFT_SUB_BIZ_TYPE
  PERFORM DROP TABLE IF EXISTS "layer_1_LEFT_SUB_BIZ_TYPE" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_LEFT_SUB_BIZ_TYPE" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."ONE",
    input_0."OD_INBOUND_SN_NO",
    input_0."OD_ORDERS_ORDER_NO",
    input_0."OD_INBOUND_CONTAINER",
    input_0."OD_INBOUND_BL",
    input_0."SCHEDULE_STATUS_NM",
    input_0."EMAIL_SEND_YN",
    input_0."EMAIL_LIST",
    input_0."DELIVERY_TYPE",
    input_0."SUB_TRANS_TYPE",
    input_0."WH_ARRIVAL_DATE",
    input_0."INVOICE_NO",
    input_0."SHIPPING_POINT_CD",
    input_0."OD_INBOUND_SO",
    input_0."VESSEL_CD",
    input_0."TRANS_CD",
    input_0."WH_CD",
    input_0."NF_MOTHER_SERIE",
    input_0."NF_MOTHER_NO",
    input_0."ETD_FROM_PORT_DATE",
    input_0."LAST_CANCEL_SCHEDULE_DATE",
    input_0."LAST_SCHEDULE_DATE",
    input_0."TC_INBOUND_REMESSA_NF_SERIE",
    input_0."NF_EXT_NO",
    input_0."NF_SERIES",
    input_0."INSERT_DATE",
    input_0."NF_TOT_AMT1",
    input_0."NF_CHILD_SERIE",
    input_0."NF_CHILD_NO",
    input_0."NF_CHILD_AMOUNT",
    input_0."DIVISION_CD",
    input_0."UNIT_PRICE",
    input_0."PLANT",
    input_0."STORAGE_LOCATION",
    input_0."NF_TOT_AMT2",
    input_0."UNIT_PRICE_NF",
    input_0."NF_ITEM_NO",
    input_0."NF_EXT_NO_PARENT",
    input_0."NF_EXT_NO_CHILD",
    input_0."NF_TOT_AMT2_CHILD",
    input_0."MNF_NO",
    input_0."CNH",
    input_0."LICENSE_PLATE",
    input_0."DRIVER_NM",
    input_0."TC_INBOUND_PRIORITY",
    input_0."TRUCK_TYPE",
    input_0."SEAL_NO",
    input_0."ITEM_CD",
    input_0."ITEM_QTY",
    input_0."SUM_ITEM_VOLUME",
    input_0."INBOUND_BOOKING",
    input_0."NF_OD_DO_NO",
    input_0."TRANSPORT_ID",
    input_0."DOCK_IN",
    input_0."DOCK_OUT",
    input_0."GATE_IN",
    input_0."GATE_OUT",
    input_0."IOD_DATE",
    input_0."DYNAMIC_OPERATION",
    input_0."SCHEDULE_STATUS_CD",
    input_0."NF_MOTHER_AMOUNT",
    input_0."UNIT",
    input_0."OD_INBOUND_DETAIL_LPAD_ITEM_NO",
    input_0."REMESSA_NF",
    input_1."CODE_NM" AS "BIZ_TYPE",
    input_1."INNER_ONE"
  FROM "layer_1_LEFT_NF_OD_ORDERS_DETAIL" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "CODE_NM",
      "CODE_CD",
      1 AS "INNER_ONE"
    FROM "OW_SEDA_S".SDI_TSS_M_CODE
  ) AS input_1
    ON input_0."ONE" = input_1."INNER_ONE"
  )
     ORDER BY "TC_INBOUND_PRIORITY"
    SEGMENTED BY HASH("TC_INBOUND_PRIORITY") ALL NODES
  ;

  -- Node: LEFT_SUB_PRIORITY
  PERFORM DROP TABLE IF EXISTS "layer_1_LEFT_SUB_PRIORITY" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_LEFT_SUB_PRIORITY" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."ONE",
    input_0."BIZ_TYPE",
    input_0."OD_INBOUND_SN_NO",
    input_0."OD_ORDERS_ORDER_NO",
    input_0."OD_INBOUND_CONTAINER",
    input_0."OD_INBOUND_BL",
    input_0."SCHEDULE_STATUS_NM",
    input_0."EMAIL_SEND_YN",
    input_0."EMAIL_LIST",
    input_0."DELIVERY_TYPE",
    input_0."SUB_TRANS_TYPE",
    input_0."WH_ARRIVAL_DATE",
    input_0."INVOICE_NO",
    input_0."SHIPPING_POINT_CD",
    input_0."OD_INBOUND_SO",
    input_0."VESSEL_CD",
    input_0."TRANS_CD",
    input_0."WH_CD",
    input_0."NF_MOTHER_SERIE",
    input_0."NF_MOTHER_NO",
    input_0."ETD_FROM_PORT_DATE",
    input_0."LAST_CANCEL_SCHEDULE_DATE",
    input_0."LAST_SCHEDULE_DATE",
    input_0."TC_INBOUND_REMESSA_NF_SERIE",
    input_0."NF_EXT_NO",
    input_0."NF_SERIES",
    input_0."INSERT_DATE",
    input_0."NF_TOT_AMT1",
    input_0."NF_CHILD_SERIE",
    input_0."NF_CHILD_NO",
    input_0."NF_CHILD_AMOUNT",
    input_0."DIVISION_CD",
    input_0."UNIT_PRICE",
    input_0."PLANT",
    input_0."STORAGE_LOCATION",
    input_0."NF_TOT_AMT2",
    input_0."UNIT_PRICE_NF",
    input_0."NF_ITEM_NO",
    input_0."NF_EXT_NO_PARENT",
    input_0."NF_EXT_NO_CHILD",
    input_0."NF_TOT_AMT2_CHILD",
    input_0."MNF_NO",
    input_0."CNH",
    input_0."LICENSE_PLATE",
    input_0."DRIVER_NM",
    input_0."TC_INBOUND_PRIORITY",
    input_0."TRUCK_TYPE",
    input_0."SEAL_NO",
    input_0."ITEM_CD",
    input_0."ITEM_QTY",
    input_0."SUM_ITEM_VOLUME",
    input_0."INBOUND_BOOKING",
    input_0."NF_OD_DO_NO",
    input_0."TRANSPORT_ID",
    input_0."DOCK_IN",
    input_0."DOCK_OUT",
    input_0."GATE_IN",
    input_0."GATE_OUT",
    input_0."IOD_DATE",
    input_0."DYNAMIC_OPERATION",
    input_0."SCHEDULE_STATUS_CD",
    input_0."NF_MOTHER_AMOUNT",
    input_0."UNIT",
    input_0."OD_INBOUND_DETAIL_LPAD_ITEM_NO",
    input_0."REMESSA_NF",
    input_1."PRIORITY"
  FROM "layer_1_LEFT_SUB_BIZ_TYPE" AS input_0
  LEFT OUTER JOIN "layer_0_DISTINCT_PRIORITY" AS input_1
    ON input_0."TC_INBOUND_PRIORITY" = input_1."CODE_CD"
  )
     ORDER BY "TRUCK_TYPE"
    SEGMENTED BY HASH("TRUCK_TYPE") ALL NODES
  ;

  -- Node: LEFT_SUB_TRUCK_TYPE_NM
  PERFORM DROP TABLE IF EXISTS "layer_1_LEFT_SUB_TRUCK_TYPE_NM" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_LEFT_SUB_TRUCK_TYPE_NM" ON COMMIT PRESERVE ROWS AS 
  SELECT
    input_0."ONE",
    input_0."BIZ_TYPE",
    input_0."OD_INBOUND_SN_NO",
    input_0."OD_ORDERS_ORDER_NO",
    input_0."OD_INBOUND_CONTAINER",
    input_0."OD_INBOUND_BL",
    input_0."SCHEDULE_STATUS_NM",
    input_0."EMAIL_SEND_YN",
    input_0."EMAIL_LIST",
    input_0."DELIVERY_TYPE",
    input_0."SUB_TRANS_TYPE",
    input_0."WH_ARRIVAL_DATE",
    input_0."INVOICE_NO",
    input_0."SHIPPING_POINT_CD",
    input_0."OD_INBOUND_SO",
    input_0."VESSEL_CD",
    input_0."TRANS_CD",
    input_0."WH_CD",
    input_0."NF_MOTHER_SERIE",
    input_0."NF_MOTHER_NO",
    input_0."ETD_FROM_PORT_DATE",
    input_0."LAST_CANCEL_SCHEDULE_DATE",
    input_0."LAST_SCHEDULE_DATE",
    input_0."TC_INBOUND_REMESSA_NF_SERIE",
    input_0."NF_EXT_NO",
    input_0."NF_SERIES",
    input_0."INSERT_DATE",
    input_0."NF_TOT_AMT1",
    input_0."NF_CHILD_SERIE",
    input_0."NF_CHILD_NO",
    input_0."NF_CHILD_AMOUNT",
    input_0."DIVISION_CD",
    input_0."UNIT_PRICE",
    input_0."PLANT",
    input_0."STORAGE_LOCATION",
    input_0."NF_TOT_AMT2",
    input_0."UNIT_PRICE_NF",
    input_0."NF_ITEM_NO",
    input_0."NF_EXT_NO_PARENT",
    input_0."NF_EXT_NO_CHILD",
    input_0."NF_TOT_AMT2_CHILD",
    input_0."MNF_NO",
    input_0."CNH",
    input_0."LICENSE_PLATE",
    input_0."DRIVER_NM",
    input_0."TC_INBOUND_PRIORITY",
    input_0."PRIORITY",
    input_0."TRUCK_TYPE",
    input_0."SEAL_NO",
    input_0."ITEM_CD",
    input_0."ITEM_QTY",
    input_0."SUM_ITEM_VOLUME",
    input_0."INBOUND_BOOKING",
    input_0."NF_OD_DO_NO",
    input_0."TRANSPORT_ID",
    input_0."DOCK_IN",
    input_0."DOCK_OUT",
    input_0."GATE_IN",
    input_0."GATE_OUT",
    input_0."IOD_DATE",
    input_0."DYNAMIC_OPERATION",
    input_0."SCHEDULE_STATUS_CD",
    input_0."NF_MOTHER_AMOUNT",
    input_0."UNIT",
    input_0."OD_INBOUND_DETAIL_LPAD_ITEM_NO",
    input_0."REMESSA_NF",
    input_1."TRUCK_TYPE_NM"
  FROM "layer_1_LEFT_SUB_PRIORITY" AS input_0
  LEFT OUTER JOIN "layer_0_DISTINCT_CODE_NM" AS input_1
    ON input_0."TRUCK_TYPE" = input_1."CODE_CD"
  ;

  -- Node: Projection_1
  PERFORM DROP TABLE IF EXISTS "layer_1_Projection_1" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_Projection_1" ON COMMIT PRESERVE ROWS AS 
  SELECT
    "DYNAMIC_OPERATION",
    "OD_ORDERS_ORDER_NO",
    "BIZ_TYPE",
    "OD_INBOUND_SN_NO",
    "OD_INBOUND_CONTAINER",
    "OD_INBOUND_BL",
    "SCHEDULE_STATUS_NM",
    "SCHEDULE_STATUS_CD",
    "EMAIL_SEND_YN",
    "EMAIL_LIST",
    "DELIVERY_TYPE",
    "SUB_TRANS_TYPE",
    "UNIT_PRICE",
    "PLANT",
    "STORAGE_LOCATION",
    "NF_MOTHER_SERIE",
    "NF_MOTHER_NO",
    "NF_MOTHER_AMOUNT",
    "NF_CHILD_SERIE",
    "NF_CHILD_NO",
    "NF_CHILD_AMOUNT_NEW" AS "NF_CHILD_AMOUNT",
    "ETD_FROM_PORT_DATE",
    "WH_ARRIVAL_DATE",
    "INVOICE_NO",
    "DIVISION_CD",
    "UNIT",
    "NF_TOT_AMT1",
    "NF_TOT_AMT2",
    "UNIT_PRICE_NF",
    "SHIPPING_POINT_CD",
    "INSERT_DATE",
    "OD_INBOUND_SO",
    "NF_ITEM_NO",
    "NF_SERIES",
    "NF_EXT_NO",
    "VESSEL_CD",
    "NF_EXT_NO_PARENT",
    "NF_EXT_NO_CHILD",
    "NF_TOT_AMT2_CHILD_NEW" AS "NF_TOT_AMT2_CHILD",
    "TRANS_CD",
    "WH_CD",
    "MNF_NO",
    "CNH",
    "LICENSE_PLATE",
    "DRIVER_NM",
    "PRIORITY",
    "TRUCK_TYPE",
    "TRUCK_TYPE_NM",
    "SEAL_NO",
    "ITEM_CD",
    "ITEM_QTY",
    "SUM_ITEM_VOLUME",
    "INBOUND_BOOKING",
    "DOCK_IN",
    "DOCK_OUT",
    "GATE_IN",
    "GATE_OUT",
    "IOD_DATE",
    "OD_INBOUND_DETAIL_LPAD_ITEM_NO" AS "XX",
    "TRANSPORT_ID",
    "TC_INBOUND_REMESSA_NF_SERIE",
    "TC_INBOUND_PRIORITY",
    "REMESSA_NF",
    "ONE",
    "LAST_CANCEL_SCHEDULE_DATE",
    "LAST_SCHEDULE_DATE",
    "NF_OD_DO_NO",
    '00020' AS "BIZ_TYPE_CD",
    COALESCE("TRANSPORT_ID", "OD_INBOUND_CONTAINER") AS "INBOUND_CONTAINER",
    'TESTE' AS "TESTE"
  FROM (
    SELECT
      "ONE",
      "BIZ_TYPE",
      "OD_INBOUND_SN_NO",
      "OD_ORDERS_ORDER_NO",
      "OD_INBOUND_CONTAINER",
      "OD_INBOUND_BL",
      "SCHEDULE_STATUS_NM",
      "EMAIL_SEND_YN",
      "EMAIL_LIST",
      "DELIVERY_TYPE",
      "SUB_TRANS_TYPE",
      "WH_ARRIVAL_DATE",
      "INVOICE_NO",
      "SHIPPING_POINT_CD",
      "OD_INBOUND_SO",
      "VESSEL_CD",
      "TRANS_CD",
      "WH_CD",
      "NF_MOTHER_SERIE",
      "NF_MOTHER_NO",
      "ETD_FROM_PORT_DATE",
      "LAST_CANCEL_SCHEDULE_DATE",
      "LAST_SCHEDULE_DATE",
      "TC_INBOUND_REMESSA_NF_SERIE",
      "NF_EXT_NO",
      "NF_SERIES",
      "INSERT_DATE",
      "NF_TOT_AMT1",
      "NF_CHILD_SERIE",
      "NF_CHILD_NO",
      "NF_CHILD_AMOUNT",
      "DIVISION_CD",
      "UNIT_PRICE",
      "PLANT",
      "STORAGE_LOCATION",
      "NF_TOT_AMT2",
      "UNIT_PRICE_NF",
      "NF_ITEM_NO",
      "NF_EXT_NO_PARENT",
      "NF_EXT_NO_CHILD",
      "NF_TOT_AMT2_CHILD",
      "MNF_NO",
      "CNH",
      "LICENSE_PLATE",
      "DRIVER_NM",
      "TC_INBOUND_PRIORITY",
      "PRIORITY",
      "TRUCK_TYPE",
      "SEAL_NO",
      "ITEM_CD",
      "ITEM_QTY",
      "SUM_ITEM_VOLUME",
      "INBOUND_BOOKING",
      "NF_OD_DO_NO",
      "TRANSPORT_ID",
      "TRUCK_TYPE_NM",
      "DOCK_IN",
      "DOCK_OUT",
      "GATE_IN",
      "GATE_OUT",
      "IOD_DATE",
      "DYNAMIC_OPERATION",
      "SCHEDULE_STATUS_CD",
      "NF_MOTHER_AMOUNT",
      "UNIT",
      "OD_INBOUND_DETAIL_LPAD_ITEM_NO",
      "REMESSA_NF",
      "NF_CHILD_AMOUNT" AS "NF_CHILD_AMOUNT_NEW",
      "NF_TOT_AMT2_CHILD" AS "NF_TOT_AMT2_CHILD_NEW"
    FROM "layer_1_LEFT_SUB_TRUCK_TYPE_NM"
  ) AS Projection
  ;

  -- Materialize final result
  PERFORM CREATE TABLE IF NOT EXISTS OW_SEDA_S.VIEWCV_CV_TSS_IOD_TRACKING_INBOUND_OD_INBOUND AS
    SELECT * FROM "layer_1_Projection_1" WHERE 1=0;
  PERFORM TRUNCATE TABLE OW_SEDA_S.VIEWCV_CV_TSS_IOD_TRACKING_INBOUND_OD_INBOUND;
  PERFORM INSERT INTO OW_SEDA_S.VIEWCV_CV_TSS_IOD_TRACKING_INBOUND_OD_INBOUND
  SELECT * FROM "layer_1_Projection_1";

  PERFORM COMMIT;
  RAISE NOTICE 'Successfully loaded OW_SEDA_S.VIEWCV_CV_TSS_IOD_TRACKING_INBOUND_OD_INBOUND';

END;
$$;