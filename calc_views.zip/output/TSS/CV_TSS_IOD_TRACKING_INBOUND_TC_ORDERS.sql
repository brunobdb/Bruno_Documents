-- Migrated from HANA Calculation View: OW_SEDA_S.VIEWCV_CV_TSS_IOD_TRACKING_INBOUND_TC_ORDERS
-- Description: CV_TSS_IOD_TRACKING_INBOUND_TC_

CREATE OR REPLACE PROCEDURE OW_SEDA_S.load_VIEWCV_CV_TSS_IOD_TRACKING_INBOUND_TC_ORDERS()
LANGUAGE PLvSQL AS $$
BEGIN

  -- Layer 0: 37 nodes

  -- Node: INNER_OD_ORDERS
  PERFORM DROP TABLE IF EXISTS "layer_0_INNER_OD_ORDERS" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_INNER_OD_ORDERS" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."TC_ORDER_NO",
    input_0."ONE",
    input_0."CONTAINER",
    input_0."SUB_TRANS_TYPE",
    input_0."IOD_DATE",
    input_1."OD_COALESCE_DYNAMIC_OPERATION",
    input_1."SN_NO",
    input_1."OD_ORDER_NO",
    input_1."DELIVERY_TYPE",
    input_1."WH_ARRIVAL_DATE",
    input_1."TRANS_CD",
    input_1."WH_CD",
    input_1."TRANSPORT_ID"
  FROM (
    SELECT
      "ORDER_NO" AS "TC_ORDER_NO",
      "ORDER_CLASS",
      "ERP_ORDER_CLASS",
      "CONTAINER_NO" AS "CONTAINER",
      "SUB_TRANS_TYPE",
      "IOD_DT",
      "IOD_TIME",
      1 AS "ONE",
      "IOD_DT" || "IOD_TIME" AS "IOD_DATE"
    FROM "OW_SEDA_S".SDI_TSS_TC_ORDERS
  ) AS input_0
  INNER JOIN (
    SELECT
      "DYNAMIC_OPERATION",
      "ORDER_NO" AS "OD_ORDER_NO",
      "ORDER_NO" AS "SN_NO",
      "DELIVERY_TYPE",
      "WH_ARRIVAL_DATE",
      "TRANS_CD_INB" AS "TRANS_CD",
      "WH_CD",
      "TRANSPORT_ID",
      COALESCE("DYNAMIC_OPERATION", 'N') AS "OD_COALESCE_DYNAMIC_OPERATION"
    FROM "OW_SEDA_S".SDI_TSS_OD_ORDERS
  ) AS input_1
    ON input_0."TC_ORDER_NO" = input_1."OD_ORDER_NO"
  )
     ORDER BY "TC_ORDER_NO"
    SEGMENTED BY HASH("TC_ORDER_NO") ALL NODES
  ;

  -- Node: INNER_OD_ORDERS_DETAIL
  PERFORM DROP TABLE IF EXISTS "layer_0_INNER_OD_ORDERS_DETAIL" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_INNER_OD_ORDERS_DETAIL" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."TC_ORDER_NO",
    input_0."OD_COALESCE_DYNAMIC_OPERATION",
    input_0."ONE",
    input_0."CONTAINER",
    input_0."SN_NO",
    input_0."OD_ORDER_NO",
    input_0."DELIVERY_TYPE",
    input_0."SUB_TRANS_TYPE",
    input_0."WH_ARRIVAL_DATE",
    input_0."TRANS_CD",
    input_0."WH_CD",
    input_0."TRANSPORT_ID",
    input_0."IOD_DATE",
    input_1."ORDER_NO" AS "OOD_ORDER_NO",
    input_1."ITEM_CD",
    input_1."ORDER_CNT" AS "ITEM_QTY"
  FROM "layer_0_INNER_OD_ORDERS" AS input_0
  INNER JOIN "OW_SEDA_S".SDI_TSS_OD_ORDERS_DETAIL AS input_1
    ON input_0."TC_ORDER_NO" = input_1."ORDER_NO"
  )
     ORDER BY "TC_ORDER_NO"
    SEGMENTED BY HASH("TC_ORDER_NO") ALL NODES
  ;

  -- Node: INNER_RS_RESULT_LOC
  PERFORM DROP TABLE IF EXISTS "layer_0_INNER_RS_RESULT_LOC" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_INNER_RS_RESULT_LOC" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."TC_ORDER_NO",
    input_0."OD_COALESCE_DYNAMIC_OPERATION",
    input_0."ONE",
    input_0."CONTAINER",
    input_0."SN_NO",
    input_0."OD_ORDER_NO",
    input_0."DELIVERY_TYPE",
    input_0."SUB_TRANS_TYPE",
    input_0."WH_ARRIVAL_DATE",
    input_0."TRANS_CD",
    input_0."WH_CD",
    input_0."TRANSPORT_ID",
    input_0."IOD_DATE",
    input_0."ITEM_CD",
    input_0."ITEM_QTY",
    input_1."ORDER_NO" AS "RSL_ORDER_NO"
  FROM "layer_0_INNER_OD_ORDERS_DETAIL" AS input_0
  INNER JOIN "OW_SEDA_S".SDI_TSS_RS_RESULT_LOC AS input_1
    ON input_0."TC_ORDER_NO" = input_1."ORDER_NO"
  )
     ORDER BY "TC_ORDER_NO"
    SEGMENTED BY HASH("TC_ORDER_NO") ALL NODES
  ;

  -- Node: LEFT_TC_SCHEDULE_ORDER
  PERFORM DROP TABLE IF EXISTS "layer_0_LEFT_TC_SCHEDULE_ORDER" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_LEFT_TC_SCHEDULE_ORDER" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."TC_ORDER_NO",
    input_0."OD_COALESCE_DYNAMIC_OPERATION",
    input_0."ONE",
    input_0."CONTAINER",
    input_0."SN_NO",
    input_0."OD_ORDER_NO",
    input_0."DELIVERY_TYPE",
    input_0."SUB_TRANS_TYPE",
    input_0."WH_ARRIVAL_DATE",
    input_0."TRANS_CD",
    input_0."WH_CD",
    input_0."TRANSPORT_ID",
    input_0."IOD_DATE",
    input_0."ITEM_CD",
    input_0."ITEM_QTY",
    input_1."SCHEDULE_STATUS_CD",
    input_1."EMAIL_SEND_YN",
    input_1."EMAIL_LIST",
    input_1."MNF_NO",
    input_1."CNH",
    input_1."LICENSE_PLATE",
    input_1."DRIVER_NM",
    input_1."JOIN_PRIORITY"
  FROM "layer_0_INNER_RS_RESULT_LOC" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "DEL_YN",
      "ORDER_NO" AS "SO_ORDER_NO",
      "SCHEDULE_STATUS_CD",
      "EMAIL_SEND_YN",
      "EMAIL_LIST",
      "MNF_NO",
      "CNH",
      "LICENSE_PLATE",
      "DRIVER_NM",
      "PRIORITY" AS "JOIN_PRIORITY"
    FROM "OW_SEDA_S".SDI_TSS_TC_SCHEDULE_ORDER
  ) AS input_1
    ON input_0."TC_ORDER_NO" = input_1."SO_ORDER_NO"
  )
     ORDER BY "SCHEDULE_STATUS_CD"
    SEGMENTED BY HASH("SCHEDULE_STATUS_CD") ALL NODES
  ;

  -- Node: LEFT_M_CODE
  PERFORM DROP TABLE IF EXISTS "layer_0_LEFT_M_CODE" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_LEFT_M_CODE" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."SCHEDULE_STATUS_CD",
    input_0."TC_ORDER_NO",
    input_0."OD_COALESCE_DYNAMIC_OPERATION",
    input_0."ONE",
    input_0."CONTAINER",
    input_0."SN_NO",
    input_0."OD_ORDER_NO",
    input_0."EMAIL_SEND_YN",
    input_0."EMAIL_LIST",
    input_0."DELIVERY_TYPE",
    input_0."SUB_TRANS_TYPE",
    input_0."WH_ARRIVAL_DATE",
    input_0."TRANS_CD",
    input_0."WH_CD",
    input_0."MNF_NO",
    input_0."CNH",
    input_0."LICENSE_PLATE",
    input_0."DRIVER_NM",
    input_0."JOIN_PRIORITY",
    input_0."TRANSPORT_ID",
    input_0."IOD_DATE",
    input_0."ITEM_CD",
    input_0."ITEM_QTY",
    input_1."M_CODE_NM"
  FROM "layer_0_LEFT_TC_SCHEDULE_ORDER" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "CODE_CD" AS "M_CODE_CD",
      "CODE_TYPE_CD",
      "CODE_NM" AS "M_CODE_NM"
    FROM "OW_SEDA_S".SDI_TSS_M_CODE
  ) AS input_1
    ON input_0."SCHEDULE_STATUS_CD" = input_1."M_CODE_CD"
  )
     ORDER BY "TC_ORDER_NO"
    SEGMENTED BY HASH("TC_ORDER_NO") ALL NODES
  ;

  -- Node: LEFT_TC_INBOUND
  PERFORM DROP TABLE IF EXISTS "layer_0_LEFT_TC_INBOUND" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_LEFT_TC_INBOUND" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."TC_ORDER_NO",
    input_0."OD_COALESCE_DYNAMIC_OPERATION",
    input_0."ONE",
    input_0."CONTAINER",
    input_0."SN_NO",
    input_0."OD_ORDER_NO",
    input_0."EMAIL_SEND_YN",
    input_0."EMAIL_LIST",
    input_0."SCHEDULE_STATUS_CD",
    input_0."M_CODE_NM",
    input_0."DELIVERY_TYPE",
    input_0."SUB_TRANS_TYPE",
    input_0."WH_ARRIVAL_DATE",
    input_0."TRANS_CD",
    input_0."WH_CD",
    input_0."MNF_NO",
    input_0."CNH",
    input_0."LICENSE_PLATE",
    input_0."DRIVER_NM",
    input_0."JOIN_PRIORITY",
    input_0."TRANSPORT_ID",
    input_0."IOD_DATE",
    input_0."ITEM_CD",
    input_0."ITEM_QTY",
    input_1."SN_NO" AS "TCI_SN_NO",
    input_1."REMESSA_NF" AS "TCI_REMESSA_NF",
    input_1."REMESSA_NF_SERIE" AS "TCI_REMESSA_NF_SERIE",
    input_1."NF_MOTHER_SERIE",
    input_1."NF_MOTHER_NO",
    input_1."INBOUND_BOOKING",
    input_1."INBOUND_CONTAINER",
    input_1."WH_DOCK_DATE_TIME",
    input_1."WH_DOCK_OUT_DATE_TIME",
    input_1."WH_GATE_IN_DATE_TIME",
    input_1."WH_GATE_OUT_DATE_TIME",
    input_1."TRUCK_TYPE"
  FROM "layer_0_LEFT_M_CODE" AS input_0
  LEFT OUTER JOIN "OW_SEDA_S".SDI_TSS_TC_INBOUND AS input_1
    ON input_0."TC_ORDER_NO" = input_1."SN_NO"
  )
     ORDER BY "TCI_SN_NO"
    SEGMENTED BY HASH("TCI_SN_NO") ALL NODES
  ;

  -- Node: LEFT_NF_OD_ORDERS_NF_OD
  PERFORM DROP TABLE IF EXISTS "layer_0_LEFT_NF_OD_ORDERS_NF_OD" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_LEFT_NF_OD_ORDERS_NF_OD" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."TCI_REMESSA_NF",
    input_0."TCI_REMESSA_NF_SERIE",
    input_0."OD_COALESCE_DYNAMIC_OPERATION",
    input_0."ONE",
    input_0."CONTAINER",
    input_0."SN_NO",
    input_0."OD_ORDER_NO",
    input_0."EMAIL_SEND_YN",
    input_0."EMAIL_LIST",
    input_0."SCHEDULE_STATUS_CD",
    input_0."M_CODE_NM",
    input_0."DELIVERY_TYPE",
    input_0."SUB_TRANS_TYPE",
    input_0."NF_MOTHER_SERIE",
    input_0."NF_MOTHER_NO",
    input_0."WH_ARRIVAL_DATE",
    input_0."TRANS_CD",
    input_0."WH_CD",
    input_0."MNF_NO",
    input_0."CNH",
    input_0."LICENSE_PLATE",
    input_0."DRIVER_NM",
    input_0."JOIN_PRIORITY",
    input_0."INBOUND_BOOKING",
    input_0."TRANSPORT_ID",
    input_0."INBOUND_CONTAINER",
    input_0."WH_DOCK_DATE_TIME",
    input_0."WH_DOCK_OUT_DATE_TIME",
    input_0."WH_GATE_IN_DATE_TIME",
    input_0."WH_GATE_OUT_DATE_TIME",
    input_0."IOD_DATE",
    input_0."ITEM_CD",
    input_0."ITEM_QTY",
    input_0."TCI_SN_NO",
    input_1."DO_NO"
  FROM "layer_0_LEFT_TC_INBOUND" AS input_0
  LEFT OUTER JOIN "OW_SEDA_S".SDI_TSS_NF_OD_ORDERS AS input_1
    ON input_0."TCI_SN_NO" = input_1."NF_INT_NO"
  )
     ORDER BY "TCI_REMESSA_NF", "TCI_REMESSA_NF_SERIE"
    SEGMENTED BY HASH("TCI_REMESSA_NF", "TCI_REMESSA_NF_SERIE") ALL NODES
  ;

  -- Node: LEFT_NF_OD_ORDERS_NFO
  PERFORM DROP TABLE IF EXISTS "layer_0_LEFT_NF_OD_ORDERS_NFO" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_LEFT_NF_OD_ORDERS_NFO" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."OD_COALESCE_DYNAMIC_OPERATION",
    input_0."ONE",
    input_0."CONTAINER",
    input_0."SN_NO",
    input_0."OD_ORDER_NO",
    input_0."EMAIL_SEND_YN",
    input_0."EMAIL_LIST",
    input_0."SCHEDULE_STATUS_CD",
    input_0."M_CODE_NM",
    input_0."DELIVERY_TYPE",
    input_0."SUB_TRANS_TYPE",
    input_0."NF_MOTHER_SERIE",
    input_0."NF_MOTHER_NO",
    input_0."WH_ARRIVAL_DATE",
    input_0."TCI_REMESSA_NF",
    input_0."TCI_REMESSA_NF_SERIE",
    input_0."TRANS_CD",
    input_0."WH_CD",
    input_0."MNF_NO",
    input_0."CNH",
    input_0."LICENSE_PLATE",
    input_0."DRIVER_NM",
    input_0."JOIN_PRIORITY",
    input_0."INBOUND_BOOKING",
    input_0."TRANSPORT_ID",
    input_0."INBOUND_CONTAINER",
    input_0."WH_DOCK_DATE_TIME",
    input_0."WH_DOCK_OUT_DATE_TIME",
    input_0."WH_GATE_IN_DATE_TIME",
    input_0."WH_GATE_OUT_DATE_TIME",
    input_0."IOD_DATE",
    input_0."ITEM_CD",
    input_0."ITEM_QTY",
    input_0."DO_NO",
    input_1."NFO_NF_INT_NO",
    input_1."NF_MOTHER_AMOUNT",
    input_1."NF_TOT_AMT1",
    input_1."NF_TOT_AMT2",
    input_1."XX"
  FROM "layer_0_LEFT_NF_OD_ORDERS_NF_OD" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "DO_NO",
      "NF_EXT_NO" AS "NFO_NF_EXT_NO",
      "NF_SERIES" AS "NFO_NF_SERIES",
      "NF_INT_NO" AS "NFO_NF_INT_NO",
      "NF_TOT_AMT1" AS "NF_MOTHER_AMOUNT",
      "NF_TOT_AMT1",
      "NF_TOT_AMT2",
      "NF_INT_NO" AS "XX"
    FROM "OW_SEDA_S".SDI_TSS_NF_OD_ORDERS
  ) AS input_1
    ON input_0."TCI_REMESSA_NF" = input_1."NFO_NF_EXT_NO"
    AND input_0."TCI_REMESSA_NF_SERIE" = input_1."NFO_NF_SERIES"
  )
     ORDER BY "NFO_NF_INT_NO"
    SEGMENTED BY HASH("NFO_NF_INT_NO") ALL NODES
  ;

  -- Node: LEFT_NF_OD_ORDERS_DETAIL
  PERFORM DROP TABLE IF EXISTS "layer_0_LEFT_NF_OD_ORDERS_DETAIL" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_LEFT_NF_OD_ORDERS_DETAIL" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."OD_COALESCE_DYNAMIC_OPERATION",
    input_0."ONE",
    input_0."CONTAINER",
    input_0."SN_NO",
    input_0."OD_ORDER_NO",
    input_0."EMAIL_SEND_YN",
    input_0."EMAIL_LIST",
    input_0."SCHEDULE_STATUS_CD",
    input_0."M_CODE_NM",
    input_0."DELIVERY_TYPE",
    input_0."SUB_TRANS_TYPE",
    input_0."NF_MOTHER_SERIE",
    input_0."NF_MOTHER_NO",
    input_0."NF_MOTHER_AMOUNT",
    input_0."WH_ARRIVAL_DATE",
    input_0."NF_TOT_AMT1",
    input_0."NF_TOT_AMT2",
    input_0."TCI_REMESSA_NF",
    input_0."TCI_REMESSA_NF_SERIE",
    input_0."TRANS_CD",
    input_0."WH_CD",
    input_0."MNF_NO",
    input_0."CNH",
    input_0."LICENSE_PLATE",
    input_0."DRIVER_NM",
    input_0."JOIN_PRIORITY",
    input_0."INBOUND_BOOKING",
    input_0."TRANSPORT_ID",
    input_0."INBOUND_CONTAINER",
    input_0."WH_DOCK_DATE_TIME",
    input_0."WH_DOCK_OUT_DATE_TIME",
    input_0."WH_GATE_IN_DATE_TIME",
    input_0."WH_GATE_OUT_DATE_TIME",
    input_0."XX",
    input_0."IOD_DATE",
    input_0."ITEM_CD",
    input_0."ITEM_QTY",
    input_0."DO_NO",
    input_0."NFO_NF_INT_NO",
    input_1."UNIT_PRICE" AS "UNIT_PRICE_NF"
  FROM "layer_0_LEFT_NF_OD_ORDERS_NFO" AS input_0
  LEFT OUTER JOIN "OW_SEDA_S".SDI_TSS_NF_OD_ORDERS_DETAIL AS input_1
    ON input_0."NFO_NF_INT_NO" = input_1."NF_INT_NO"
  )
     ORDER BY "ONE"
    SEGMENTED BY HASH("ONE") ALL NODES
  ;

  -- Node: Rank
  PERFORM DROP TABLE IF EXISTS "layer_0_Rank" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Rank" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    "PRIORITY",
    "CODE_CD"
  FROM (
    SELECT
      "PRIORITY",
      "CODE_CD",
      ROW_NUMBER() OVER (PARTITION BY "PRIORITY" ORDER BY "CODE_CD" DESC) AS _rn
    FROM (
      SELECT
        "CODE_TYPE_CD",
        "CODE_NM" AS "PRIORITY",
        "CODE_CD"
      FROM "OW_SEDA_S".SDI_TSS_M_CODE
    ) AS _rank_src
  ) AS _ranked
  WHERE
    _rn = 1
  )
     ORDER BY "CODE_CD"
    SEGMENTED BY HASH("CODE_CD") ALL NODES
  ;

  -- Layer 1: 4 nodes

  -- Node: LEFT_SUB_BIZ_TYPE
  PERFORM DROP TABLE IF EXISTS "layer_1_LEFT_SUB_BIZ_TYPE" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_LEFT_SUB_BIZ_TYPE" ON COMMIT PRESERVE ROWS AS 
  SELECT
    input_0."ONE",
    input_0."OD_COALESCE_DYNAMIC_OPERATION",
    input_0."CONTAINER",
    input_0."SN_NO",
    input_0."OD_ORDER_NO",
    input_0."EMAIL_SEND_YN",
    input_0."EMAIL_LIST",
    input_0."SCHEDULE_STATUS_CD",
    input_0."M_CODE_NM",
    input_0."DELIVERY_TYPE",
    input_0."SUB_TRANS_TYPE",
    input_0."NF_MOTHER_SERIE",
    input_0."NF_MOTHER_NO",
    input_0."NF_MOTHER_AMOUNT",
    input_0."WH_ARRIVAL_DATE",
    input_0."NF_TOT_AMT1",
    input_0."NF_TOT_AMT2",
    input_0."UNIT_PRICE_NF",
    input_0."TCI_REMESSA_NF",
    input_0."TCI_REMESSA_NF_SERIE",
    input_0."TRANS_CD",
    input_0."WH_CD",
    input_0."MNF_NO",
    input_0."CNH",
    input_0."LICENSE_PLATE",
    input_0."DRIVER_NM",
    input_0."JOIN_PRIORITY",
    input_0."INBOUND_BOOKING",
    input_0."TRANSPORT_ID",
    input_0."INBOUND_CONTAINER",
    input_0."WH_DOCK_DATE_TIME",
    input_0."WH_DOCK_OUT_DATE_TIME",
    input_0."WH_GATE_IN_DATE_TIME",
    input_0."WH_GATE_OUT_DATE_TIME",
    input_0."XX",
    input_0."IOD_DATE",
    input_0."ITEM_CD",
    input_0."ITEM_QTY",
    input_0."DO_NO",
    input_1."CODE_NM",
    1 AS "COUNT_1"
  FROM "layer_0_LEFT_NF_OD_ORDERS_DETAIL" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "CODE_NM",
      "CODE_CD",
      "CODE_TYPE_CD",
      1 AS "JOIN_ONE"
    FROM "OW_SEDA_S".SDI_TSS_M_CODE
  ) AS input_1
    ON input_0."ONE" = input_1."JOIN_ONE"
  ;

  -- Node: LFET_SUB_PRIORITY
  PERFORM DROP TABLE IF EXISTS "layer_1_LFET_SUB_PRIORITY" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_LFET_SUB_PRIORITY" ON COMMIT PRESERVE ROWS AS 
  SELECT
    input_0."JOIN_PRIORITY",
    input_0."ONE",
    input_0."DYNAMIC_OPERATION",
    input_0."ORDER_NO",
    input_0."BIZ_TYPE",
    input_0."CONTAINER",
    input_0."SN_NO",
    input_0."EMAIL_SEND_YN",
    input_0."EMAIL_LIST",
    input_0."SCHEDULE_STATUS_CD",
    input_0."M_CODE_NM",
    input_0."DELIVERY_TYPE",
    input_0."SUB_TRANS_TYPE",
    input_0."NF_MOTHER_SERIE",
    input_0."NF_MOTHER_NO",
    input_0."NF_MOTHER_AMOUNT",
    input_0."WH_ARRIVAL_DATE",
    input_0."NF_TOT_AMT1",
    input_0."NF_TOT_AMT2",
    input_0."UNIT_PRICE_NF",
    input_0."NF_EXT_NO",
    input_0."NF_SERIES",
    input_0."TRANS_CD",
    input_0."WH_CD",
    input_0."MNF_NO",
    input_0."CNH",
    input_0."LICENSE_PLATE",
    input_0."DRIVER_NM",
    input_0."JOIN_PRIORITY" AS "JOIN_PRIORITY_1",
    input_0."BIZ_TYPE_CD",
    input_0."BL",
    input_0."SCHEDULE_STATUS_NM",
    input_0."UNIT_PRICE",
    input_0."PLANT",
    input_0."STORAGE_LOCATION",
    input_0."NF_CHILD_SERIE",
    input_0."NF_CHILD_NO",
    input_0."NF_CHILD_AMOUNT",
    input_0."ETD_FROM_PORT_DATE",
    input_0."INVOICE_NO20",
    input_0."DIVISION_CD",
    input_0."UNIT",
    input_0."SHIPPING_POINT_CD",
    input_0."INSERT_DATE",
    input_0."SO",
    input_0."NF_ITEM_NO",
    input_0."VESSEL_CD",
    input_0."NF_EXT_NO_PARENT",
    input_0."NF_EXT_NO_CHILD",
    input_0."NF_TOT_AMT2_CHILD",
    input_0."TRUCK_TYPE",
    input_0."INBOUND_BOOKING",
    input_0."TRANSPORT_ID",
    input_0."INBOUND_CONTAINER",
    input_0."XX",
    input_0."IOD_DATE",
    input_0."ITEM_CD",
    input_0."ITEM_QTY",
    input_0."DOCK_IN",
    input_0."DOCK_OUT",
    input_0."GATE_IN",
    input_0."GATE_OUT",
    input_0."TRUCK_TYPE_NM",
    input_0."SEAL_NO",
    input_0."SUM_ITEM_VOLUME",
    input_0."DO_NO",
    input_1."PRIORITY"
  FROM (
    SELECT
      "ONE",
      "OD_COALESCE_DYNAMIC_OPERATION" AS "DYNAMIC_OPERATION",
      "OD_ORDER_NO" AS "ORDER_NO",
      "CODE_NM" AS "BIZ_TYPE",
      "CONTAINER",
      "SN_NO",
      "EMAIL_SEND_YN",
      "EMAIL_LIST",
      "SCHEDULE_STATUS_CD",
      "M_CODE_NM",
      "DELIVERY_TYPE",
      "SUB_TRANS_TYPE",
      "NF_MOTHER_SERIE",
      "NF_MOTHER_NO",
      "NF_MOTHER_AMOUNT",
      "WH_ARRIVAL_DATE",
      "NF_TOT_AMT1",
      "NF_TOT_AMT2",
      "UNIT_PRICE_NF",
      "TCI_REMESSA_NF" AS "NF_EXT_NO",
      "TCI_REMESSA_NF_SERIE" AS "NF_SERIES",
      "TRANS_CD",
      "WH_CD",
      "MNF_NO",
      "CNH",
      "LICENSE_PLATE",
      "DRIVER_NM",
      "JOIN_PRIORITY",
      "INBOUND_BOOKING",
      "TRANSPORT_ID",
      "INBOUND_CONTAINER",
      "XX",
      "IOD_DATE",
      "ITEM_CD",
      "ITEM_QTY",
      "WH_DOCK_DATE_TIME" AS "DOCK_IN",
      "WH_DOCK_OUT_DATE_TIME" AS "DOCK_OUT",
      "WH_GATE_IN_DATE_TIME" AS "GATE_IN",
      "WH_GATE_OUT_DATE_TIME" AS "GATE_OUT",
      "DO_NO",
      '00010' AS "BIZ_TYPE_CD",
      '' AS "BL",
      CASE "SCHEDULE_STATUS_CD" WHEN NULL THEN 'Not Scheduled' ELSE "M_CODE_NM" END AS "SCHEDULE_STATUS_NM",
      0 AS "UNIT_PRICE",
      ' ' AS "PLANT",
      ' ' AS "STORAGE_LOCATION",
      ' ' AS "NF_CHILD_SERIE",
      ' ' AS "NF_CHILD_NO",
      0 AS "NF_CHILD_AMOUNT",
      NULL AS "ETD_FROM_PORT_DATE",
      ' ' AS "INVOICE_NO20",
      ' ' AS "DIVISION_CD",
      ' ' AS "UNIT",
      ' ' AS "SHIPPING_POINT_CD",
      NOW() AS "INSERT_DATE",
      ' ' AS "SO",
      ' ' AS "NF_ITEM_NO",
      ' ' AS "VESSEL_CD",
      ' ' AS "NF_EXT_NO_PARENT",
      ' ' AS "NF_EXT_NO_CHILD",
      0 AS "NF_TOT_AMT2_CHILD",
      ' ' AS "TRUCK_TYPE",
      ' ' AS "TRUCK_TYPE_NM",
      ' ' AS "SEAL_NO",
      0 AS "SUM_ITEM_VOLUME",
      COALESCE("TRANSPORT_ID", "INBOUND_CONTAINER") AS "COALESCE_INBOUND_CONTAINER"
    FROM "layer_1_LEFT_SUB_BIZ_TYPE"
  ) AS input_0
  LEFT OUTER JOIN "layer_0_Rank" AS input_1
    ON input_0."JOIN_PRIORITY" = input_1."CODE_CD"
  ;

  -- Node: Projection_1
  PERFORM DROP TABLE IF EXISTS "layer_1_Projection_1" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_Projection_1" ON COMMIT PRESERVE ROWS AS 
  SELECT
    "BIZ_TYPE_CD",
    "DYNAMIC_OPERATION",
    "ORDER_NO",
    "BIZ_TYPE",
    "SN_NO",
    "CONTAINER",
    "BL",
    "SCHEDULE_STATUS_NM",
    "SCHEDULE_STATUS_CD",
    "EMAIL_SEND_YN",
    "EMAIL_LIST",
    "DELIVERY_TYPE",
    "SUB_TRANS_TYPE",
    "UNIT_PRICE",
    "PLANT",
    "STORAGE_LOCATION",
    "NF_MOTHER_SERIE",
    "NF_MOTHER_NO",
    "NF_MOTHER_AMOUNT",
    "NF_CHILD_SERIE",
    "NF_CHILD_NO",
    "NF_CHILD_AMOUNT",
    "ETD_FROM_PORT_DATE",
    "WH_ARRIVAL_DATE",
    "INVOICE_NO20",
    "DIVISION_CD",
    "UNIT",
    "NF_TOT_AMT1",
    "NF_TOT_AMT2",
    "UNIT_PRICE_NF",
    "SHIPPING_POINT_CD",
    "INSERT_DATE",
    "SO",
    "NF_ITEM_NO",
    "NF_SERIES",
    "NF_EXT_NO",
    "VESSEL_CD",
    "NF_EXT_NO_PARENT",
    "NF_EXT_NO_CHILD",
    "NF_TOT_AMT2_CHILD",
    "TRANS_CD",
    "WH_CD",
    "MNF_NO",
    "CNH",
    "LICENSE_PLATE",
    "DRIVER_NM",
    "PRIORITY",
    "TRUCK_TYPE",
    "TRUCK_TYPE_NM",
    "SEAL_NO",
    "ITEM_CD",
    "ITEM_QTY",
    "SUM_ITEM_VOLUME",
    "INBOUND_BOOKING",
    "INBOUND_CONTAINER",
    "DOCK_IN",
    "DOCK_OUT",
    "GATE_IN",
    "GATE_OUT",
    "IOD_DATE",
    "XX",
    "ONE",
    "JOIN_PRIORITY",
    "M_CODE_NM",
    "JOIN_PRIORITY_1",
    "TRANSPORT_ID",
    "DO_NO",
    'TESTE' AS "TESTE"
  FROM "layer_1_LFET_SUB_PRIORITY"
  ;

  -- Materialize final result
  PERFORM CREATE TABLE IF NOT EXISTS OW_SEDA_S.VIEWCV_CV_TSS_IOD_TRACKING_INBOUND_TC_ORDERS AS
    SELECT * FROM "layer_1_Projection_1" WHERE 1=0;
  PERFORM TRUNCATE TABLE OW_SEDA_S.VIEWCV_CV_TSS_IOD_TRACKING_INBOUND_TC_ORDERS;
  PERFORM INSERT INTO OW_SEDA_S.VIEWCV_CV_TSS_IOD_TRACKING_INBOUND_TC_ORDERS
  SELECT * FROM "layer_1_Projection_1";

  PERFORM COMMIT;
  RAISE NOTICE 'Successfully loaded OW_SEDA_S.VIEWCV_CV_TSS_IOD_TRACKING_INBOUND_TC_ORDERS';

END;
$$;