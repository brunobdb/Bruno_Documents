CREATE OR REPLACE VIEW "OW_SEDA_S.VIEWCV_CV_TSS_IOD_TRACKING_ITEM" AS
SELECT
  "COUNT"
FROM (
  SELECT
    input_0."COUNT"
  FROM (
    SELECT
      input_0."TC_ORDERS_ORDER_NO",
      input_0."COUNT"
    FROM (
      SELECT
        input_0."COUNT",
        input_0."TC_ORDERS_ORDER_NO",
        input_1."TRANS_CD"
      FROM (
        SELECT
          input_0."COUNT",
          input_0."TC_ORDERS_ORDER_NO"
        FROM (
          SELECT
            input_0."COUNT",
            input_0."DESTINATION_CD",
            input_0."TC_ORDERS_ORDER_NO"
          FROM (
            SELECT
              input_0."COUNT",
              input_0."BOOKING_AT_HUB_LOCATION_GID",
              input_0."DESTINATION_CD",
              input_0."TC_ORDERS_ORDER_NO"
            FROM (
              SELECT
                input_0."TC_ORDERS_ORDER_NO",
                input_0."COUNT",
                input_0."BOOKING_AT_HUB_LOCATION_GID",
                input_0."DESTINATION_CD"
              FROM (
                SELECT
                  input_0."TC_ORDERS_ORDER_NO",
                  input_0."COUNT",
                  input_0."BOOKING_AT_HUB_LOCATION_GID",
                  input_0."DESTINATION_CD",
                  input_1."FOLLOW_UP_CD"
                FROM (
                  SELECT
                    input_0."COUNT",
                    input_0."FOLLOW_UP_STATUS_SEQ",
                    input_0."TC_ORDERS_ORDER_NO",
                    input_0."BOOKING_AT_HUB_LOCATION_GID",
                    input_0."DESTINATION_CD"
                  FROM (
                    SELECT
                      input_0."COUNT",
                      input_0."FOLLOW_UP_STATUS_SEQ",
                      input_0."TC_ORDERS_ORDER_NO",
                      input_0."BOOKING_AT_HUB_LOCATION_GID",
                      input_0."DESTINATION_CD",
                      input_1."DIVISION_CD"
                    FROM (
                      SELECT
                        input_0."COUNT",
                        input_0."FOLLOW_UP_STATUS_SEQ",
                        input_0."TC_ORDERS_ORDER_NO",
                        input_0."BOOKING_AT_HUB_LOCATION_GID",
                        input_0."DESTINATION_CD",
                        input_1."ITEM_CD"
                      FROM (
                        SELECT
                          input_0."TC_ORDERS_ORDER_NO",
                          input_0."COUNT",
                          input_0."FOLLOW_UP_STATUS_SEQ",
                          input_0."BOOKING_AT_HUB_LOCATION_GID",
                          input_0."DESTINATION_CD"
                        FROM (
                          SELECT
                            input_0."COUNT",
                            input_0."TC_ORDERS_ORDER_NO",
                            input_0."FOLLOW_UP_STATUS_SEQ",
                            input_0."BOOKING_AT_HUB_LOCATION_GID",
                            input_0."DESTINATION_CD"
                          FROM (
                            SELECT
                              input_0."COUNT",
                              input_0."TC_ORDERS_ORDER_NO",
                              input_0."FOLLOW_UP_STATUS_SEQ",
                              input_0."BOOKING_AT_HUB_LOCATION_GID",
                              input_0."DESTINATION_CD",
                              input_1."DISPATCH_GROUP_NO"
                            FROM (
                              SELECT
                                input_0."COUNT",
                                input_0."TC_ORDERS_ORDER_NO",
                                input_0."FOLLOW_UP_STATUS_SEQ",
                                input_0."BOOKING_AT_HUB_LOCATION_GID",
                                input_0."DESTINATION_CD",
                                input_1."DISPATCH_NO"
                              FROM (
                                SELECT
                                  input_0."TC_ORDERS_ORDER_NO",
                                  input_0."COUNT",
                                  input_0."FOLLOW_UP_STATUS_SEQ",
                                  input_0."BOOKING_AT_HUB_LOCATION_GID",
                                  input_1."DESTINATION_CD"
                                FROM (
                                  SELECT
                                    input_0."TC_ORDERS_ORDER_NO",
                                    input_0."COUNT",
                                    input_0."FOLLOW_UP_STATUS_SEQ",
                                    input_0."BOOKING_AT_HUB_LOCATION_GID"
                                  FROM (
                                    SELECT
                                      "ORDER_NO" AS "TC_ORDERS_ORDER_NO",
                                      "FOLLOW_UP_STATUS_SEQ",
                                      "BOOKING_AT_HUB_LOCATION_GID",
                                      1 AS "COUNT"
                                    FROM "OW_SEDA_S".ODS_TSS_TC_ORDERS
                                  ) AS input_0
                                  INNER JOIN "OW_SEDA_S".ODS_TSS_OD_ORDERS_LOC AS input_1
                                    ON input_0."TC_ORDERS_ORDER_NO" = input_1."ORDER_NO"
                                ) AS input_0
                                INNER JOIN "OW_SEDA_S".ODS_TSS_OD_ORDERS AS input_1
                                  ON input_0."TC_ORDERS_ORDER_NO" = input_1."ORDER_NO"
                              ) AS input_0
                              LEFT OUTER JOIN "OW_SEDA_S".ODS_TSS_RS_RESULT_LOC AS input_1
                                ON input_0."TC_ORDERS_ORDER_NO" = input_1."ORDER_NO"
                            ) AS input_0
                            LEFT OUTER JOIN "OW_SEDA_S".ODS_TSS_RS_RESULT AS input_1
                              ON input_0."DISPATCH_NO" = input_1."DISPATCH_NO"
                          ) AS input_0
                          LEFT OUTER JOIN "OW_SEDA_S".ODS_TSS_RS_RESULT_GROUP AS input_1
                            ON input_0."DISPATCH_GROUP_NO" = input_1."DISPATCH_GROUP_NO"
                        ) AS input_0
                        LEFT OUTER JOIN "OW_SEDA_S".ODS_TSS_BOOKING_UPDATE_LOG AS input_1
                          ON input_0."TC_ORDERS_ORDER_NO" = input_1."DO_ID"
                      ) AS input_0
                      LEFT OUTER JOIN "OW_SEDA_S".ODS_TSS_OD_ORDERS_DETAIL AS input_1
                        ON input_0."TC_ORDERS_ORDER_NO" = input_1."ORDER_NO"
                    ) AS input_0
                    LEFT OUTER JOIN "OW_SEDA_S".ODS_TSS_M_ITEM AS input_1
                      ON input_0."ITEM_CD" = input_1."ITEM_CD"
                  ) AS input_0
                  LEFT OUTER JOIN "OW_SEDA_S".ODS_TSS_M_DIVISION AS input_1
                    ON input_0."DIVISION_CD" = input_1."DIVISION_CD"
                ) AS input_0
                LEFT OUTER JOIN "OW_SEDA_S".ODS_TSS_TC_FOLLOW_UP_STATUS AS input_1
                  ON input_0."FOLLOW_UP_STATUS_SEQ" = input_1."FOLLOW_UP_STATUS_SEQ"
                  AND input_0."TC_ORDERS_ORDER_NO" = input_1."ORDER_NO"
              ) AS input_0
              LEFT OUTER JOIN "OW_SEDA_S".ODS_TSS_M_FOLLOW_UP_STATUS AS input_1
                ON input_0."FOLLOW_UP_CD" = input_1."FOLLOW_UP_CD"
            ) AS input_0
            LEFT OUTER JOIN (
              SELECT
                "DELETE_YN",
                "DO_NO"
              FROM "OW_SEDA_S".ODS_TSS_NF_OD_ORDERS
            ) AS input_1
              ON input_0."TC_ORDERS_ORDER_NO" = input_1."DO_NO"
          ) AS input_0
          LEFT OUTER JOIN "OW_SEDA_S".ODS_TSS_M_LOCATION AS input_1
            ON input_0."BOOKING_AT_HUB_LOCATION_GID" = input_1."LOCATION_GID"
        ) AS input_0
        LEFT OUTER JOIN "OW_SEDA_S".ODS_TSS_M_LOCATION AS input_1
          ON input_0."DESTINATION_CD" = input_1."LOCATION_CD"
      ) AS input_0
      LEFT OUTER JOIN "OW_SEDA_S".ODS_TSS_TB_MVW_TC_LEG_PLANNING AS input_1
        ON input_0."TC_ORDERS_ORDER_NO" = input_1."ORDER_NO"
    ) AS input_0
    LEFT OUTER JOIN "OW_SEDA_S".ODS_TSS_M_TRANS AS input_1
      ON input_0."TRANS_CD" = input_1."TRANS_CD"
  ) AS input_0
  LEFT OUTER JOIN "OW_SEDA_S".ODS_TSS_TC_EVENT_DATE AS input_1
    ON input_0."TC_ORDERS_ORDER_NO" = input_1."ORDER_NO"
) AS LEFT_TC_EVENT_DATE