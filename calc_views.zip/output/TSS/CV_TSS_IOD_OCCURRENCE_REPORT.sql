-- Migrated from HANA Calculation View: OW_SEDA_S.VIEWCV_CV_TSS_IOD_OCCURRENCE_REPORT
-- Description: CV_TSS_IOD_OCCURRENCE_REPORT

CREATE OR REPLACE PROCEDURE OW_SEDA_S.load_VIEWCV_CV_TSS_IOD_OCCURRENCE_REPORT()
LANGUAGE PLvSQL AS $$
BEGIN

  -- Layer 0: 65 nodes

  -- Node: LF_TC_CUSTOMER_REJECT
  PERFORM DROP TABLE IF EXISTS "layer_0_LF_TC_CUSTOMER_REJECT" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_LF_TC_CUSTOMER_REJECT" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."DO_NO",
    input_0."EVENT_CODE_TC_OCCURRENCE",
    input_0."REMARKS",
    input_0."OCCURRENCE_VALID",
    input_0."INSERT_DT_ID",
    input_0."INSERT_ID",
    input_0."OCCURRENCE_DT",
    input_1."VALIDATE_ID",
    input_1."VALIDATE_DATE"
  FROM (
    SELECT
      "SEQ",
      "EVENT_CODE" AS "EVENT_CODE_TC_OCCURRENCE",
      "DO_NO",
      "INSERT_ID",
      "REMARKS" AS "REMARKS_TC_OCCURRENCE",
      "TRACKING_REMARK",
      "OCCURRENCE_VALID" AS "OCCURRENCE_VALID_TC_OCCURRENCE",
      "INSERT_DATE" AS "INSERT_DT_ID",
      "OCCUR_DATE",
      "OCCUR_TIME",
      CAST("SEQ" AS VARCHAR) AS "SEQ_LJ",
      CASE
        WHEN (
          "REMARKS_TC_OCCURRENCE"
        ) IS NULL
        THEN "TRACKING_REMARK"
        ELSE "REMARKS_TC_OCCURRENCE"
      END AS "REMARKS",
      CASE "OCCURRENCE_VALID_TC_OCCURRENCE" WHEN 'Y' THEN 'OK' WHEN 'N' THEN 'Not OK' END AS "OCCURRENCE_VALID",
      CONCAT("OCCUR_DATE", "OCCUR_TIME") AS "VALIDA_CONCAT",
      DATS_IS_VALID("VALIDA_CONCAT") AS "VALIDA_DATE",
      CASE "VALIDA_DATE" WHEN '1' THEN "VALIDA_CONCAT" WHEN '0' THEN '19000101000000' END AS "OCCURRENCE_DT_NVARCHAR",
      TO_DATE(("OCCURRENCE_DT_NVARCHAR")::VARCHAR, 'YYYY-MM-DD') AS "OCCURRENCE_DT"
    FROM "OW_SEDA_S".ODS_TSS_TC_OCCURRENCE
  ) AS input_0
  LEFT OUTER JOIN (
    SELECT
      "OCCUR_SEQ",
      "EVENT_CODE" AS "EVENT_CODE_TC_CUSTOMER_REJECT",
      "DELETE_YN",
      "INSERT_ID",
      "INSERT_DATE" AS "VALIDATE_DATE",
      "INSERT_ID" AS "VALIDATE_ID"
    FROM "OW_SEDA_S".ODS_TSS_TC_CUSTOMER_REJECT
  ) AS input_1
    ON input_0."SEQ_LJ" = input_1."OCCUR_SEQ"
  )
     ORDER BY "DO_NO"
    SEGMENTED BY HASH("DO_NO") ALL NODES
  ;

  -- Node: IN_OD_ORDERS
  PERFORM DROP TABLE IF EXISTS "layer_0_IN_OD_ORDERS" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_IN_OD_ORDERS" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."EVENT_CODE_TC_OCCURRENCE",
    input_0."VALIDATE_ID",
    input_0."REMARKS",
    input_0."OCCURRENCE_VALID",
    input_0."VALIDATE_DATE",
    input_0."INSERT_DT_ID",
    input_0."INSERT_ID",
    input_0."OCCURRENCE_DT",
    input_1."ORDER_NO_OD_ORDERS",
    input_1."MID_AREA_CD",
    input_1."SOURCE_CD",
    input_1."SOLD_TO_CD",
    input_1."SOLD_TO_NM",
    input_1."SHIP_TO",
    input_1."SHIP_TO_NAME",
    input_1."SHIPPING_TYPE",
    input_1."TRANS_CD_OD_ORDERS",
    input_1."UDF10",
    input_1."HEADER_DIVISION_CD_OD_ORDERS"
  FROM "layer_0_LF_TC_CUSTOMER_REJECT" AS input_0
  INNER JOIN (
    SELECT
      "ORDER_NO" AS "ORDER_NO_OD_ORDERS",
      "MID_AREA_CD",
      "SOURCE_CD",
      "UDF10",
      "SOLD_TO_CD",
      "SOLD_TO_NM",
      "DESTINATION_CD" AS "SHIP_TO",
      "DESTINATION_NM" AS "SHIP_TO_NAME",
      "SUB_TRANS_TYPE" AS "SHIPPING_TYPE",
      "TRANS_CD" AS "TRANS_CD_OD_ORDERS",
      "HEADER_DIVISION_CD" AS "HEADER_DIVISION_CD_OD_ORDERS"
    FROM "OW_SEDA_S".ODS_TSS_OD_ORDERS
  ) AS input_1
    ON input_0."DO_NO" = input_1."ORDER_NO_OD_ORDERS"
  )
     ORDER BY "ORDER_NO_OD_ORDERS"
    SEGMENTED BY HASH("ORDER_NO_OD_ORDERS") ALL NODES
  ;

  -- Node: IN_TC_ORDERS
  PERFORM DROP TABLE IF EXISTS "layer_0_IN_TC_ORDERS" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_IN_TC_ORDERS" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."MID_AREA_CD",
    input_0."EVENT_CODE_TC_OCCURRENCE",
    input_0."ORDER_NO_OD_ORDERS",
    input_0."SOURCE_CD",
    input_0."SOLD_TO_CD",
    input_0."SOLD_TO_NM",
    input_0."SHIP_TO",
    input_0."SHIP_TO_NAME",
    input_0."SHIPPING_TYPE",
    input_0."TRANS_CD_OD_ORDERS",
    input_0."UDF10",
    input_0."VALIDATE_ID",
    input_0."REMARKS",
    input_0."OCCURRENCE_VALID",
    input_0."HEADER_DIVISION_CD_OD_ORDERS",
    input_0."VALIDATE_DATE",
    input_0."INSERT_DT_ID",
    input_0."INSERT_ID",
    input_0."OCCURRENCE_DT",
    input_1."ORDER_NO_TC_ORDERS"
  FROM "layer_0_IN_OD_ORDERS" AS input_0
  INNER JOIN (
    SELECT
      "ORDER_NO" AS "ORDER_NO_TC_ORDERS"
    FROM "OW_SEDA_S".ODS_TSS_TC_ORDERS
  ) AS input_1
    ON input_0."ORDER_NO_OD_ORDERS" = input_1."ORDER_NO_TC_ORDERS"
  )
     ORDER BY "MID_AREA_CD"
    SEGMENTED BY HASH("MID_AREA_CD") ALL NODES
  ;

  -- Node: IN_MID_AREA
  PERFORM DROP TABLE IF EXISTS "layer_0_IN_MID_AREA" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_IN_MID_AREA" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."EVENT_CODE_TC_OCCURRENCE",
    input_0."ORDER_NO_OD_ORDERS",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."SOURCE_CD",
    input_0."SOLD_TO_CD",
    input_0."SOLD_TO_NM",
    input_0."SHIP_TO",
    input_0."SHIP_TO_NAME",
    input_0."SHIPPING_TYPE",
    input_0."TRANS_CD_OD_ORDERS",
    input_0."UDF10",
    input_0."VALIDATE_ID",
    input_0."REMARKS",
    input_0."OCCURRENCE_VALID",
    input_0."HEADER_DIVISION_CD_OD_ORDERS",
    input_0."VALIDATE_DATE",
    input_0."INSERT_DT_ID",
    input_0."INSERT_ID",
    input_0."OCCURRENCE_DT",
    input_1."UF_TO"
  FROM "layer_0_IN_TC_ORDERS" AS input_0
  INNER JOIN (
    SELECT
      "MID_AREA_CD",
      "UN_SUBD_CD",
      "MID_AREA_NM",
      "UN_SUBD_CD" || ' - ' || "MID_AREA_NM" AS "UF_TO"
    FROM "OW_SEDA_S".ODS_TSS_M_MID_AREA
  ) AS input_1
    ON input_0."MID_AREA_CD" = input_1."MID_AREA_CD"
  )
     ORDER BY "EVENT_CODE_TC_OCCURRENCE"
    SEGMENTED BY HASH("EVENT_CODE_TC_OCCURRENCE") ALL NODES
  ;

  -- Node: IN_M_REASON
  PERFORM DROP TABLE IF EXISTS "layer_0_IN_M_REASON" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_IN_M_REASON" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."EVENT_CODE_TC_OCCURRENCE",
    input_0."ORDER_NO_OD_ORDERS",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."SOURCE_CD",
    input_0."SOLD_TO_CD",
    input_0."SOLD_TO_NM",
    input_0."SHIP_TO",
    input_0."SHIP_TO_NAME",
    input_0."SHIPPING_TYPE",
    input_0."TRANS_CD_OD_ORDERS",
    input_0."UDF10",
    input_0."VALIDATE_ID",
    input_0."REMARKS",
    input_0."UF_TO",
    input_0."OCCURRENCE_VALID",
    input_0."HEADER_DIVISION_CD_OD_ORDERS",
    input_0."VALIDATE_DATE",
    input_0."INSERT_DT_ID",
    input_0."INSERT_ID",
    input_0."OCCURRENCE_DT",
    input_1."REASON_PO_NM",
    input_1."REASON_NM",
    input_1."RESPONSIBLE_DELAY"
  FROM "layer_0_IN_MID_AREA" AS input_0
  INNER JOIN (
    SELECT
      "REASON_CD",
      "REASON_PO_NM",
      "REASON_NM",
      "RESPONSIBLE_DELAY"
    FROM "OW_SEDA_S".ODS_TSS_M_REASON
  ) AS input_1
    ON input_0."EVENT_CODE_TC_OCCURRENCE" = input_1."REASON_CD"
  )
     ORDER BY "EVENT_CODE_TC_OCCURRENCE"
    SEGMENTED BY HASH("EVENT_CODE_TC_OCCURRENCE") ALL NODES
  ;

  -- Node: IN_M_REASON_GRP
  PERFORM DROP TABLE IF EXISTS "layer_0_IN_M_REASON_GRP" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_IN_M_REASON_GRP" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."ORDER_NO_OD_ORDERS",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."SOURCE_CD",
    input_0."SOLD_TO_CD",
    input_0."SOLD_TO_NM",
    input_0."SHIP_TO",
    input_0."SHIP_TO_NAME",
    input_0."SHIPPING_TYPE",
    input_0."TRANS_CD_OD_ORDERS",
    input_0."UDF10",
    input_0."EVENT_CODE_TC_OCCURRENCE",
    input_0."REASON_PO_NM" AS "REASON_PO_NM_M_REASON",
    input_0."REASON_NM" AS "REASON_NM_M_REASON",
    input_0."RESPONSIBLE_DELAY",
    input_0."VALIDATE_ID",
    input_0."REMARKS",
    input_0."UF_TO",
    input_0."OCCURRENCE_VALID",
    input_0."HEADER_DIVISION_CD_OD_ORDERS",
    input_0."VALIDATE_DATE",
    input_0."INSERT_DT_ID",
    input_0."INSERT_ID",
    input_0."OCCURRENCE_DT",
    input_1."REASON_GRP_NM",
    input_1."RESP_DELAY",
    input_1."REASON_GRP_PO_NM",
    CASE
      WHEN (
        "REASON_PO_NM_M_REASON"
      ) IS NULL
      THEN input_1."REASON_GRP_PO_NM"
      ELSE "REASON_PO_NM_M_REASON"
    END AS "REASON_PO_NM",
    CASE
      WHEN (
        "REASON_NM_M_REASON"
      ) IS NULL
      THEN input_1."REASON_GRP_NM"
      ELSE "REASON_NM_M_REASON"
    END AS "REASON_NM",
    CASE
      WHEN (
        input_0."RESPONSIBLE_DELAY"
      ) IS NULL
      THEN input_1."RESP_DELAY"
      ELSE input_0."RESPONSIBLE_DELAY"
    END AS "IF_RESP_DELAY_NM"
  FROM "layer_0_IN_M_REASON" AS input_0
  INNER JOIN (
    SELECT
      "REASON_GRP_CD",
      "REASON_GRP_NM",
      "RESP_DELAY",
      "REASON_GRP_PO_NM"
    FROM "OW_SEDA_S".ODS_TSS_M_REASON_GRP
  ) AS input_1
    ON input_0."EVENT_CODE_TC_OCCURRENCE" = input_1."REASON_GRP_CD"
  )
     ORDER BY "HEADER_DIVISION_CD_OD_ORDERS"
    SEGMENTED BY HASH("HEADER_DIVISION_CD_OD_ORDERS") ALL NODES
  ;

  -- Node: IN_M_HEADER_DIVISION
  PERFORM DROP TABLE IF EXISTS "layer_0_IN_M_HEADER_DIVISION" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_IN_M_HEADER_DIVISION" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."ORDER_NO_OD_ORDERS",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."SOURCE_CD",
    input_0."SOLD_TO_CD",
    input_0."SOLD_TO_NM",
    input_0."SHIP_TO",
    input_0."SHIP_TO_NAME",
    input_0."SHIPPING_TYPE",
    input_0."TRANS_CD_OD_ORDERS",
    input_0."UDF10",
    input_0."EVENT_CODE_TC_OCCURRENCE",
    input_0."REASON_PO_NM",
    input_0."REASON_NM",
    input_0."VALIDATE_ID",
    input_0."REMARKS",
    input_0."UF_TO",
    input_0."OCCURRENCE_VALID",
    input_0."IF_RESP_DELAY_NM",
    input_0."VALIDATE_DATE",
    input_0."INSERT_DT_ID",
    input_0."INSERT_ID",
    input_0."OCCURRENCE_DT",
    input_1."HEADER_DIVISION_NM__M_HEADER_DIVISION" AS "HEADER_DIVISION_NM"
  FROM "layer_0_IN_M_REASON_GRP" AS input_0
  INNER JOIN (
    SELECT
      "HEADER_DIVISION_CD",
      "HEADER_DIVISION_NM" AS "HEADER_DIVISION_NM__M_HEADER_DIVISION"
    FROM "OW_SEDA_S".ODS_TSS_M_HEADER_DIVISION
  ) AS input_1
    ON input_0."HEADER_DIVISION_CD_OD_ORDERS" = input_1."HEADER_DIVISION_CD"
  )
     ORDER BY "ORDER_NO_OD_ORDERS"
    SEGMENTED BY HASH("ORDER_NO_OD_ORDERS") ALL NODES
  ;

  -- Node: IN_RS_RESULT_LOC
  PERFORM DROP TABLE IF EXISTS "layer_0_IN_RS_RESULT_LOC" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_IN_RS_RESULT_LOC" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."ORDER_NO_TC_ORDERS",
    input_0."HEADER_DIVISION_NM",
    input_0."SOURCE_CD",
    input_0."SOLD_TO_CD",
    input_0."SOLD_TO_NM",
    input_0."SHIP_TO",
    input_0."SHIP_TO_NAME",
    input_0."SHIPPING_TYPE",
    input_0."ORDER_NO_OD_ORDERS",
    input_0."TRANS_CD_OD_ORDERS",
    input_0."UDF10",
    input_0."EVENT_CODE_TC_OCCURRENCE",
    input_0."REASON_PO_NM",
    input_0."REASON_NM",
    input_0."VALIDATE_ID",
    input_0."REMARKS",
    input_0."UF_TO",
    input_0."OCCURRENCE_VALID",
    input_0."IF_RESP_DELAY_NM",
    input_0."VALIDATE_DATE",
    input_0."INSERT_DT_ID",
    input_0."INSERT_ID",
    input_0."OCCURRENCE_DT",
    input_1."DISPATCH_NO"
  FROM "layer_0_IN_M_HEADER_DIVISION" AS input_0
  INNER JOIN (
    SELECT
      "ORDER_NO",
      "DISPATCH_NO"
    FROM "OW_SEDA_S".ODS_TSS_RS_RESULT_LOC
  ) AS input_1
    ON input_0."ORDER_NO_OD_ORDERS" = input_1."ORDER_NO"
  )
     ORDER BY "DISPATCH_NO"
    SEGMENTED BY HASH("DISPATCH_NO") ALL NODES
  ;

  -- Node: IN_RS_RESULT
  PERFORM DROP TABLE IF EXISTS "layer_0_IN_RS_RESULT" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_IN_RS_RESULT" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."ORDER_NO_TC_ORDERS",
    input_0."HEADER_DIVISION_NM",
    input_0."SOURCE_CD",
    input_0."SOLD_TO_CD",
    input_0."SOLD_TO_NM",
    input_0."SHIP_TO",
    input_0."SHIP_TO_NAME",
    input_0."SHIPPING_TYPE",
    input_0."ORDER_NO_OD_ORDERS",
    input_0."TRANS_CD_OD_ORDERS",
    input_0."UDF10",
    input_0."EVENT_CODE_TC_OCCURRENCE",
    input_0."REASON_PO_NM",
    input_0."REASON_NM",
    input_0."VALIDATE_ID",
    input_0."REMARKS",
    input_0."UF_TO",
    input_0."OCCURRENCE_VALID",
    input_0."IF_RESP_DELAY_NM",
    input_0."VALIDATE_DATE",
    input_0."INSERT_DT_ID",
    input_0."INSERT_ID",
    input_0."OCCURRENCE_DT",
    input_1."DISPATCH_GROUP_NO"
  FROM "layer_0_IN_RS_RESULT_LOC" AS input_0
  INNER JOIN (
    SELECT
      "DISPATCH_NO",
      "DISPATCH_GROUP_NO"
    FROM "OW_SEDA_S".ODS_TSS_RS_RESULT
  ) AS input_1
    ON input_0."DISPATCH_NO" = input_1."DISPATCH_NO"
  )
     ORDER BY "DISPATCH_GROUP_NO"
    SEGMENTED BY HASH("DISPATCH_GROUP_NO") ALL NODES
  ;

  -- Node: Rank_1
  PERFORM DROP TABLE IF EXISTS "layer_0_Rank_1" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Rank_1" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    "TRANS_NM",
    "TRANS_CD_M_TRANS"
  FROM (
    SELECT
      "TRANS_NM",
      "TRANS_CD_M_TRANS",
      ROW_NUMBER() OVER (PARTITION BY "TRANS_NM" ORDER BY "TRANS_NM") AS _rn
    FROM (
      SELECT
        "TRANS_NM",
        "TRANS_CD" AS "TRANS_CD_M_TRANS"
      FROM "OW_SEDA_S".ODS_TSS_M_TRANS
    ) AS _rank_src
  ) AS _ranked
  WHERE
    _rn = 1
  )
     ORDER BY "TRANS_CD_M_TRANS"
    SEGMENTED BY HASH("TRANS_CD_M_TRANS") ALL NODES
  ;

  -- Node: Rank_2
  PERFORM DROP TABLE IF EXISTS "layer_0_Rank_2" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Rank_2" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    "CODE_CD",
    "CODE_NM",
    "CODE_TYPE_CD"
  FROM (
    SELECT
      "CODE_CD",
      "CODE_NM",
      "CODE_TYPE_CD",
      ROW_NUMBER() OVER (PARTITION BY "CODE_NM", "CODE_TYPE_CD" ORDER BY "CODE_CD" ASC) AS _rn
    FROM (
      SELECT
        "CODE_TYPE_CD",
        "CODE_NM",
        "CODE_CD"
      FROM "OW_SEDA_S".ODS_TSS_M_CODE
    ) AS _rank_src
  ) AS _ranked
  WHERE
    _rn = 1
  )
     ORDER BY "CODE_TYPE_CD", "CODE_CD"
    SEGMENTED BY HASH("CODE_TYPE_CD", "CODE_CD") ALL NODES
  ;

  -- Layer 1: 10 nodes

  -- Node: IN_RS_RESULT_GROUP
  PERFORM DROP TABLE IF EXISTS "layer_1_IN_RS_RESULT_GROUP" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_IN_RS_RESULT_GROUP" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."ORDER_NO_TC_ORDERS",
    input_0."HEADER_DIVISION_NM",
    input_0."SOURCE_CD",
    input_0."SOLD_TO_CD",
    input_0."SOLD_TO_NM",
    input_0."SHIP_TO",
    input_0."SHIP_TO_NAME",
    input_0."SHIPPING_TYPE",
    input_0."ORDER_NO_OD_ORDERS",
    input_0."TRANS_CD_OD_ORDERS",
    input_0."UDF10",
    input_0."EVENT_CODE_TC_OCCURRENCE",
    input_0."REASON_PO_NM",
    input_0."REASON_NM",
    input_0."VALIDATE_ID",
    input_0."REMARKS",
    input_0."UF_TO",
    input_0."OCCURRENCE_VALID",
    input_0."IF_RESP_DELAY_NM",
    input_0."VALIDATE_DATE",
    input_0."INSERT_DT_ID",
    input_0."INSERT_ID",
    input_0."OCCURRENCE_DT",
    input_1."TRANS_PARENT_CD"
  FROM "layer_0_IN_RS_RESULT" AS input_0
  INNER JOIN (
    SELECT
      "DISPATCH_GROUP_NO",
      "TRANS_PARENT_CD"
    FROM "OW_SEDA_S".ODS_TSS_RS_RESULT_GROUP
  ) AS input_1
    ON input_0."DISPATCH_GROUP_NO" = input_1."DISPATCH_GROUP_NO"
  )
     ORDER BY "ORDER_NO_TC_ORDERS"
    SEGMENTED BY HASH("ORDER_NO_TC_ORDERS") ALL NODES
  ;

  -- Node: LF_TC_LEG_PLANNING
  PERFORM DROP TABLE IF EXISTS "layer_1_LF_TC_LEG_PLANNING" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_LF_TC_LEG_PLANNING" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."ORDER_NO_TC_ORDERS",
    input_0."SOURCE_CD",
    input_0."SOLD_TO_CD",
    input_0."SOLD_TO_NM",
    input_0."SHIP_TO",
    input_0."SHIP_TO_NAME",
    input_0."SHIPPING_TYPE",
    input_0."ORDER_NO_OD_ORDERS",
    input_0."TRANS_CD_OD_ORDERS",
    input_0."UDF10",
    input_0."HEADER_DIVISION_NM",
    input_0."EVENT_CODE_TC_OCCURRENCE",
    input_0."REASON_PO_NM",
    input_0."REASON_NM",
    input_0."VALIDATE_ID",
    input_0."TRANS_PARENT_CD",
    input_0."REMARKS",
    input_0."UF_TO",
    input_0."OCCURRENCE_VALID",
    input_0."IF_RESP_DELAY_NM",
    input_0."VALIDATE_DATE",
    input_0."INSERT_DT_ID",
    input_0."INSERT_ID",
    input_0."OCCURRENCE_DT"
  FROM "layer_1_IN_RS_RESULT_GROUP" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "ORDER_NO"
    FROM "OW_SEDA_S".ODS_TSS_TC_LEG_PLANNING
  ) AS input_1
    ON input_0."ORDER_NO_TC_ORDERS" = input_1."ORDER_NO"
  )
     ORDER BY "ORDER_NO_TC_ORDERS"
    SEGMENTED BY HASH("ORDER_NO_TC_ORDERS") ALL NODES
  ;

  -- Node: LF_TB_MVW_TC_LEG_PLANNING
  PERFORM DROP TABLE IF EXISTS "layer_1_LF_TB_MVW_TC_LEG_PLANNING" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_LF_TB_MVW_TC_LEG_PLANNING" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."SOURCE_CD",
    input_0."SOLD_TO_CD",
    input_0."SOLD_TO_NM",
    input_0."SHIP_TO",
    input_0."SHIP_TO_NAME",
    input_0."SHIPPING_TYPE",
    input_0."ORDER_NO_OD_ORDERS",
    input_0."TRANS_CD_OD_ORDERS",
    input_0."UDF10",
    input_0."HEADER_DIVISION_NM",
    input_0."EVENT_CODE_TC_OCCURRENCE",
    input_0."REASON_PO_NM",
    input_0."REASON_NM",
    input_0."VALIDATE_ID",
    input_0."TRANS_PARENT_CD",
    input_0."REMARKS",
    input_0."UF_TO",
    input_0."OCCURRENCE_VALID",
    input_0."IF_RESP_DELAY_NM",
    input_0."VALIDATE_DATE",
    input_0."INSERT_DT_ID",
    input_0."INSERT_ID",
    input_0."OCCURRENCE_DT",
    input_1."TRANS_CD_LEG_PLANNING",
    CASE
      WHEN (
        input_1."TRANS_CD_LEG_PLANNING"
      ) IS NULL
      THEN input_0."UDF10"
      ELSE input_1."TRANS_CD_LEG_PLANNING"
    END AS "LAST_LEG_CARRIER_CD"
  FROM "layer_1_LF_TC_LEG_PLANNING" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "ORDER_NO",
      "TRANS_CD" AS "TRANS_CD_LEG_PLANNING"
    FROM "OW_SEDA_S".ODS_TSS_TB_MVW_TC_LEG_PLANNING
  ) AS input_1
    ON input_0."ORDER_NO_TC_ORDERS" = input_1."ORDER_NO"
  )
     ORDER BY "TRANS_CD_OD_ORDERS"
    SEGMENTED BY HASH("TRANS_CD_OD_ORDERS") ALL NODES
  ;

  -- Node: FNS_NM1_CARRIER
  PERFORM DROP TABLE IF EXISTS "layer_1_FNS_NM1_CARRIER" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_FNS_NM1_CARRIER" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."SOURCE_CD",
    input_0."SOLD_TO_CD",
    input_0."SOLD_TO_NM",
    input_0."SHIP_TO",
    input_0."SHIP_TO_NAME",
    input_0."SHIPPING_TYPE",
    input_0."ORDER_NO_OD_ORDERS",
    input_0."TRANS_CD_OD_ORDERS",
    input_0."HEADER_DIVISION_NM",
    input_0."LAST_LEG_CARRIER_CD",
    input_0."EVENT_CODE_TC_OCCURRENCE",
    input_0."REASON_PO_NM",
    input_0."REASON_NM",
    input_0."VALIDATE_ID",
    input_0."TRANS_PARENT_CD",
    input_0."REMARKS",
    input_0."UF_TO",
    input_0."OCCURRENCE_VALID",
    input_0."IF_RESP_DELAY_NM",
    input_0."VALIDATE_DATE",
    input_0."INSERT_DT_ID",
    input_0."INSERT_ID",
    input_0."OCCURRENCE_DT",
    input_1."TRANS_NM" AS "CARRIER"
  FROM "layer_1_LF_TB_MVW_TC_LEG_PLANNING" AS input_0
  LEFT OUTER JOIN "layer_0_Rank_1" AS input_1
    ON input_0."TRANS_CD_OD_ORDERS" = input_1."TRANS_CD_M_TRANS"
  )
     ORDER BY "TRANS_PARENT_CD"
    SEGMENTED BY HASH("TRANS_PARENT_CD") ALL NODES
  ;

  -- Node: FNS_NM1_TRANS_PARENT_NM
  PERFORM DROP TABLE IF EXISTS "layer_1_FNS_NM1_TRANS_PARENT_NM" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_FNS_NM1_TRANS_PARENT_NM" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."SOURCE_CD",
    input_0."SOLD_TO_CD",
    input_0."SOLD_TO_NM",
    input_0."SHIP_TO",
    input_0."SHIP_TO_NAME",
    input_0."SHIPPING_TYPE",
    input_0."ORDER_NO_OD_ORDERS",
    input_0."TRANS_CD_OD_ORDERS",
    input_0."HEADER_DIVISION_NM",
    input_0."LAST_LEG_CARRIER_CD",
    input_0."EVENT_CODE_TC_OCCURRENCE",
    input_0."REASON_PO_NM",
    input_0."REASON_NM",
    input_0."VALIDATE_ID",
    input_0."CARRIER",
    input_0."TRANS_PARENT_CD",
    input_0."REMARKS",
    input_0."UF_TO",
    input_0."OCCURRENCE_VALID",
    input_0."IF_RESP_DELAY_NM",
    input_0."VALIDATE_DATE",
    input_0."INSERT_DT_ID",
    input_0."INSERT_ID",
    input_0."OCCURRENCE_DT",
    input_1."TRANS_NM" AS "TRANS_PARENT_NM"
  FROM "layer_1_FNS_NM1_CARRIER" AS input_0
  LEFT OUTER JOIN "layer_0_Rank_1" AS input_1
    ON input_0."TRANS_PARENT_CD" = input_1."TRANS_CD_M_TRANS"
  )
     ORDER BY "LAST_LEG_CARRIER_CD"
    SEGMENTED BY HASH("LAST_LEG_CARRIER_CD") ALL NODES
  ;

  -- Node: FNS_NM1_LAST_LEG_CARRIER
  PERFORM DROP TABLE IF EXISTS "layer_1_FNS_NM1_LAST_LEG_CARRIER" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_FNS_NM1_LAST_LEG_CARRIER" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."SOURCE_CD",
    input_0."SOLD_TO_CD",
    input_0."SOLD_TO_NM",
    input_0."SHIP_TO",
    input_0."SHIP_TO_NAME",
    input_0."SHIPPING_TYPE",
    input_0."ORDER_NO_OD_ORDERS",
    input_0."TRANS_CD_OD_ORDERS",
    input_0."HEADER_DIVISION_NM",
    input_0."LAST_LEG_CARRIER_CD",
    input_0."EVENT_CODE_TC_OCCURRENCE",
    input_0."REASON_PO_NM",
    input_0."REASON_NM",
    input_0."VALIDATE_ID",
    input_0."CARRIER",
    input_0."TRANS_PARENT_CD",
    input_0."TRANS_PARENT_NM",
    input_0."REMARKS",
    input_0."UF_TO",
    input_0."OCCURRENCE_VALID",
    input_0."IF_RESP_DELAY_NM",
    input_0."VALIDATE_DATE",
    input_0."INSERT_DT_ID",
    input_0."INSERT_ID",
    input_0."OCCURRENCE_DT",
    input_1."TRANS_NM" AS "LAST_LEG_CARRIER",
    'BE030' AS "BE030"
  FROM "layer_1_FNS_NM1_TRANS_PARENT_NM" AS input_0
  LEFT OUTER JOIN "layer_0_Rank_1" AS input_1
    ON input_0."LAST_LEG_CARRIER_CD" = input_1."TRANS_CD_M_TRANS"
  )
     ORDER BY "BE030", "IF_RESP_DELAY_NM"
    SEGMENTED BY HASH("BE030", "IF_RESP_DELAY_NM") ALL NODES
  ;

  -- Node: FNS_NM2_RESP_DELAY_NM
  PERFORM DROP TABLE IF EXISTS "layer_1_FNS_NM2_RESP_DELAY_NM" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_FNS_NM2_RESP_DELAY_NM" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."SOURCE_CD",
    input_0."SOLD_TO_CD",
    input_0."SOLD_TO_NM",
    input_0."SHIP_TO",
    input_0."SHIP_TO_NAME",
    input_0."SHIPPING_TYPE",
    input_0."ORDER_NO_OD_ORDERS",
    input_0."TRANS_CD_OD_ORDERS",
    input_0."HEADER_DIVISION_NM",
    input_0."LAST_LEG_CARRIER_CD",
    input_0."EVENT_CODE_TC_OCCURRENCE",
    input_0."REASON_PO_NM",
    input_0."REASON_NM",
    input_0."VALIDATE_ID",
    input_0."CARRIER",
    input_0."TRANS_PARENT_CD",
    input_0."TRANS_PARENT_NM",
    input_0."LAST_LEG_CARRIER",
    input_0."REMARKS",
    input_0."UF_TO",
    input_0."OCCURRENCE_VALID",
    input_0."IF_RESP_DELAY_NM",
    input_0."VALIDATE_DATE",
    input_0."INSERT_DT_ID",
    input_0."INSERT_ID",
    input_0."OCCURRENCE_DT",
    input_1."CODE_NM" AS "RESP_DELAY_NM",
    'OC010' AS "OC010"
  FROM "layer_1_FNS_NM1_LAST_LEG_CARRIER" AS input_0
  LEFT OUTER JOIN "layer_0_Rank_2" AS input_1
    ON input_0."BE030" = input_1."CODE_TYPE_CD"
    AND input_0."IF_RESP_DELAY_NM" = input_1."CODE_CD"
  )
     ORDER BY "OC010", "IF_RESP_DELAY_NM"
    SEGMENTED BY HASH("OC010", "IF_RESP_DELAY_NM") ALL NODES
  ;

  -- Node: FNS_NM2_NEXT_STEP
  PERFORM DROP TABLE IF EXISTS "layer_1_FNS_NM2_NEXT_STEP" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_FNS_NM2_NEXT_STEP" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."SOURCE_CD",
    input_0."SOLD_TO_CD",
    input_0."SOLD_TO_NM",
    input_0."SHIP_TO",
    input_0."SHIP_TO_NAME",
    input_0."SHIPPING_TYPE",
    input_0."ORDER_NO_OD_ORDERS",
    input_0."TRANS_CD_OD_ORDERS",
    input_0."HEADER_DIVISION_NM",
    input_0."LAST_LEG_CARRIER_CD",
    input_0."EVENT_CODE_TC_OCCURRENCE",
    input_0."REASON_PO_NM",
    input_0."REASON_NM",
    input_0."VALIDATE_ID",
    input_0."CARRIER",
    input_0."TRANS_PARENT_CD",
    input_0."TRANS_PARENT_NM",
    input_0."LAST_LEG_CARRIER",
    input_0."REMARKS",
    input_0."UF_TO",
    input_0."OCCURRENCE_VALID",
    input_0."IF_RESP_DELAY_NM",
    input_0."RESP_DELAY_NM",
    input_0."VALIDATE_DATE",
    input_0."INSERT_DT_ID",
    input_0."INSERT_ID",
    input_0."OCCURRENCE_DT",
    input_1."CODE_NM" AS "NEXT_STEP",
    'OC020' AS "OC020"
  FROM "layer_1_FNS_NM2_RESP_DELAY_NM" AS input_0
  LEFT OUTER JOIN "layer_0_Rank_2" AS input_1
    ON input_0."OC010" = input_1."CODE_TYPE_CD"
    AND input_0."IF_RESP_DELAY_NM" = input_1."CODE_CD"
  )
     ORDER BY "OC020", "RESP_DELAY_NM"
    SEGMENTED BY HASH("OC020", "RESP_DELAY_NM") ALL NODES
  ;

  -- Node: FNS_NM2_NEXT_STEP_ACTION
  PERFORM DROP TABLE IF EXISTS "layer_1_FNS_NM2_NEXT_STEP_ACTION" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_FNS_NM2_NEXT_STEP_ACTION" ON COMMIT PRESERVE ROWS AS 
  SELECT
    input_0."SOURCE_CD",
    input_0."SOLD_TO_CD",
    input_0."SOLD_TO_NM",
    input_0."SHIP_TO",
    input_0."SHIP_TO_NAME",
    input_0."SHIPPING_TYPE",
    input_0."ORDER_NO_OD_ORDERS",
    input_0."TRANS_CD_OD_ORDERS",
    input_0."HEADER_DIVISION_NM",
    input_0."LAST_LEG_CARRIER_CD",
    input_0."EVENT_CODE_TC_OCCURRENCE",
    input_0."REASON_PO_NM",
    input_0."REASON_NM",
    input_0."VALIDATE_ID",
    input_0."CARRIER",
    input_0."TRANS_PARENT_CD",
    input_0."TRANS_PARENT_NM",
    input_0."LAST_LEG_CARRIER",
    input_0."REMARKS",
    input_0."UF_TO",
    input_0."OCCURRENCE_VALID",
    input_0."IF_RESP_DELAY_NM",
    input_0."RESP_DELAY_NM",
    input_0."NEXT_STEP",
    input_0."VALIDATE_DATE",
    input_0."INSERT_DT_ID",
    input_0."INSERT_ID",
    input_0."OCCURRENCE_DT",
    input_1."CODE_NM" AS "NEXT_STEP_ACTION"
  FROM "layer_1_FNS_NM2_NEXT_STEP" AS input_0
  LEFT OUTER JOIN "layer_0_Rank_2" AS input_1
    ON input_0."OC020" = input_1."CODE_TYPE_CD"
    AND input_0."RESP_DELAY_NM" = input_1."CODE_CD"
  ;

  -- Node: Projection
  PERFORM DROP TABLE IF EXISTS "layer_1_Projection" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_Projection" ON COMMIT PRESERVE ROWS AS 
  SELECT
    "SOURCE_CD",
    "SOLD_TO_CD",
    "SOLD_TO_NM",
    "SHIP_TO",
    "SHIP_TO_NAME",
    "SHIPPING_TYPE",
    "ORDER_NO_OD_ORDERS",
    "TRANS_CD_OD_ORDERS",
    "HEADER_DIVISION_NM",
    "LAST_LEG_CARRIER_CD",
    "EVENT_CODE_TC_OCCURRENCE",
    "REASON_PO_NM",
    "REASON_NM",
    "VALIDATE_ID",
    "CARRIER",
    "TRANS_PARENT_CD",
    "TRANS_PARENT_NM",
    "LAST_LEG_CARRIER",
    "REMARKS",
    "UF_TO",
    "OCCURRENCE_VALID",
    "RESP_DELAY_NM",
    "NEXT_STEP",
    "VALIDATE_DATE",
    "INSERT_DT_ID",
    "INSERT_ID",
    "OCCURRENCE_DT",
    "NEXT_STEP_ACTION"
  FROM "layer_1_FNS_NM2_NEXT_STEP_ACTION"
  ;

  -- Materialize final result
  PERFORM CREATE TABLE IF NOT EXISTS OW_SEDA_S.VIEWCV_CV_TSS_IOD_OCCURRENCE_REPORT AS
    SELECT * FROM "layer_1_Projection" WHERE 1=0;
  PERFORM TRUNCATE TABLE OW_SEDA_S.VIEWCV_CV_TSS_IOD_OCCURRENCE_REPORT;
  PERFORM INSERT INTO OW_SEDA_S.VIEWCV_CV_TSS_IOD_OCCURRENCE_REPORT
  SELECT * FROM "layer_1_Projection";

  PERFORM COMMIT;
  RAISE NOTICE 'Successfully loaded OW_SEDA_S.VIEWCV_CV_TSS_IOD_OCCURRENCE_REPORT';

END;
$$;