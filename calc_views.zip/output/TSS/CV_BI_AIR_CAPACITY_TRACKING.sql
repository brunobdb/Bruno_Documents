CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_CV_BI_AIR_CAPACITY_TRACKING" AS
SELECT
  "Delivery_Type",
  "DO_No_",
  "Source_Code",
  "Planned_GI_Date_(ETD)",
  "Ship-to_Party",
  "Shipping_Type",
  "Gross_Wgt",
  "Delivery_Qty",
  "Division_Name",
  "UF",
  "City",
  "Common_Division",
  "Gross_Item",
  "DAY_OF_WEEK",
  "PCS",
  "TON",
  "Source_System",
  "Order_Status_",
  "PROCESS_DATE"
FROM (
  SELECT
    input_0."Delivery_Type",
    input_0."DO_No_",
    input_0."Source_Code",
    input_0."Planned_GI_Date_(ETD)",
    input_0."Ship-to_Party",
    input_0."Shipping_Type",
    input_0."Gross_Wgt",
    input_0."Delivery_Qty",
    input_0."Division_Name",
    input_0."UF",
    input_0."City",
    input_0."Common_Division",
    input_0."Gross_Item",
    input_0."DAY_OF_WEEK",
    input_0."PCS",
    input_0."TON",
    input_0."Source_System",
    input_0."PROCESS_DATE",
    input_1."Order_Status" AS "Order_Status_"
  FROM (
    SELECT
      input_0."Delivery_Type",
      input_0."DO_No_",
      input_0."Source_Code",
      input_0."Planned_GI_Date_(ETD)",
      input_0."Ship-to_Party",
      input_0."Shipping_Type",
      input_0."Gross_Wgt",
      input_0."Delivery_Qty",
      input_0."Division_Name",
      input_0."UF",
      input_0."City",
      input_0."Common_Division",
      input_0."Gross_Item",
      input_0."DAY_OF_WEEK",
      input_0."Source_System",
      input_0."PROCESS_DATE",
      input_1."PCS",
      input_1."TON"
    FROM (
      SELECT
        "Delivery_Type" AS "Delivery_Type",
        "DO_No." AS "DO_No_",
        "Source_Code" AS "Source_Code",
        "Planned_GI_Date_(ETD)" AS "Planned_GI_Date_(ETD)",
        "Ship-to_Party" AS "Ship-to_Party",
        "Shipping_Type" AS "Shipping_Type",
        "Gross_Wgt" AS "Gross_Wgt",
        "Delivery_Qty" AS "Delivery_Qty",
        "Division_Name" AS "Division_Name",
        "UDF" AS "UF",
        "City",
        "Common_Division" AS "Common_Division",
        "Gross_Item" AS "Gross_Item",
        "Source_System" AS "Source_System",
        "PROCESS_DATE",
        SUBSTRING((TRIM(TO_CHAR("Planned_GI_Date_(ETD)", 'Day')))::VARCHAR, 1, 3) AS "DAY_OF_WEEK"
      FROM "OW_SEDA_S".VW_UNION_TSS_CELLO
    ) AS input_0
    INNER JOIN "OW_SEDA_S".INPUT_AIR_CAPACITY_TRACKING AS input_1
      ON input_0."DAY_OF_WEEK" = input_1."DAY_OF_WEEK" AND input_0."UF" = input_1."UF"
  ) AS input_0
  INNER JOIN "OW_SEDA_S".VW_UNION_TSS_CELLO AS input_1
    ON input_0."DO_No_" = input_1."DO_No."
) AS Join_1