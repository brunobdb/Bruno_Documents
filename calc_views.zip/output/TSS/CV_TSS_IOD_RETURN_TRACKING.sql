-- Migrated from HANA Calculation View: OW_SEDA_S.VIEWCV_CV_TSS_IOD_RETURN_TRACKING
-- Description: CV_TSS_IOD_RETURN_TRACKING

CREATE OR REPLACE PROCEDURE OW_SEDA_S.load_VIEWCV_CV_TSS_IOD_RETURN_TRACKING()
LANGUAGE PLvSQL AS $$
BEGIN

  -- Layer 0: 155 nodes

  -- Node: INNER_OD_ORDERS_LOC
  PERFORM DROP TABLE IF EXISTS "layer_0_INNER_OD_ORDERS_LOC" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_INNER_OD_ORDERS_LOC" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."REF_NO",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."COUNT",
    input_0."FOLLOW_UP_STATUS_SEQ",
    input_0."BOOKING_AT_HUB_LOCATION_GID",
    input_0."RET_NF_EXT_NO",
    input_0."RET_NF_SERIES",
    input_0."SUB_TRANS_TYPE",
    input_0."STATUS_CD",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."RETURN_CARRIER_CODE",
    input_0."COLLECT_DATE_TIME",
    input_1."ORDER_VOLUME",
    input_1."ORDER_WEIGHT"
  FROM (
    SELECT
      "ORDER_NO" AS "ORDER_NO_TC_ORDERS",
      "REF_NO",
      "DELETE_YN",
      "FOLLOW_UP_STATUS_SEQ",
      "BOOKING_AT_HUB_LOCATION_GID",
      "RET_NF_EXT_NO",
      "RET_NF_SERIES",
      "SUB_TRANS_TYPE",
      "COLLECT_DATE",
      "COLLECT_TIME",
      "STATUS_CD",
      "BOOKING_STATUS",
      "TRANS_CD",
      1 AS "COUNT",
      "COLLECT_DATE" || "COLLECT_TIME" AS "COLLECT_DATE_TIME_VARCHAR",
      DATS_IS_VALID("COLLECT_DATE_TIME_VARCHAR") AS "VALIDA_DATA",
      CASE "VALIDA_DATA" WHEN '1' THEN "VALIDA_DATA" WHEN '0' THEN NULL END AS "COLLECT",
      TO_DATE(("COLLECT")::VARCHAR, 'YYYY-MM-DD') AS "COLLECT_DATE_TIME",
      "BOOKING_STATUS" AS "BOOKING_STATUS_VARCHAR",
      CASE WHEN (
        "TRANS_CD"
      ) IS NULL THEN NULL ELSE "TRANS_CD" END AS "RETURN_CARRIER_CODE"
    FROM "OW_SEDA_S".ODS_TSS_TC_ORDERS
  ) AS input_0
  INNER JOIN (
    SELECT
      "ORDER_NO",
      "ORDER_VOLUME",
      "ORDER_WEIGHT"
    FROM "OW_SEDA_S".ODS_TSS_OD_ORDERS_LOC
  ) AS input_1
    ON input_0."ORDER_NO_TC_ORDERS" = input_1."ORDER_NO"
  )
     ORDER BY "ORDER_NO_TC_ORDERS"
    SEGMENTED BY HASH("ORDER_NO_TC_ORDERS") ALL NODES
  ;

  -- Node: INNER_OD_ORDERS
  PERFORM DROP TABLE IF EXISTS "layer_0_INNER_OD_ORDERS" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_INNER_OD_ORDERS" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."REF_NO",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."COUNT",
    input_0."FOLLOW_UP_STATUS_SEQ",
    input_0."BOOKING_AT_HUB_LOCATION_GID",
    input_0."RET_NF_EXT_NO",
    input_0."RET_NF_SERIES",
    input_0."ORDER_VOLUME",
    input_0."ORDER_WEIGHT",
    input_0."SUB_TRANS_TYPE",
    input_0."STATUS_CD",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."RETURN_CARRIER_CODE",
    input_0."COLLECT_DATE_TIME",
    input_1."ORDER_NO",
    input_1."DESTINATION_CD",
    input_1."DESTINATION_NM",
    input_1."UDF2",
    input_1."MID_AREA_CD"
  FROM "layer_0_INNER_OD_ORDERS_LOC" AS input_0
  INNER JOIN (
    SELECT
      "ORDER_NO",
      "ORDER_CLASS",
      "DELETE_YN",
      "DESTINATION_CD",
      "DESTINATION_NM",
      "UDF2",
      "MID_AREA_CD"
    FROM "OW_SEDA_S".ODS_TSS_OD_ORDERS
  ) AS input_1
    ON input_0."ORDER_NO_TC_ORDERS" = input_1."ORDER_NO"
  )
     ORDER BY "ORDER_NO"
    SEGMENTED BY HASH("ORDER_NO") ALL NODES
  ;

  -- Node: LEFT_OD_ORDERS_RETURN
  PERFORM DROP TABLE IF EXISTS "layer_0_LEFT_OD_ORDERS_RETURN" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_LEFT_OD_ORDERS_RETURN" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."REF_NO",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."COUNT",
    input_0."FOLLOW_UP_STATUS_SEQ",
    input_0."BOOKING_AT_HUB_LOCATION_GID",
    input_0."DESTINATION_CD",
    input_0."RET_NF_EXT_NO",
    input_0."RET_NF_SERIES",
    input_0."DESTINATION_NM",
    input_0."ORDER_VOLUME",
    input_0."ORDER_WEIGHT",
    input_0."UDF2",
    input_0."SUB_TRANS_TYPE",
    input_0."STATUS_CD",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."RETURN_CARRIER_CODE",
    input_0."MID_AREA_CD",
    input_0."COLLECT_DATE_TIME",
    input_1."DO_NO",
    input_1."AGING",
    input_1."AGING_RANGE",
    input_1."RETURN_ETA",
    input_1."GR_DATE"
  FROM "layer_0_INNER_OD_ORDERS" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "ORDER_NO",
      "DO_NO",
      "INSERT_DATE",
      "RET_GR_UPDATE_DATE" AS "GR_DATE",
      CASE
        WHEN NOT (
          "GR_DATE"
        ) IS NULL
        THEN TIMESTAMPDIFF(dd, "GR_DATE", TIMESTAMPADD(dd, 10, "INSERT_DATE"))
        ELSE TIMESTAMPDIFF(dd, NOW(), TIMESTAMPADD(dd, 10, "INSERT_DATE"))
      END AS "AGING",
      CASE
        WHEN 10 >= TIMESTAMPDIFF(dd, NOW(), INSERT_DATE)
        THEN 'Return On Time'
        ELSE CASE
          WHEN 20 >= TIMESTAMPDIFF(dd, NOW(), INSERT_DATE)
          AND 10 < TIMESTAMPDIFF(dd, NOW(), INSERT_DATE)
          THEN 'Aging 1 ~ 10'
          ELSE CASE
            WHEN 20 < TIMESTAMPDIFF(dd, NOW(), INSERT_DATE)
            THEN 'Aging Over 10 days'
            ELSE NULL
          END
        END
      END AS "AGING_RANGE",
      TIMESTAMPADD(dd, 10, "INSERT_DATE") AS "RETURN_ETA"
    FROM "OW_SEDA_S".ODS_TSS_OD_ORDERS_RETURN
  ) AS input_1
    ON input_0."ORDER_NO" = input_1."ORDER_NO"
  )
     ORDER BY "REF_NO"
    SEGMENTED BY HASH("REF_NO") ALL NODES
  ;

  -- Node: LEFT_WEB_RETURN_REQUEST
  PERFORM DROP TABLE IF EXISTS "layer_0_LEFT_WEB_RETURN_REQUEST" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_LEFT_WEB_RETURN_REQUEST" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."DO_NO",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."COUNT",
    input_0."FOLLOW_UP_STATUS_SEQ",
    input_0."REF_NO",
    input_0."BOOKING_AT_HUB_LOCATION_GID",
    input_0."DESTINATION_CD",
    input_0."RET_NF_EXT_NO",
    input_0."RET_NF_SERIES",
    input_0."DESTINATION_NM",
    input_0."ORDER_VOLUME",
    input_0."ORDER_WEIGHT",
    input_0."UDF2",
    input_0."SUB_TRANS_TYPE",
    input_0."STATUS_CD",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."MID_AREA_CD",
    input_0."GR_DATE",
    input_0."COLLECT_DATE_TIME",
    input_1."AUTHORIZATION_CODE",
    input_1."AUTHORIZATION_DATE"
  FROM "layer_0_LEFT_OD_ORDERS_RETURN" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "ORDER_NO",
      "DELETE_YN",
      "AUTHORIZATION_CODE",
      "AUTHORIZATION_DATE"
    FROM "OW_SEDA_S".ODS_TSS_WEB_RETURN_REQUEST
  ) AS input_1
    ON input_0."REF_NO" = input_1."ORDER_NO"
  )
     ORDER BY "DO_NO"
    SEGMENTED BY HASH("DO_NO") ALL NODES
  ;

  -- Node: LEFT_OD_ORDERS_RETURN_DETAIL
  PERFORM DROP TABLE IF EXISTS "layer_0_LEFT_OD_ORDERS_RETURN_DETAIL" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_LEFT_OD_ORDERS_RETURN_DETAIL" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."COUNT",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."FOLLOW_UP_STATUS_SEQ",
    input_0."REF_NO" AS "REF_NO_1",
    input_0."BOOKING_AT_HUB_LOCATION_GID",
    input_0."DESTINATION_CD",
    input_0."AUTHORIZATION_CODE",
    input_0."AUTHORIZATION_DATE",
    input_0."RET_NF_EXT_NO",
    input_0."RET_NF_SERIES",
    input_0."DO_NO",
    input_0."DESTINATION_NM",
    input_0."ORDER_VOLUME",
    input_0."ORDER_WEIGHT",
    input_0."UDF2",
    input_0."SUB_TRANS_TYPE",
    input_0."STATUS_CD",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."MID_AREA_CD",
    input_0."GR_DATE",
    input_0."COLLECT_DATE_TIME",
    input_1."REF_NO",
    input_1."MATERIAL_CD",
    input_1."QTY",
    input_1."VOLUME",
    input_1."WEIGHT",
    input_1."INSERT_DATE",
    input_1."RETURN_NF_AMT"
  FROM "layer_0_LEFT_WEB_RETURN_REQUEST" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "REF_NO",
      "MATERIAL_CD",
      "QTY",
      "VOLUME",
      "WEIGHT",
      "INSERT_DATE",
      "UNIT_PRICE",
      "DO_NO",
      "QTY" * "UNIT_PRICE" AS "RETURN_NF_AMT"
    FROM "OW_SEDA_S".ODS_TSS_OD_ORDERS_RETURN_DETAIL
  ) AS input_1
    ON input_0."DO_NO" = input_1."DO_NO"
  )
     ORDER BY "ORDER_NO_TC_ORDERS"
    SEGMENTED BY HASH("ORDER_NO_TC_ORDERS") ALL NODES
  ;

  -- Node: LEFT_RS_RESULT_LOC
  PERFORM DROP TABLE IF EXISTS "layer_0_LEFT_RS_RESULT_LOC" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_LEFT_RS_RESULT_LOC" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."COUNT",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."REF_NO",
    input_0."MATERIAL_CD",
    input_0."FOLLOW_UP_STATUS_SEQ",
    input_0."REF_NO_1" AS "REF_NO_TC_ORDERS",
    input_0."BOOKING_AT_HUB_LOCATION_GID",
    input_0."DESTINATION_CD",
    input_0."AUTHORIZATION_CODE",
    input_0."AUTHORIZATION_DATE",
    input_0."RET_NF_EXT_NO",
    input_0."RET_NF_SERIES",
    input_0."DO_NO",
    input_0."DESTINATION_NM",
    input_0."QTY",
    input_0."ORDER_VOLUME",
    input_0."ORDER_WEIGHT",
    input_0."VOLUME",
    input_0."WEIGHT",
    input_0."UDF2",
    input_0."SUB_TRANS_TYPE",
    input_0."INSERT_DATE",
    input_0."STATUS_CD",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."MID_AREA_CD",
    input_0."GR_DATE",
    input_0."COLLECT_DATE_TIME",
    input_0."RETURN_NF_AMT",
    input_1."DISPATCH_NO",
    input_1."AREA_TYPE_CD"
  FROM "layer_0_LEFT_OD_ORDERS_RETURN_DETAIL" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "ORDER_NO",
      "DISPATCH_NO",
      "AREA_TYPE_CD"
    FROM "OW_SEDA_S".ODS_TSS_RS_RESULT_LOC
  ) AS input_1
    ON input_0."ORDER_NO_TC_ORDERS" = input_1."ORDER_NO"
  )
     ORDER BY "DISPATCH_NO"
    SEGMENTED BY HASH("DISPATCH_NO") ALL NODES
  ;

  -- Node: LEFT_RS_RESULT
  PERFORM DROP TABLE IF EXISTS "layer_0_LEFT_RS_RESULT" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_LEFT_RS_RESULT" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."COUNT",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."REF_NO",
    input_0."MATERIAL_CD",
    input_0."FOLLOW_UP_STATUS_SEQ",
    input_0."REF_NO_TC_ORDERS",
    input_0."BOOKING_AT_HUB_LOCATION_GID",
    input_0."DESTINATION_CD",
    input_0."AUTHORIZATION_CODE",
    input_0."AUTHORIZATION_DATE",
    input_0."RET_NF_EXT_NO",
    input_0."RET_NF_SERIES",
    input_0."DO_NO",
    input_0."DESTINATION_NM",
    input_0."QTY",
    input_0."ORDER_VOLUME",
    input_0."ORDER_WEIGHT",
    input_0."VOLUME",
    input_0."WEIGHT",
    input_0."UDF2",
    input_0."SUB_TRANS_TYPE",
    input_0."AREA_TYPE_CD",
    input_0."INSERT_DATE",
    input_0."STATUS_CD",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."MID_AREA_CD",
    input_0."GR_DATE",
    input_0."COLLECT_DATE_TIME",
    input_0."RETURN_NF_AMT",
    input_1."RETURN_REASON_CD",
    input_1."DISPATCH_GROUP_NO"
  FROM "layer_0_LEFT_RS_RESULT_LOC" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "DISPATCH_NO",
      "RETURN_REASON_CD",
      "DISPATCH_GROUP_NO"
    FROM "OW_SEDA_S".ODS_TSS_RS_RESULT
  ) AS input_1
    ON input_0."DISPATCH_NO" = input_1."DISPATCH_NO"
  )
     ORDER BY "RETURN_REASON_CD"
    SEGMENTED BY HASH("RETURN_REASON_CD") ALL NODES
  ;

  -- Node: LEFT_M_RETURN_REASON
  PERFORM DROP TABLE IF EXISTS "layer_0_LEFT_M_RETURN_REASON" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_LEFT_M_RETURN_REASON" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."COUNT",
    input_0."DISPATCH_GROUP_NO",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."REF_NO",
    input_0."MATERIAL_CD",
    input_0."FOLLOW_UP_STATUS_SEQ",
    input_0."REF_NO_TC_ORDERS",
    input_0."BOOKING_AT_HUB_LOCATION_GID",
    input_0."DESTINATION_CD",
    input_0."AUTHORIZATION_CODE",
    input_0."AUTHORIZATION_DATE",
    input_0."RET_NF_EXT_NO",
    input_0."RET_NF_SERIES",
    input_0."DO_NO",
    input_0."DESTINATION_NM",
    input_0."QTY",
    input_0."ORDER_VOLUME",
    input_0."ORDER_WEIGHT",
    input_0."VOLUME",
    input_0."WEIGHT",
    input_0."UDF2",
    input_0."SUB_TRANS_TYPE",
    input_0."AREA_TYPE_CD",
    input_0."INSERT_DATE",
    input_0."STATUS_CD",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."MID_AREA_CD",
    input_0."GR_DATE",
    input_0."COLLECT_DATE_TIME",
    input_0."RETURN_NF_AMT",
    input_1."R_REASON_CD",
    input_1."R_REASON_NM"
  FROM "layer_0_LEFT_RS_RESULT" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "R_REASON_CD",
      "R_REASON_NM"
    FROM "OW_SEDA_S".ODS_TSS_M_RETURN_REASON
  ) AS input_1
    ON input_0."RETURN_REASON_CD" = input_1."R_REASON_CD"
  )
     ORDER BY "DISPATCH_GROUP_NO"
    SEGMENTED BY HASH("DISPATCH_GROUP_NO") ALL NODES
  ;

  -- Node: LEFT_RS_RESULT_GROUP
  PERFORM DROP TABLE IF EXISTS "layer_0_LEFT_RS_RESULT_GROUP" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_LEFT_RS_RESULT_GROUP" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."COUNT",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."REF_NO",
    input_0."MATERIAL_CD",
    input_0."FOLLOW_UP_STATUS_SEQ",
    input_0."REF_NO_TC_ORDERS",
    input_0."BOOKING_AT_HUB_LOCATION_GID",
    input_0."DESTINATION_CD",
    input_0."AUTHORIZATION_CODE",
    input_0."AUTHORIZATION_DATE",
    input_0."RET_NF_EXT_NO",
    input_0."RET_NF_SERIES",
    input_0."DO_NO",
    input_0."DESTINATION_NM",
    input_0."QTY",
    input_0."ORDER_VOLUME",
    input_0."ORDER_WEIGHT",
    input_0."VOLUME",
    input_0."WEIGHT",
    input_0."UDF2",
    input_0."SUB_TRANS_TYPE",
    input_0."R_REASON_CD",
    input_0."R_REASON_NM",
    input_0."AREA_TYPE_CD",
    input_0."INSERT_DATE",
    input_0."STATUS_CD",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."MID_AREA_CD",
    input_0."GR_DATE",
    input_0."COLLECT_DATE_TIME",
    input_0."RETURN_NF_AMT"
  FROM "layer_0_LEFT_M_RETURN_REASON" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "DISPATCH_GROUP_NO"
    FROM "OW_SEDA_S".ODS_TSS_RS_RESULT_GROUP
  ) AS input_1
    ON input_0."DISPATCH_GROUP_NO" = input_1."DISPATCH_GROUP_NO"
  )
     ORDER BY "ORDER_NO_TC_ORDERS"
    SEGMENTED BY HASH("ORDER_NO_TC_ORDERS") ALL NODES
  ;

  -- Node: AGREGADA_TC_RETURN_BOOKING_REQUEST
  PERFORM DROP TABLE IF EXISTS "layer_0_AGREGADA_TC_RETURN_BOOKING_REQUEST" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_AGREGADA_TC_RETURN_BOOKING_REQUEST" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    "SHIP_ID",
    "CANCELED_YN",
    "ORDER_NO"
  FROM "OW_SEDA_S".ODS_TSS_TC_RETURN_BOOKING_REQUEST
  GROUP BY
    "SHIP_ID",
    "CANCELED_YN",
    "ORDER_NO"
  )
     ORDER BY "ORDER_NO", "SHIP_ID", "CANCELED_YN"
    SEGMENTED BY HASH("ORDER_NO", "SHIP_ID") ALL NODES
  ;

  -- Node: INNER_TC_RETURN_BOOKING_REQUEST
  PERFORM DROP TABLE IF EXISTS "layer_0_INNER_TC_RETURN_BOOKING_REQUEST" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_INNER_TC_RETURN_BOOKING_REQUEST" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."ORDER_NO",
    input_0."SOURCE_CD",
    input_0."DESTINATION_CD",
    input_0."SUB_TRANS_TYPE",
    input_0."INSERT_ID",
    input_0."INSERT_DATE",
    input_0."UPDATE_ID",
    input_0."UPDATE_DATE",
    input_0."CANCELED_YN",
    input_0."CONFIRMED_YN",
    input_0."CANCEL_REASON",
    input_0."REQUEST_BOOKING_DATE",
    input_0."CONFIRM_CANCELED_YN",
    input_0."VEHICLE_TYPE_CD",
    input_0."TRUCK_PLATE",
    input_0."TRAILER_PLATE",
    input_0."CONFIRM_TIME",
    input_0."CANCELED_ID",
    input_0."CANCELED_DATE",
    input_0."WH_CD",
    input_0."BOOKING_PROPOSED_DATE",
    input_0."RETURN_BOOKING_DATE",
    input_0."SHIP_ID"
  FROM (
    SELECT
      "ORDER_NO",
      "SHIP_ID",
      "SOURCE_CD",
      "DESTINATION_CD",
      "SUB_TRANS_TYPE",
      "INSERT_ID",
      "INSERT_DATE",
      "UPDATE_ID",
      "UPDATE_DATE",
      "CANCELED_YN",
      "CONFIRMED_YN",
      "CANCEL_REASON",
      "REQUEST_BOOKING_DATE",
      "CONFIRM_CANCELED_YN",
      "VEHICLE_TYPE_CD",
      "TRUCK_PLATE",
      "TRAILER_PLATE",
      "CONFIRM_TIME",
      "CANCELED_ID",
      "CANCELED_DATE",
      "WH_CD",
      "BOOKING_PROPOSED_DATE",
      "CONFIRM_DATE" AS "CONFIRM_DATE_VARCHAR",
      TO_DATE(("CONFIRM_DATE_VARCHAR")::VARCHAR, 'YYYY-MM-DD') AS "RETURN_BOOKING_DATE"
    FROM "OW_SEDA_S".ODS_TSS_TC_RETURN_BOOKING_REQUEST
  ) AS input_0
  INNER JOIN "layer_0_AGREGADA_TC_RETURN_BOOKING_REQUEST" AS input_1
    ON input_0."ORDER_NO" = input_1."ORDER_NO" AND input_0."SHIP_ID" = input_1."SHIP_ID"
  )
     ORDER BY "ORDER_NO"
    SEGMENTED BY HASH("ORDER_NO") ALL NODES
  ;

  -- Node: AGREGADA_TC_LEG_PLANNING
  PERFORM DROP TABLE IF EXISTS "layer_0_AGREGADA_TC_LEG_PLANNING" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_AGREGADA_TC_LEG_PLANNING" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    "INSERT_DATE",
    "ORDER_NO"
  FROM "OW_SEDA_S".ODS_TSS_TC_LEG_PLANNING
  GROUP BY
    "INSERT_DATE",
    "ORDER_NO"
  )
     ORDER BY "INSERT_DATE", "ORDER_NO"
    SEGMENTED BY HASH("INSERT_DATE", "ORDER_NO") ALL NODES
  ;

  -- Node: INNER_TC_LEG_PLANNING
  PERFORM DROP TABLE IF EXISTS "layer_0_INNER_TC_LEG_PLANNING" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_INNER_TC_LEG_PLANNING" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."ORDER_NO",
    input_0."TRANS_CD"
  FROM (
    SELECT
      "INSERT_DATE",
      "ORDER_NO",
      "ORDER_NO" AS "ORDER_NO_1",
      "MANIFEST_NO",
      "LOCATION_CD",
      "TRUCK_TYPE_CD",
      "TRANS_CD",
      "DRIVER_LICENCE",
      "TRUCK_PLATE",
      "INSERT_DATE" AS "INSERT_DATE_1",
      "INSERT_ID",
      "UPDATE_DATE",
      "UPDATE_ID",
      "SUB_TRANS_TYPE",
      "SHIPMENT_NO",
      "WMS_MANIFEST_NO",
      "CTRL_TIMESTAMP_SEQ",
      "CTRL_TIMESTAMP",
      "TENDER_STATUS_CD",
      "TENDER_REJECT_REASON",
      "IF_SEND"
    FROM "OW_SEDA_S".ODS_TSS_TC_LEG_PLANNING
  ) AS input_0
  INNER JOIN "layer_0_AGREGADA_TC_LEG_PLANNING" AS input_1
    ON input_0."INSERT_DATE" = input_1."INSERT_DATE"
    AND input_0."ORDER_NO" = input_1."ORDER_NO"
  )
     ORDER BY "ORDER_NO"
    SEGMENTED BY HASH("ORDER_NO") ALL NODES
  ;

  -- Node: Rank_1
  PERFORM DROP TABLE IF EXISTS "layer_0_Rank_1" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Rank_1" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    "CODE_NM",
    "CODE_TYPE_CD",
    "CODE_CD"
  FROM (
    SELECT
      "CODE_NM",
      "CODE_TYPE_CD",
      "CODE_CD",
      ROW_NUMBER() OVER (PARTITION BY "CODE_CD" ORDER BY "CODE_NM" DESC) AS _rn
    FROM (
      SELECT
        "CODE_TYPE_CD",
        "CODE_NM",
        "CODE_CD"
      FROM "OW_SEDA_S".ODS_TSS_M_CODE
    ) AS _rank_src
  ) AS _ranked
  WHERE
    _rn = 1
  )
     ORDER BY "CODE_TYPE_CD", "CODE_CD"
    SEGMENTED BY HASH("CODE_TYPE_CD", "CODE_CD") ALL NODES
  ;

  -- Node: Rank_2
  PERFORM DROP TABLE IF EXISTS "layer_0_Rank_2" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Rank_2" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    "FN_NEXT_STEP_ACTION",
    "ORDER_NO",
    "DELETE_YN",
    "NEXT_STEP",
    "EVENT_CODE",
    "INSERT_DATE"
  FROM (
    SELECT
      "FN_NEXT_STEP_ACTION",
      "ORDER_NO",
      "DELETE_YN",
      "NEXT_STEP",
      "EVENT_CODE",
      "INSERT_DATE",
      ROW_NUMBER() OVER (PARTITION BY "FN_NEXT_STEP_ACTION" ORDER BY "INSERT_DATE" DESC) AS _rn
    FROM (
      SELECT
        "NEXT_STEP_ACTION" AS "FN_NEXT_STEP_ACTION",
        "DELETE_YN",
        "NEXT_STEP",
        "ORDER_NO",
        "EVENT_CODE",
        "INSERT_DATE"
      FROM "OW_SEDA_S".ODS_TSS_TC_CUSTOMER_REJECT
    ) AS _rank_src
  ) AS _ranked
  WHERE
    _rn = 1
  )
     ORDER BY "ORDER_NO"
    SEGMENTED BY HASH("ORDER_NO") ALL NODES
  ;

  -- Node: Rank_3
  PERFORM DROP TABLE IF EXISTS "layer_0_Rank_3" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Rank_3" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    "ORDER_NO",
    "UDF8"
  FROM (
    SELECT
      "ORDER_NO",
      "UDF8",
      ROW_NUMBER() OVER (PARTITION BY "UDF8" ORDER BY "ORDER_NO" DESC) AS _rn
    FROM (
      SELECT
        "ORDER_NO",
        "UDF8"
      FROM "OW_SEDA_S".ODS_TSS_OD_ORDERS_DETAIL
    ) AS _rank_src
  ) AS _ranked
  WHERE
    _rn = 1
  )
     ORDER BY "ORDER_NO"
    SEGMENTED BY HASH("ORDER_NO") ALL NODES
  ;

  -- Node: Rank_4
  PERFORM DROP TABLE IF EXISTS "layer_0_Rank_4" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Rank_4" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    "TRANS_CD",
    "TRANS_NM"
  FROM (
    SELECT
      "TRANS_CD",
      "TRANS_NM",
      ROW_NUMBER() OVER (PARTITION BY "TRANS_CD" ORDER BY "TRANS_NM" DESC) AS _rn
    FROM (
      SELECT
        "TRANS_CD",
        "TRANS_NM"
      FROM "OW_SEDA_S".ODS_TSS_M_TRANS
    ) AS _rank_src
  ) AS _ranked
  WHERE
    _rn = 1
  )
     ORDER BY "TRANS_CD"
    SEGMENTED BY HASH("TRANS_CD") ALL NODES
  ;

  -- Node: Rank_5
  PERFORM DROP TABLE IF EXISTS "layer_0_Rank_5" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Rank_5" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    "UN_SUBD_CD",
    "MID_AREA_CD"
  FROM (
    SELECT
      "UN_SUBD_CD",
      "MID_AREA_CD",
      ROW_NUMBER() OVER (PARTITION BY "MID_AREA_CD" ORDER BY "UN_SUBD_CD" DESC) AS _rn
    FROM (
      SELECT
        "UN_SUBD_CD",
        "MID_AREA_CD"
      FROM "OW_SEDA_S".ODS_TSS_M_MID_AREA
    ) AS _rank_src
  ) AS _ranked
  WHERE
    _rn = 1
  )
     ORDER BY "MID_AREA_CD"
    SEGMENTED BY HASH("MID_AREA_CD") ALL NODES
  ;

  -- Node: Aggregation_5
  PERFORM DROP TABLE IF EXISTS "layer_0_Aggregation_5" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Aggregation_5" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    "TRANS_DT",
    "DO_NO",
    "EVENT_CODE"
  FROM "OW_SEDA_S".ODS_TSS_TC_EVENT
  GROUP BY
    "TRANS_DT",
    "DO_NO",
    "EVENT_CODE"
  )
     ORDER BY "EVENT_CODE", "DO_NO", "TRANS_DT"
    SEGMENTED BY HASH("EVENT_CODE", "DO_NO") ALL NODES
  ;

  -- Node: Aggregation_6
  PERFORM DROP TABLE IF EXISTS "layer_0_Aggregation_6" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Aggregation_6" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    "REF_NO",
    "SELECT_MAX",
    NULL AS "VALIDA_DATA",
    NULL AS "SELECT_MAX_DT",
    NULL AS "RET_IOD_DT"
  FROM (
    SELECT
      "REF_NO",
      "EPOD_DATE",
      "EPOD_TIME",
      "IOD_VALID_YN" AS "IOD_VALID_YN_2",
      "EPOD_DATE" || "EPOD_TIME" AS "SELECT_MAX",
      CASE WHEN (
        "IOD_VALID_YN_2"
      ) IS NULL THEN 'N' ELSE "IOD_VALID_YN_2" END AS "IOD_VALID_YN"
    FROM "OW_SEDA_S".ODS_TSS_TC_IOD
  ) AS TC_IOD
  GROUP BY
    "REF_NO",
    "SELECT_MAX"
  )
     ORDER BY "REF_NO", "SELECT_MAX"
    SEGMENTED BY HASH("REF_NO") ALL NODES
  ;

  -- Layer 1: 10 nodes

  -- Node: LEFT_TC_RETURN_BOOKING_REQUEST
  PERFORM DROP TABLE IF EXISTS "layer_1_LEFT_TC_RETURN_BOOKING_REQUEST" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_LEFT_TC_RETURN_BOOKING_REQUEST" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."COUNT",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."REF_NO",
    input_0."MATERIAL_CD",
    input_0."FOLLOW_UP_STATUS_SEQ",
    input_0."REF_NO_TC_ORDERS",
    input_0."BOOKING_AT_HUB_LOCATION_GID",
    input_0."DESTINATION_CD",
    input_0."AUTHORIZATION_CODE",
    input_0."AUTHORIZATION_DATE",
    input_0."RET_NF_EXT_NO",
    input_0."RET_NF_SERIES",
    input_0."DO_NO",
    input_0."DESTINATION_NM",
    input_0."QTY",
    input_0."ORDER_VOLUME",
    input_0."ORDER_WEIGHT",
    input_0."VOLUME",
    input_0."WEIGHT",
    input_0."UDF2",
    input_0."SUB_TRANS_TYPE",
    input_0."R_REASON_CD",
    input_0."R_REASON_NM",
    input_0."AREA_TYPE_CD",
    input_0."INSERT_DATE",
    input_0."STATUS_CD",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."MID_AREA_CD",
    input_0."GR_DATE",
    input_0."COLLECT_DATE_TIME",
    input_0."RETURN_NF_AMT",
    input_1."TRUCK_PLATE",
    input_1."RETURN_BOOKING_DATE",
    input_1."SHIP_ID"
  FROM "layer_0_LEFT_RS_RESULT_GROUP" AS input_0
  LEFT OUTER JOIN "layer_0_INNER_TC_RETURN_BOOKING_REQUEST" AS input_1
    ON input_0."ORDER_NO_TC_ORDERS" = input_1."ORDER_NO"
  )
     ORDER BY "ORDER_NO_TC_ORDERS"
    SEGMENTED BY HASH("ORDER_NO_TC_ORDERS") ALL NODES
  ;

  -- Node: LEFT_BOOKING_UPDATE_LOG
  PERFORM DROP TABLE IF EXISTS "layer_1_LEFT_BOOKING_UPDATE_LOG" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_LEFT_BOOKING_UPDATE_LOG" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."REF_NO",
    input_0."MATERIAL_CD",
    input_0."COUNT",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."FOLLOW_UP_STATUS_SEQ",
    input_0."REF_NO_TC_ORDERS",
    input_0."BOOKING_AT_HUB_LOCATION_GID",
    input_0."DESTINATION_CD",
    input_0."AUTHORIZATION_CODE",
    input_0."AUTHORIZATION_DATE",
    input_0."RET_NF_EXT_NO",
    input_0."RET_NF_SERIES",
    input_0."DO_NO",
    input_0."DESTINATION_NM",
    input_0."QTY",
    input_0."ORDER_VOLUME",
    input_0."ORDER_WEIGHT",
    input_0."VOLUME",
    input_0."WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."UDF2",
    input_0."SUB_TRANS_TYPE",
    input_0."R_REASON_CD",
    input_0."R_REASON_NM",
    input_0."AREA_TYPE_CD",
    input_0."INSERT_DATE",
    input_0."STATUS_CD",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."MID_AREA_CD",
    input_0."RETURN_BOOKING_DATE",
    input_0."GR_DATE",
    input_0."SHIP_ID",
    input_0."COLLECT_DATE_TIME",
    input_0."RETURN_NF_AMT"
  FROM "layer_1_LEFT_TC_RETURN_BOOKING_REQUEST" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "DO_ID"
    FROM "OW_SEDA_S".ODS_TSS_BOOKING_UPDATE_LOG
  ) AS input_1
    ON input_0."ORDER_NO_TC_ORDERS" = input_1."DO_ID"
  )
     ORDER BY "REF_NO", "MATERIAL_CD"
    SEGMENTED BY HASH("REF_NO", "MATERIAL_CD") ALL NODES
  ;

  -- Node: LEFT_OD_ORDERS_DETAIL
  PERFORM DROP TABLE IF EXISTS "layer_1_LEFT_OD_ORDERS_DETAIL" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_LEFT_OD_ORDERS_DETAIL" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."COUNT",
    input_0."MATERIAL_CD",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."FOLLOW_UP_STATUS_SEQ",
    input_0."REF_NO_TC_ORDERS",
    input_0."BOOKING_AT_HUB_LOCATION_GID",
    input_0."DESTINATION_CD",
    input_0."AUTHORIZATION_CODE",
    input_0."AUTHORIZATION_DATE",
    input_0."RET_NF_EXT_NO",
    input_0."RET_NF_SERIES",
    input_0."DO_NO",
    input_0."DESTINATION_NM",
    input_0."QTY",
    input_0."ORDER_VOLUME",
    input_0."ORDER_WEIGHT",
    input_0."VOLUME",
    input_0."WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."UDF2",
    input_0."SUB_TRANS_TYPE",
    input_0."R_REASON_CD",
    input_0."R_REASON_NM",
    input_0."AREA_TYPE_CD",
    input_0."INSERT_DATE",
    input_0."STATUS_CD",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."MID_AREA_CD",
    input_0."RETURN_BOOKING_DATE",
    input_0."GR_DATE",
    input_0."SHIP_ID",
    input_0."COLLECT_DATE_TIME",
    input_0."RETURN_NF_AMT",
    input_1."ITEM_CD",
    input_1."ITEM_NM",
    input_1."ORDER_CNT"
  FROM "layer_1_LEFT_BOOKING_UPDATE_LOG" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "ITEM_CD",
      "ORDER_NO",
      "ITEM_NM",
      "ORDER_CNT"
    FROM "OW_SEDA_S".ODS_TSS_OD_ORDERS_DETAIL
  ) AS input_1
    ON input_0."REF_NO" = input_1."ORDER_NO"
    AND input_0."MATERIAL_CD" = input_1."ITEM_CD"
  )
     ORDER BY "ORDER_NO_TC_ORDERS", "MATERIAL_CD"
    SEGMENTED BY HASH("ORDER_NO_TC_ORDERS", "MATERIAL_CD") ALL NODES
  ;

  -- Node: LEFT_OD_ORDERS_DETAIL_2
  PERFORM DROP TABLE IF EXISTS "layer_1_LEFT_OD_ORDERS_DETAIL_2" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_LEFT_OD_ORDERS_DETAIL_2" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."COUNT",
    input_0."ITEM_CD",
    input_0."FOLLOW_UP_STATUS_SEQ",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."REF_NO_TC_ORDERS",
    input_0."BOOKING_AT_HUB_LOCATION_GID",
    input_0."DESTINATION_CD",
    input_0."AUTHORIZATION_CODE",
    input_0."AUTHORIZATION_DATE",
    input_0."RET_NF_EXT_NO",
    input_0."RET_NF_SERIES",
    input_0."DO_NO",
    input_0."DESTINATION_NM",
    input_0."ITEM_NM",
    input_0."ORDER_CNT",
    input_0."QTY",
    input_0."ORDER_VOLUME",
    input_0."ORDER_WEIGHT",
    input_0."VOLUME",
    input_0."WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."UDF2",
    input_0."SUB_TRANS_TYPE",
    input_0."R_REASON_CD",
    input_0."R_REASON_NM",
    input_0."AREA_TYPE_CD",
    input_0."INSERT_DATE",
    input_0."STATUS_CD",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."MID_AREA_CD",
    input_0."RETURN_BOOKING_DATE",
    input_0."GR_DATE",
    input_0."SHIP_ID",
    input_0."COLLECT_DATE_TIME",
    input_0."RETURN_NF_AMT"
  FROM "layer_1_LEFT_OD_ORDERS_DETAIL" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "ORDER_NO",
      "ITEM_CD"
    FROM "OW_SEDA_S".ODS_TSS_OD_ORDERS_DETAIL
  ) AS input_1
    ON input_0."ORDER_NO_TC_ORDERS" = input_1."ORDER_NO"
    AND input_0."MATERIAL_CD" = input_1."ITEM_CD"
  )
     ORDER BY "ITEM_CD"
    SEGMENTED BY HASH("ITEM_CD") ALL NODES
  ;

  -- Node: LEFT_M_ITEM
  PERFORM DROP TABLE IF EXISTS "layer_1_LEFT_M_ITEM" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_LEFT_M_ITEM" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."COUNT",
    input_0."FOLLOW_UP_STATUS_SEQ",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."REF_NO_TC_ORDERS",
    input_0."BOOKING_AT_HUB_LOCATION_GID",
    input_0."DESTINATION_CD",
    input_0."AUTHORIZATION_CODE",
    input_0."AUTHORIZATION_DATE",
    input_0."RET_NF_EXT_NO",
    input_0."RET_NF_SERIES",
    input_0."DO_NO",
    input_0."DESTINATION_NM",
    input_0."ITEM_NM",
    input_0."ORDER_CNT",
    input_0."ITEM_CD",
    input_0."QTY",
    input_0."ORDER_VOLUME",
    input_0."ORDER_WEIGHT",
    input_0."VOLUME",
    input_0."WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."UDF2",
    input_0."SUB_TRANS_TYPE",
    input_0."R_REASON_CD",
    input_0."R_REASON_NM",
    input_0."AREA_TYPE_CD",
    input_0."INSERT_DATE",
    input_0."STATUS_CD",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."MID_AREA_CD",
    input_0."RETURN_BOOKING_DATE",
    input_0."GR_DATE",
    input_0."SHIP_ID",
    input_0."COLLECT_DATE_TIME",
    input_0."RETURN_NF_AMT",
    input_1."DIVISION_CD"
  FROM "layer_1_LEFT_OD_ORDERS_DETAIL_2" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "ITEM_CD",
      "DIVISION_CD"
    FROM "OW_SEDA_S".ODS_TSS_M_ITEM
  ) AS input_1
    ON input_0."ITEM_CD" = input_1."ITEM_CD"
  )
     ORDER BY "FOLLOW_UP_STATUS_SEQ", "ORDER_NO_TC_ORDERS"
    SEGMENTED BY HASH("FOLLOW_UP_STATUS_SEQ", "ORDER_NO_TC_ORDERS") ALL NODES
  ;

  -- Node: LEFT_TC_FOLLOW_UP_STATUS
  PERFORM DROP TABLE IF EXISTS "layer_1_LEFT_TC_FOLLOW_UP_STATUS" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_LEFT_TC_FOLLOW_UP_STATUS" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."COUNT",
    input_0."REF_NO_TC_ORDERS",
    input_0."DIVISION_CD",
    input_0."BOOKING_AT_HUB_LOCATION_GID",
    input_0."DESTINATION_CD",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."AUTHORIZATION_CODE",
    input_0."AUTHORIZATION_DATE",
    input_0."RET_NF_EXT_NO",
    input_0."RET_NF_SERIES",
    input_0."DO_NO",
    input_0."DESTINATION_NM",
    input_0."ITEM_NM",
    input_0."ORDER_CNT",
    input_0."ITEM_CD",
    input_0."QTY",
    input_0."ORDER_VOLUME",
    input_0."ORDER_WEIGHT",
    input_0."VOLUME",
    input_0."WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."UDF2",
    input_0."SUB_TRANS_TYPE",
    input_0."R_REASON_CD",
    input_0."R_REASON_NM",
    input_0."AREA_TYPE_CD",
    input_0."INSERT_DATE",
    input_0."STATUS_CD",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."MID_AREA_CD",
    input_0."RETURN_BOOKING_DATE",
    input_0."GR_DATE",
    input_0."SHIP_ID",
    input_0."COLLECT_DATE_TIME",
    input_0."RETURN_NF_AMT",
    input_1."FOLLOW_UP_CD"
  FROM "layer_1_LEFT_M_ITEM" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "FOLLOW_UP_STATUS_SEQ",
      "ORDER_NO",
      "FOLLOW_UP_CD"
    FROM "OW_SEDA_S".ODS_TSS_TC_FOLLOW_UP_STATUS
  ) AS input_1
    ON input_0."FOLLOW_UP_STATUS_SEQ" = input_1."FOLLOW_UP_STATUS_SEQ"
    AND input_0."ORDER_NO_TC_ORDERS" = input_1."ORDER_NO"
  )
     ORDER BY "FOLLOW_UP_CD"
    SEGMENTED BY HASH("FOLLOW_UP_CD") ALL NODES
  ;

  -- Node: LEFT_M_FOLLOW_UP_STATUS
  PERFORM DROP TABLE IF EXISTS "layer_1_LEFT_M_FOLLOW_UP_STATUS" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_LEFT_M_FOLLOW_UP_STATUS" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."COUNT",
    input_0."REF_NO_TC_ORDERS",
    input_0."DIVISION_CD",
    input_0."BOOKING_AT_HUB_LOCATION_GID",
    input_0."DESTINATION_CD",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."AUTHORIZATION_CODE",
    input_0."AUTHORIZATION_DATE",
    input_0."RET_NF_EXT_NO",
    input_0."RET_NF_SERIES",
    input_0."DO_NO",
    input_0."DESTINATION_NM",
    input_0."ITEM_NM",
    input_0."ORDER_CNT",
    input_0."ITEM_CD",
    input_0."QTY",
    input_0."ORDER_VOLUME",
    input_0."ORDER_WEIGHT",
    input_0."VOLUME",
    input_0."WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."UDF2",
    input_0."SUB_TRANS_TYPE",
    input_0."R_REASON_CD",
    input_0."R_REASON_NM",
    input_0."AREA_TYPE_CD",
    input_0."INSERT_DATE",
    input_0."STATUS_CD",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."MID_AREA_CD",
    input_0."RETURN_BOOKING_DATE",
    input_0."GR_DATE",
    input_0."SHIP_ID",
    input_0."COLLECT_DATE_TIME",
    input_0."RETURN_NF_AMT"
  FROM "layer_1_LEFT_TC_FOLLOW_UP_STATUS" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "FOLLOW_UP_CD"
    FROM "OW_SEDA_S".ODS_TSS_M_FOLLOW_UP_STATUS
  ) AS input_1
    ON input_0."FOLLOW_UP_CD" = input_1."FOLLOW_UP_CD"
  )
     ORDER BY "REF_NO_TC_ORDERS"
    SEGMENTED BY HASH("REF_NO_TC_ORDERS") ALL NODES
  ;

  -- Node: LEFT_NF_OD_ORDERS
  PERFORM DROP TABLE IF EXISTS "layer_1_LEFT_NF_OD_ORDERS" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_LEFT_NF_OD_ORDERS" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."COUNT",
    input_0."DIVISION_CD",
    input_0."BOOKING_AT_HUB_LOCATION_GID",
    input_0."DESTINATION_CD",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."AUTHORIZATION_CODE",
    input_0."AUTHORIZATION_DATE",
    input_0."RET_NF_EXT_NO",
    input_0."RET_NF_SERIES",
    input_0."REF_NO_TC_ORDERS",
    input_0."DO_NO",
    input_0."DESTINATION_NM",
    input_0."ITEM_NM",
    input_0."ORDER_CNT",
    input_0."ITEM_CD",
    input_0."QTY",
    input_0."ORDER_VOLUME",
    input_0."ORDER_WEIGHT",
    input_0."VOLUME",
    input_0."WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."UDF2",
    input_0."SUB_TRANS_TYPE",
    input_0."R_REASON_CD",
    input_0."R_REASON_NM",
    input_0."AREA_TYPE_CD",
    input_0."INSERT_DATE",
    input_0."STATUS_CD",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."MID_AREA_CD",
    input_0."RETURN_BOOKING_DATE",
    input_0."GR_DATE",
    input_0."SHIP_ID",
    input_0."COLLECT_DATE_TIME",
    input_0."RETURN_NF_AMT",
    input_1."NF_EXT_NO",
    input_1."NF_SERIES",
    input_1."NF_TOT_AMT2" AS "NF_AMT"
  FROM "layer_1_LEFT_M_FOLLOW_UP_STATUS" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "DO_NO",
      "DELETE_YN",
      "NF_EXT_NO",
      "NF_SERIES",
      "NF_TOT_AMT2"
    FROM "OW_SEDA_S".ODS_TSS_NF_OD_ORDERS
  ) AS input_1
    ON input_0."REF_NO_TC_ORDERS" = input_1."DO_NO"
  )
     ORDER BY "DIVISION_CD"
    SEGMENTED BY HASH("DIVISION_CD") ALL NODES
  ;

  -- Node: LEFT_M_DIVISION
  PERFORM DROP TABLE IF EXISTS "layer_1_LEFT_M_DIVISION" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_LEFT_M_DIVISION" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."COUNT",
    input_0."BOOKING_AT_HUB_LOCATION_GID",
    input_0."DESTINATION_CD",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."AUTHORIZATION_CODE",
    input_0."AUTHORIZATION_DATE",
    input_0."RET_NF_EXT_NO",
    input_0."RET_NF_SERIES",
    input_0."REF_NO_TC_ORDERS",
    input_0."DO_NO",
    input_0."NF_EXT_NO",
    input_0."NF_SERIES",
    input_0."DESTINATION_NM",
    input_0."ITEM_NM",
    input_0."ORDER_CNT",
    input_0."ITEM_CD",
    input_0."QTY",
    input_0."ORDER_VOLUME",
    input_0."ORDER_WEIGHT",
    input_0."VOLUME",
    input_0."WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."UDF2",
    input_0."SUB_TRANS_TYPE",
    input_0."R_REASON_CD",
    input_0."R_REASON_NM",
    input_0."AREA_TYPE_CD",
    input_0."INSERT_DATE",
    input_0."STATUS_CD",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."DIVISION_CD",
    input_0."MID_AREA_CD",
    input_0."RETURN_BOOKING_DATE",
    input_0."GR_DATE",
    input_0."SHIP_ID",
    input_0."COLLECT_DATE_TIME",
    input_0."NF_AMT",
    input_0."RETURN_NF_AMT"
  FROM "layer_1_LEFT_NF_OD_ORDERS" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "DIVISION_CD"
    FROM "OW_SEDA_S".ODS_TSS_M_DIVISION
  ) AS input_1
    ON input_0."DIVISION_CD" = input_1."DIVISION_CD"
  )
     ORDER BY "BOOKING_AT_HUB_LOCATION_GID"
    SEGMENTED BY HASH("BOOKING_AT_HUB_LOCATION_GID") ALL NODES
  ;

  -- Node: LEFT_M_LOCATION
  PERFORM DROP TABLE IF EXISTS "layer_1_LEFT_M_LOCATION" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_1_LEFT_M_LOCATION" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."DESTINATION_CD",
    input_0."COUNT",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."AUTHORIZATION_CODE",
    input_0."AUTHORIZATION_DATE",
    input_0."RET_NF_EXT_NO",
    input_0."RET_NF_SERIES",
    input_0."REF_NO_TC_ORDERS",
    input_0."DO_NO",
    input_0."NF_EXT_NO",
    input_0."NF_SERIES",
    input_0."DESTINATION_NM",
    input_0."ITEM_NM",
    input_0."ORDER_CNT",
    input_0."ITEM_CD",
    input_0."QTY",
    input_0."ORDER_VOLUME",
    input_0."ORDER_WEIGHT",
    input_0."VOLUME",
    input_0."WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."UDF2",
    input_0."SUB_TRANS_TYPE",
    input_0."R_REASON_CD",
    input_0."R_REASON_NM",
    input_0."AREA_TYPE_CD",
    input_0."INSERT_DATE",
    input_0."STATUS_CD",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."DIVISION_CD",
    input_0."MID_AREA_CD",
    input_0."RETURN_BOOKING_DATE",
    input_0."GR_DATE",
    input_0."SHIP_ID",
    input_0."COLLECT_DATE_TIME",
    input_0."NF_AMT",
    input_0."RETURN_NF_AMT"
  FROM "layer_1_LEFT_M_DIVISION" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "LOCATION_GID"
    FROM "OW_SEDA_S".ODS_TSS_M_LOCATION
  ) AS input_1
    ON input_0."BOOKING_AT_HUB_LOCATION_GID" = input_1."LOCATION_GID"
  )
     ORDER BY "DESTINATION_CD"
    SEGMENTED BY HASH("DESTINATION_CD") ALL NODES
  ;

  -- Layer 2: 12 nodes

  -- Node: LEFT_M_LOCATION_2
  PERFORM DROP TABLE IF EXISTS "layer_2_LEFT_M_LOCATION_2" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_2_LEFT_M_LOCATION_2" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."COUNT",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."AUTHORIZATION_CODE",
    input_0."AUTHORIZATION_DATE",
    input_0."RET_NF_EXT_NO",
    input_0."RET_NF_SERIES",
    input_0."REF_NO_TC_ORDERS",
    input_0."DO_NO",
    input_0."NF_EXT_NO",
    input_0."NF_SERIES",
    input_0."DESTINATION_NM",
    input_0."DESTINATION_CD",
    input_0."ITEM_NM",
    input_0."ORDER_CNT",
    input_0."ITEM_CD",
    input_0."QTY",
    input_0."ORDER_VOLUME",
    input_0."ORDER_WEIGHT",
    input_0."VOLUME",
    input_0."WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."UDF2",
    input_0."SUB_TRANS_TYPE",
    input_0."R_REASON_CD",
    input_0."R_REASON_NM",
    input_0."AREA_TYPE_CD",
    input_0."INSERT_DATE",
    input_0."STATUS_CD",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."DIVISION_CD",
    input_0."MID_AREA_CD",
    input_0."RETURN_BOOKING_DATE",
    input_0."GR_DATE",
    input_0."SHIP_ID",
    input_0."COLLECT_DATE_TIME",
    input_0."NF_AMT",
    input_0."RETURN_NF_AMT"
  FROM "layer_1_LEFT_M_LOCATION" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "LOCATION_CD"
    FROM "OW_SEDA_S".ODS_TSS_M_LOCATION
  ) AS input_1
    ON input_0."DESTINATION_CD" = input_1."LOCATION_CD"
  )
     ORDER BY "ORDER_NO_TC_ORDERS"
    SEGMENTED BY HASH("ORDER_NO_TC_ORDERS") ALL NODES
  ;

  -- Node: LEFT_TC_LEG_PLANNING
  PERFORM DROP TABLE IF EXISTS "layer_2_LEFT_TC_LEG_PLANNING" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_2_LEFT_TC_LEG_PLANNING" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."COUNT",
    input_0."ORDER_NO_TC_ORDERS",
    input_0."AUTHORIZATION_CODE",
    input_0."AUTHORIZATION_DATE",
    input_0."RET_NF_EXT_NO",
    input_0."RET_NF_SERIES",
    input_0."REF_NO_TC_ORDERS",
    input_0."DO_NO",
    input_0."NF_EXT_NO",
    input_0."NF_SERIES",
    input_0."DESTINATION_NM",
    input_0."DESTINATION_CD",
    input_0."ITEM_NM",
    input_0."ORDER_CNT",
    input_0."ITEM_CD",
    input_0."QTY",
    input_0."ORDER_VOLUME",
    input_0."ORDER_WEIGHT",
    input_0."VOLUME",
    input_0."WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."UDF2",
    input_0."SUB_TRANS_TYPE",
    input_0."R_REASON_CD",
    input_0."R_REASON_NM",
    input_0."AREA_TYPE_CD",
    input_0."INSERT_DATE",
    input_0."STATUS_CD",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."DIVISION_CD",
    input_0."MID_AREA_CD",
    input_0."RETURN_BOOKING_DATE",
    input_0."GR_DATE",
    input_0."SHIP_ID",
    input_0."COLLECT_DATE_TIME",
    input_0."NF_AMT",
    input_0."RETURN_NF_AMT",
    input_1."TRANS_CD"
  FROM "layer_2_LEFT_M_LOCATION_2" AS input_0
  LEFT OUTER JOIN "layer_0_INNER_TC_LEG_PLANNING" AS input_1
    ON input_0."ORDER_NO_TC_ORDERS" = input_1."ORDER_NO"
  )
     ORDER BY "TRANS_CD"
    SEGMENTED BY HASH("TRANS_CD") ALL NODES
  ;

  -- Node: LEFT_M_TRANS
  PERFORM DROP TABLE IF EXISTS "layer_2_LEFT_M_TRANS" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_2_LEFT_M_TRANS" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."COUNT",
    input_0."ORDER_NO_TC_ORDERS" AS "TO_NO",
    input_0."AUTHORIZATION_CODE" AS "AUTHORIZATION_NUMBER",
    input_0."AUTHORIZATION_DATE",
    input_0."REF_NO_TC_ORDERS" AS "ORIG_DO_NO",
    input_0."DO_NO" AS "RDO_NUMBER",
    input_0."NF_EXT_NO" AS "ORIGINAL_NF",
    input_0."NF_SERIES" AS "ORIGINAL_NF_SERIES",
    input_0."RET_NF_EXT_NO" AS "CUSTOMER_NF",
    input_0."RET_NF_SERIES" AS "CUSTOMER_NF_SERIES",
    input_0."DESTINATION_NM" AS "SHIP_TO_PARTY_NM",
    input_0."DESTINATION_CD" AS "SHIP_TO_PARTY_CD",
    input_0."ITEM_NM" AS "MATERIAL",
    input_0."ORDER_CNT" AS "ORIGINAL_QTY",
    input_0."ITEM_CD" AS "MATERIAL_CODE",
    input_0."QTY" AS "RETURN_QTY",
    input_0."ORDER_VOLUME" AS "ORDER_GROSS_VOLUME",
    input_0."ORDER_WEIGHT" AS "ORDER_GROSS_WEIGHT",
    input_0."VOLUME" AS "RET_ORDER_GROSS_VOLUME",
    input_0."WEIGHT" AS "RET_ORDER_GROSS_WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."UDF2" AS "SHIPPING_POINT_CODE",
    input_0."SUB_TRANS_TYPE",
    input_0."R_REASON_CD" AS "RETURN_REASON_CODE",
    input_0."R_REASON_NM" AS "RETURN_REASON_DESC",
    input_0."AREA_TYPE_CD" AS "TRANS_ZONE",
    input_0."INSERT_DATE" AS "RDO_INSERT_DATE",
    input_0."STATUS_CD",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."DIVISION_CD",
    input_0."MID_AREA_CD",
    input_0."RETURN_BOOKING_DATE",
    input_0."GR_DATE",
    input_0."SHIP_ID",
    input_0."COLLECT_DATE_TIME",
    input_0."NF_AMT",
    input_0."RETURN_NF_AMT",
    '' AS "RET_COLLECT_YN",
    '00340' AS "00340"
  FROM "layer_2_LEFT_TC_LEG_PLANNING" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "TRANS_CD"
    FROM "OW_SEDA_S".ODS_TSS_M_TRANS
  ) AS input_1
    ON input_0."TRANS_CD" = input_1."TRANS_CD"
  )
     ORDER BY "00340", "STATUS_CD"
    SEGMENTED BY HASH("00340", "STATUS_CD") ALL NODES
  ;

  -- Node: FNS_NM2_STATUS_NM
  PERFORM DROP TABLE IF EXISTS "layer_2_FNS_NM2_STATUS_NM" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_2_FNS_NM2_STATUS_NM" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."COUNT",
    input_0."TO_NO",
    input_0."AUTHORIZATION_NUMBER",
    input_0."AUTHORIZATION_DATE",
    input_0."ORIG_DO_NO",
    input_0."RDO_NUMBER",
    input_0."ORIGINAL_NF",
    input_0."ORIGINAL_NF_SERIES",
    input_0."CUSTOMER_NF",
    input_0."CUSTOMER_NF_SERIES",
    input_0."SHIP_TO_PARTY_NM",
    input_0."SHIP_TO_PARTY_CD",
    input_0."MATERIAL",
    input_0."ORIGINAL_QTY",
    input_0."MATERIAL_CODE",
    input_0."RETURN_QTY",
    input_0."ORDER_GROSS_VOLUME",
    input_0."ORDER_GROSS_WEIGHT",
    input_0."RET_ORDER_GROSS_VOLUME",
    input_0."RET_ORDER_GROSS_WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."SHIPPING_POINT_CODE",
    input_0."SUB_TRANS_TYPE",
    input_0."RETURN_REASON_CODE",
    input_0."RETURN_REASON_DESC",
    input_0."TRANS_ZONE",
    input_0."RDO_INSERT_DATE",
    input_0."RET_COLLECT_YN",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."DIVISION_CD",
    input_0."MID_AREA_CD",
    input_0."RETURN_BOOKING_DATE",
    input_0."GR_DATE",
    input_0."SHIP_ID",
    input_0."COLLECT_DATE_TIME",
    input_0."NF_AMT",
    input_0."RETURN_NF_AMT",
    input_1."CODE_NM" AS "STATUS_NM"
  FROM "layer_2_LEFT_M_TRANS" AS input_0
  LEFT OUTER JOIN "layer_0_Rank_1" AS input_1
    ON input_0."00340" = input_1."CODE_TYPE_CD"
    AND input_0."STATUS_CD" = input_1."CODE_CD"
  )
     ORDER BY "TO_NO"
    SEGMENTED BY HASH("TO_NO") ALL NODES
  ;

  -- Node: FN_GET_DO_CURR_ACTION_NEXT_STEP_ACTION_NM
  PERFORM DROP TABLE IF EXISTS "layer_2_FN_GET_DO_CURR_ACTION_NEXT_STEP_ACTION_NM" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_2_FN_GET_DO_CURR_ACTION_NEXT_STEP_ACTION_NM" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."COUNT",
    input_0."TO_NO",
    input_0."AUTHORIZATION_NUMBER",
    input_0."AUTHORIZATION_DATE",
    input_0."ORIG_DO_NO",
    input_0."RDO_NUMBER",
    input_0."ORIGINAL_NF",
    input_0."ORIGINAL_NF_SERIES",
    input_0."CUSTOMER_NF",
    input_0."CUSTOMER_NF_SERIES",
    input_0."SHIP_TO_PARTY_NM",
    input_0."SHIP_TO_PARTY_CD",
    input_0."MATERIAL",
    input_0."ORIGINAL_QTY",
    input_0."MATERIAL_CODE",
    input_0."RETURN_QTY",
    input_0."ORDER_GROSS_VOLUME",
    input_0."ORDER_GROSS_WEIGHT",
    input_0."RET_ORDER_GROSS_VOLUME",
    input_0."RET_ORDER_GROSS_WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."SHIPPING_POINT_CODE",
    input_0."SUB_TRANS_TYPE",
    input_0."RETURN_REASON_CODE",
    input_0."RETURN_REASON_DESC",
    input_0."TRANS_ZONE",
    input_0."RDO_INSERT_DATE",
    input_0."RET_COLLECT_YN",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."DIVISION_CD",
    input_0."MID_AREA_CD",
    input_0."RETURN_BOOKING_DATE",
    input_0."STATUS_NM",
    input_0."GR_DATE",
    input_0."SHIP_ID",
    input_0."COLLECT_DATE_TIME",
    input_0."NF_AMT",
    input_0."RETURN_NF_AMT",
    input_1."FN_NEXT_STEP_ACTION",
    'OC020' AS "OC020"
  FROM "layer_2_FNS_NM2_STATUS_NM" AS input_0
  LEFT OUTER JOIN "layer_0_Rank_2" AS input_1
    ON input_0."TO_NO" = input_1."ORDER_NO"
  )
     ORDER BY "OC020", "FN_NEXT_STEP_ACTION"
    SEGMENTED BY HASH("OC020", "FN_NEXT_STEP_ACTION") ALL NODES
  ;

  -- Node: FNS_NM2_NEXT_STEP_ACTION_NM
  PERFORM DROP TABLE IF EXISTS "layer_2_FNS_NM2_NEXT_STEP_ACTION_NM" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_2_FNS_NM2_NEXT_STEP_ACTION_NM" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."COUNT",
    input_0."TO_NO",
    input_0."AUTHORIZATION_NUMBER",
    input_0."AUTHORIZATION_DATE",
    input_0."ORIG_DO_NO",
    input_0."RDO_NUMBER",
    input_0."ORIGINAL_NF",
    input_0."ORIGINAL_NF_SERIES",
    input_0."CUSTOMER_NF",
    input_0."CUSTOMER_NF_SERIES",
    input_0."SHIP_TO_PARTY_NM",
    input_0."SHIP_TO_PARTY_CD",
    input_0."MATERIAL",
    input_0."ORIGINAL_QTY",
    input_0."MATERIAL_CODE",
    input_0."RETURN_QTY",
    input_0."ORDER_GROSS_VOLUME",
    input_0."ORDER_GROSS_WEIGHT",
    input_0."RET_ORDER_GROSS_VOLUME",
    input_0."RET_ORDER_GROSS_WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."SHIPPING_POINT_CODE",
    input_0."SUB_TRANS_TYPE",
    input_0."RETURN_REASON_CODE",
    input_0."RETURN_REASON_DESC",
    input_0."TRANS_ZONE",
    input_0."RDO_INSERT_DATE",
    input_0."RET_COLLECT_YN",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."DIVISION_CD",
    input_0."MID_AREA_CD",
    input_0."RETURN_BOOKING_DATE",
    input_0."STATUS_NM",
    input_0."GR_DATE",
    input_0."SHIP_ID",
    input_0."COLLECT_DATE_TIME",
    input_0."NF_AMT",
    input_0."RETURN_NF_AMT",
    input_1."CODE_NM" AS "NEXT_STEP_ACTION_NM"
  FROM "layer_2_FN_GET_DO_CURR_ACTION_NEXT_STEP_ACTION_NM" AS input_0
  LEFT OUTER JOIN "layer_0_Rank_1" AS input_1
    ON input_0."OC020" = input_1."CODE_TYPE_CD"
    AND input_0."FN_NEXT_STEP_ACTION" = input_1."CODE_CD"
  )
     ORDER BY "TO_NO"
    SEGMENTED BY HASH("TO_NO") ALL NODES
  ;

  -- Node: LEFT_V_OCCUR_TOTAL_CNT
  PERFORM DROP TABLE IF EXISTS "layer_2_LEFT_V_OCCUR_TOTAL_CNT" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_2_LEFT_V_OCCUR_TOTAL_CNT" ON COMMIT PRESERVE ROWS AS 
  SELECT
    input_0."NEXT_STEP_ACTION_NM",
    input_0."COUNT",
    input_0."TO_NO",
    input_0."AUTHORIZATION_NUMBER",
    input_0."AUTHORIZATION_DATE",
    input_0."ORIG_DO_NO",
    input_0."RDO_NUMBER",
    input_0."ORIGINAL_NF",
    input_0."ORIGINAL_NF_SERIES",
    input_0."CUSTOMER_NF",
    input_0."CUSTOMER_NF_SERIES",
    input_0."SHIP_TO_PARTY_NM",
    input_0."SHIP_TO_PARTY_CD",
    input_0."MATERIAL",
    input_0."ORIGINAL_QTY",
    input_0."MATERIAL_CODE",
    input_0."RETURN_QTY",
    input_0."ORDER_GROSS_VOLUME",
    input_0."ORDER_GROSS_WEIGHT",
    input_0."RET_ORDER_GROSS_VOLUME",
    input_0."RET_ORDER_GROSS_WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."SHIPPING_POINT_CODE",
    input_0."SUB_TRANS_TYPE",
    input_0."RETURN_REASON_CODE",
    input_0."RETURN_REASON_DESC",
    input_0."TRANS_ZONE",
    input_0."RDO_INSERT_DATE",
    input_0."RET_COLLECT_YN",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."DIVISION_CD",
    input_0."MID_AREA_CD",
    input_0."RETURN_BOOKING_DATE",
    input_0."STATUS_NM",
    input_0."GR_DATE",
    input_0."SHIP_ID",
    input_0."COLLECT_DATE_TIME",
    input_0."NF_AMT",
    input_0."RETURN_NF_AMT",
    1 AS "V_OCCUR_TOTAL_CNT"
  FROM "layer_2_FNS_NM2_NEXT_STEP_ACTION_NM" AS input_0
  LEFT OUTER JOIN "OW_SEDA_S".ODS_TSS_TC_OCCURRENCE AS input_1
    ON input_0."TO_NO" = input_1."DO_NO"
  ;

  -- Node: Aggregation_1
  PERFORM DROP TABLE IF EXISTS "layer_2_Aggregation_1" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_2_Aggregation_1" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    "V_OCCUR_TOTAL_CNT",
    "V_OCCUR_TOTAL_CNT" AS "V_OCCUR_TOTAL_CNT_1",
    "NEXT_STEP_ACTION_NM",
    "COUNT",
    "TO_NO",
    "AUTHORIZATION_NUMBER",
    "AUTHORIZATION_DATE",
    "ORIG_DO_NO",
    "RDO_NUMBER",
    "ORIGINAL_NF",
    "ORIGINAL_NF_SERIES",
    "CUSTOMER_NF",
    "CUSTOMER_NF_SERIES",
    "SHIP_TO_PARTY_NM",
    "SHIP_TO_PARTY_CD",
    "MATERIAL",
    "ORIGINAL_QTY",
    "MATERIAL_CODE",
    "RETURN_QTY",
    "ORDER_GROSS_VOLUME",
    "ORDER_GROSS_WEIGHT",
    "RET_ORDER_GROSS_VOLUME",
    "RET_ORDER_GROSS_WEIGHT",
    "TRUCK_PLATE",
    "SHIPPING_POINT_CODE",
    "SUB_TRANS_TYPE",
    "RETURN_REASON_CODE",
    "RETURN_REASON_DESC",
    "TRANS_ZONE",
    "RDO_INSERT_DATE",
    "RET_COLLECT_YN",
    "BOOKING_STATUS_VARCHAR",
    "AGING",
    "AGING_RANGE",
    "RETURN_ETA",
    "RETURN_CARRIER_CODE",
    "MID_AREA_CD",
    "RETURN_BOOKING_DATE",
    "STATUS_NM",
    "GR_DATE",
    "SHIP_ID",
    "COLLECT_DATE_TIME",
    "NF_AMT",
    "RETURN_NF_AMT"
  FROM "layer_2_LEFT_V_OCCUR_TOTAL_CNT"
  GROUP BY
    "V_OCCUR_TOTAL_CNT",
    "NEXT_STEP_ACTION_NM",
    "COUNT",
    "TO_NO",
    "AUTHORIZATION_NUMBER",
    "AUTHORIZATION_DATE",
    "ORIG_DO_NO",
    "RDO_NUMBER",
    "ORIGINAL_NF",
    "ORIGINAL_NF_SERIES",
    "CUSTOMER_NF",
    "CUSTOMER_NF_SERIES",
    "SHIP_TO_PARTY_NM",
    "SHIP_TO_PARTY_CD",
    "MATERIAL",
    "ORIGINAL_QTY",
    "MATERIAL_CODE",
    "RETURN_QTY",
    "ORDER_GROSS_VOLUME",
    "ORDER_GROSS_WEIGHT",
    "RET_ORDER_GROSS_VOLUME",
    "RET_ORDER_GROSS_WEIGHT",
    "TRUCK_PLATE",
    "SHIPPING_POINT_CODE",
    "SUB_TRANS_TYPE",
    "RETURN_REASON_CODE",
    "RETURN_REASON_DESC",
    "TRANS_ZONE",
    "RDO_INSERT_DATE",
    "RET_COLLECT_YN",
    "BOOKING_STATUS_VARCHAR",
    "AGING",
    "AGING_RANGE",
    "RETURN_ETA",
    "RETURN_CARRIER_CODE",
    "MID_AREA_CD",
    "RETURN_BOOKING_DATE",
    "STATUS_NM",
    "GR_DATE",
    "SHIP_ID",
    "COLLECT_DATE_TIME",
    "NF_AMT",
    "RETURN_NF_AMT"
  )
     ORDER BY "TO_NO", "V_OCCUR_TOTAL_CNT", "NEXT_STEP_ACTION_NM", "COUNT", "AUTHORIZATION_NUMBER", "AUTHORIZATION_DATE", "ORIG_DO_NO", "RDO_NUMBER", "ORIGINAL_NF", "ORIGINAL_NF_SERIES", "CUSTOMER_NF", "CUSTOMER_NF_SERIES", "SHIP_TO_PARTY_NM", "SHIP_TO_PARTY_CD", "MATERIAL", "ORIGINAL_QTY", "MATERIAL_CODE", "RETURN_QTY", "ORDER_GROSS_VOLUME", "ORDER_GROSS_WEIGHT", "RET_ORDER_GROSS_VOLUME", "RET_ORDER_GROSS_WEIGHT", "TRUCK_PLATE", "SHIPPING_POINT_CODE", "SUB_TRANS_TYPE", "RETURN_REASON_CODE", "RETURN_REASON_DESC", "TRANS_ZONE", "RDO_INSERT_DATE", "RET_COLLECT_YN", "BOOKING_STATUS_VARCHAR", "AGING", "AGING_RANGE", "RETURN_ETA", "RETURN_CARRIER_CODE", "MID_AREA_CD", "RETURN_BOOKING_DATE", "STATUS_NM", "GR_DATE", "SHIP_ID", "COLLECT_DATE_TIME", "NF_AMT", "RETURN_NF_AMT"
    SEGMENTED BY HASH("TO_NO") ALL NODES
  ;

  -- Node: LEFT_V_OCCUR_VALID_TOTAL_CNT
  PERFORM DROP TABLE IF EXISTS "layer_2_LEFT_V_OCCUR_VALID_TOTAL_CNT" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_2_LEFT_V_OCCUR_VALID_TOTAL_CNT" ON COMMIT PRESERVE ROWS AS 
  SELECT
    input_0."NEXT_STEP_ACTION_NM",
    input_0."COUNT",
    input_0."TO_NO",
    input_0."AUTHORIZATION_NUMBER",
    input_0."AUTHORIZATION_DATE",
    input_0."ORIG_DO_NO",
    input_0."RDO_NUMBER",
    input_0."ORIGINAL_NF",
    input_0."ORIGINAL_NF_SERIES",
    input_0."CUSTOMER_NF",
    input_0."CUSTOMER_NF_SERIES",
    input_0."SHIP_TO_PARTY_NM",
    input_0."SHIP_TO_PARTY_CD",
    input_0."MATERIAL",
    input_0."ORIGINAL_QTY",
    input_0."MATERIAL_CODE",
    input_0."RETURN_QTY",
    input_0."ORDER_GROSS_VOLUME",
    input_0."ORDER_GROSS_WEIGHT",
    input_0."RET_ORDER_GROSS_VOLUME",
    input_0."RET_ORDER_GROSS_WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."SHIPPING_POINT_CODE",
    input_0."SUB_TRANS_TYPE",
    input_0."RETURN_REASON_CODE",
    input_0."RETURN_REASON_DESC",
    input_0."TRANS_ZONE",
    input_0."RDO_INSERT_DATE",
    input_0."RET_COLLECT_YN",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."MID_AREA_CD",
    input_0."RETURN_BOOKING_DATE",
    input_0."STATUS_NM",
    input_0."GR_DATE",
    input_0."SHIP_ID",
    input_0."COLLECT_DATE_TIME",
    input_0."NF_AMT",
    input_0."RETURN_NF_AMT",
    1 AS "V_OCCUR_VALID_TOTAL_CNT"
  FROM "layer_2_FNS_NM2_NEXT_STEP_ACTION_NM" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "OCCURRENCE_VALID",
      "DO_NO"
    FROM "OW_SEDA_S".ODS_TSS_TC_OCCURRENCE
  ) AS input_1
    ON input_0."TO_NO" = input_1."DO_NO"
  ;

  -- Node: Aggregation_2
  PERFORM DROP TABLE IF EXISTS "layer_2_Aggregation_2" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_2_Aggregation_2" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    "NEXT_STEP_ACTION_NM",
    "COUNT",
    "TO_NO",
    "AUTHORIZATION_NUMBER",
    "AUTHORIZATION_DATE",
    "ORIG_DO_NO",
    "RDO_NUMBER",
    "ORIGINAL_NF",
    "ORIGINAL_NF_SERIES",
    "CUSTOMER_NF",
    "CUSTOMER_NF_SERIES",
    "SHIP_TO_PARTY_NM",
    "SHIP_TO_PARTY_CD",
    "MATERIAL",
    "ORIGINAL_QTY",
    "MATERIAL_CODE",
    "RETURN_QTY",
    "ORDER_GROSS_VOLUME",
    "ORDER_GROSS_WEIGHT",
    "RET_ORDER_GROSS_VOLUME",
    "RET_ORDER_GROSS_WEIGHT",
    "TRUCK_PLATE",
    "SHIPPING_POINT_CODE",
    "SUB_TRANS_TYPE",
    "RETURN_REASON_CODE",
    "RETURN_REASON_DESC",
    "TRANS_ZONE",
    "RDO_INSERT_DATE",
    "RET_COLLECT_YN",
    "BOOKING_STATUS_VARCHAR",
    "AGING",
    "AGING_RANGE",
    "RETURN_ETA",
    "V_OCCUR_VALID_TOTAL_CNT",
    "RETURN_CARRIER_CODE",
    "MID_AREA_CD",
    "RETURN_BOOKING_DATE",
    "STATUS_NM",
    "GR_DATE",
    "SHIP_ID",
    "COLLECT_DATE_TIME",
    "NF_AMT",
    "RETURN_NF_AMT"
  FROM "layer_2_LEFT_V_OCCUR_VALID_TOTAL_CNT"
  GROUP BY
    "NEXT_STEP_ACTION_NM",
    "COUNT",
    "TO_NO",
    "AUTHORIZATION_NUMBER",
    "AUTHORIZATION_DATE",
    "ORIG_DO_NO",
    "RDO_NUMBER",
    "ORIGINAL_NF",
    "ORIGINAL_NF_SERIES",
    "CUSTOMER_NF",
    "CUSTOMER_NF_SERIES",
    "SHIP_TO_PARTY_NM",
    "SHIP_TO_PARTY_CD",
    "MATERIAL",
    "ORIGINAL_QTY",
    "MATERIAL_CODE",
    "RETURN_QTY",
    "ORDER_GROSS_VOLUME",
    "ORDER_GROSS_WEIGHT",
    "RET_ORDER_GROSS_VOLUME",
    "RET_ORDER_GROSS_WEIGHT",
    "TRUCK_PLATE",
    "SHIPPING_POINT_CODE",
    "SUB_TRANS_TYPE",
    "RETURN_REASON_CODE",
    "RETURN_REASON_DESC",
    "TRANS_ZONE",
    "RDO_INSERT_DATE",
    "RET_COLLECT_YN",
    "BOOKING_STATUS_VARCHAR",
    "AGING",
    "AGING_RANGE",
    "RETURN_ETA",
    "V_OCCUR_VALID_TOTAL_CNT",
    "RETURN_CARRIER_CODE",
    "MID_AREA_CD",
    "RETURN_BOOKING_DATE",
    "STATUS_NM",
    "GR_DATE",
    "SHIP_ID",
    "COLLECT_DATE_TIME",
    "NF_AMT",
    "RETURN_NF_AMT"
  )
     ORDER BY "TO_NO", "NEXT_STEP_ACTION_NM", "COUNT", "AUTHORIZATION_NUMBER", "AUTHORIZATION_DATE", "ORIG_DO_NO", "RDO_NUMBER", "ORIGINAL_NF", "ORIGINAL_NF_SERIES", "CUSTOMER_NF", "CUSTOMER_NF_SERIES", "SHIP_TO_PARTY_NM", "SHIP_TO_PARTY_CD", "MATERIAL", "ORIGINAL_QTY", "MATERIAL_CODE", "RETURN_QTY", "ORDER_GROSS_VOLUME", "ORDER_GROSS_WEIGHT", "RET_ORDER_GROSS_VOLUME", "RET_ORDER_GROSS_WEIGHT", "TRUCK_PLATE", "SHIPPING_POINT_CODE", "SUB_TRANS_TYPE", "RETURN_REASON_CODE", "RETURN_REASON_DESC", "TRANS_ZONE", "RDO_INSERT_DATE", "RET_COLLECT_YN", "BOOKING_STATUS_VARCHAR", "AGING", "AGING_RANGE", "RETURN_ETA", "V_OCCUR_VALID_TOTAL_CNT", "RETURN_CARRIER_CODE", "MID_AREA_CD", "RETURN_BOOKING_DATE", "STATUS_NM", "GR_DATE", "SHIP_ID", "COLLECT_DATE_TIME", "NF_AMT", "RETURN_NF_AMT"
    SEGMENTED BY HASH("TO_NO") ALL NODES
  ;

  -- Node: FN_GET_OCCURRENCE_STATUS_OCCURRENCES_STATUS
  PERFORM DROP TABLE IF EXISTS "layer_2_FN_GET_OCCURRENCE_STATUS_OCCURRENCES_STATUS" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_2_FN_GET_OCCURRENCE_STATUS_OCCURRENCES_STATUS" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."V_OCCUR_TOTAL_CNT_1" AS "V_OCCUR_TOTAL_CNT",
    input_0."NEXT_STEP_ACTION_NM",
    input_0."COUNT",
    input_0."TO_NO",
    input_0."AUTHORIZATION_NUMBER",
    input_0."AUTHORIZATION_DATE",
    input_0."ORIG_DO_NO",
    input_0."RDO_NUMBER",
    input_0."ORIGINAL_NF",
    input_0."ORIGINAL_NF_SERIES",
    input_0."CUSTOMER_NF",
    input_0."CUSTOMER_NF_SERIES",
    input_0."SHIP_TO_PARTY_NM",
    input_0."SHIP_TO_PARTY_CD",
    input_0."MATERIAL",
    input_0."ORIGINAL_QTY",
    input_0."MATERIAL_CODE",
    input_0."RETURN_QTY",
    input_0."ORDER_GROSS_VOLUME",
    input_0."ORDER_GROSS_WEIGHT",
    input_0."RET_ORDER_GROSS_VOLUME",
    input_0."RET_ORDER_GROSS_WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."SHIPPING_POINT_CODE",
    input_0."SUB_TRANS_TYPE",
    input_0."RETURN_REASON_CODE",
    input_0."RETURN_REASON_DESC",
    input_0."TRANS_ZONE",
    input_0."RDO_INSERT_DATE",
    input_0."RET_COLLECT_YN",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."MID_AREA_CD",
    input_0."RETURN_BOOKING_DATE",
    input_0."STATUS_NM",
    input_0."GR_DATE",
    input_0."SHIP_ID",
    input_0."COLLECT_DATE_TIME",
    input_0."NF_AMT",
    input_0."RETURN_NF_AMT",
    input_1."V_OCCUR_VALID_TOTAL_CNT",
    CASE
      WHEN "V_OCCUR_TOTAL_CNT" > 0
      THEN CASE
        WHEN "V_OCCUR_TOTAL_CNT" = input_1."V_OCCUR_VALID_TOTAL_CNT"
        THEN '01'
        ELSE '02'
      END
      ELSE NULL
    END AS "V_OCCUR_STATUS",
    'OC030' AS "OC030"
  FROM "layer_2_Aggregation_1" AS input_0
  LEFT OUTER JOIN "layer_2_Aggregation_2" AS input_1
    ON input_0."TO_NO" = input_1."TO_NO"
  )
     ORDER BY "OC030", "V_OCCUR_STATUS"
    SEGMENTED BY HASH("OC030", "V_OCCUR_STATUS") ALL NODES
  ;

  -- Node: FNS_NM2_OCCURRENCES_STATUS
  PERFORM DROP TABLE IF EXISTS "layer_2_FNS_NM2_OCCURRENCES_STATUS" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_2_FNS_NM2_OCCURRENCES_STATUS" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."V_OCCUR_TOTAL_CNT",
    input_0."NEXT_STEP_ACTION_NM",
    input_0."COUNT",
    input_0."TO_NO",
    input_0."AUTHORIZATION_NUMBER",
    input_0."AUTHORIZATION_DATE",
    input_0."ORIG_DO_NO",
    input_0."RDO_NUMBER",
    input_0."ORIGINAL_NF",
    input_0."ORIGINAL_NF_SERIES",
    input_0."CUSTOMER_NF",
    input_0."CUSTOMER_NF_SERIES",
    input_0."SHIP_TO_PARTY_NM",
    input_0."SHIP_TO_PARTY_CD",
    input_0."MATERIAL",
    input_0."ORIGINAL_QTY",
    input_0."MATERIAL_CODE",
    input_0."RETURN_QTY",
    input_0."ORDER_GROSS_VOLUME",
    input_0."ORDER_GROSS_WEIGHT",
    input_0."RET_ORDER_GROSS_VOLUME",
    input_0."RET_ORDER_GROSS_WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."SHIPPING_POINT_CODE",
    input_0."SUB_TRANS_TYPE",
    input_0."RETURN_REASON_CODE",
    input_0."RETURN_REASON_DESC",
    input_0."TRANS_ZONE",
    input_0."RDO_INSERT_DATE",
    input_0."RET_COLLECT_YN",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."RETURN_CARRIER_CODE",
    input_0."MID_AREA_CD",
    input_0."RETURN_BOOKING_DATE",
    input_0."STATUS_NM",
    input_0."GR_DATE",
    input_0."SHIP_ID",
    input_0."COLLECT_DATE_TIME",
    input_0."NF_AMT",
    input_0."RETURN_NF_AMT",
    input_1."CODE_NM" AS "OCCURRENCES_STATUS"
  FROM "layer_2_FN_GET_OCCURRENCE_STATUS_OCCURRENCES_STATUS" AS input_0
  LEFT OUTER JOIN "layer_0_Rank_1" AS input_1
    ON input_0."OC030" = input_1."CODE_TYPE_CD"
    AND input_0."V_OCCUR_STATUS" = input_1."CODE_CD"
  )
     ORDER BY "TO_NO"
    SEGMENTED BY HASH("TO_NO") ALL NODES
  ;

  -- Layer 3: 10 nodes

  -- Node: OCCURRENCES_STATUS
  PERFORM DROP TABLE IF EXISTS "layer_3_OCCURRENCES_STATUS" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_3_OCCURRENCES_STATUS" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."NEXT_STEP_ACTION_NM",
    input_0."COUNT",
    input_0."TO_NO",
    input_0."AUTHORIZATION_NUMBER",
    input_0."AUTHORIZATION_DATE",
    input_0."ORIG_DO_NO",
    input_0."RDO_NUMBER",
    input_0."ORIGINAL_NF",
    input_0."ORIGINAL_NF_SERIES",
    input_0."CUSTOMER_NF",
    input_0."CUSTOMER_NF_SERIES",
    input_0."SHIP_TO_PARTY_NM",
    input_0."SHIP_TO_PARTY_CD",
    input_0."MATERIAL",
    input_0."ORIGINAL_QTY",
    input_0."MATERIAL_CODE",
    input_0."RETURN_QTY",
    input_0."ORDER_GROSS_VOLUME",
    input_0."ORDER_GROSS_WEIGHT",
    input_0."RET_ORDER_GROSS_VOLUME",
    input_0."RET_ORDER_GROSS_WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."SHIPPING_POINT_CODE",
    input_0."SUB_TRANS_TYPE",
    input_0."RETURN_REASON_CODE",
    input_0."RETURN_REASON_DESC",
    input_0."TRANS_ZONE",
    input_0."RDO_INSERT_DATE",
    input_0."RET_COLLECT_YN",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."DIVISION_CD",
    input_1."OCCURRENCES_STATUS",
    input_1."BOOKING_STATUS_VARCHAR",
    input_1."RETURN_CARRIER_CODE",
    input_1."MID_AREA_CD",
    input_1."RETURN_BOOKING_DATE",
    input_1."STATUS_NM",
    input_1."GR_DATE",
    input_1."SHIP_ID",
    input_1."COLLECT_DATE_TIME",
    input_1."NF_AMT",
    input_1."RETURN_NF_AMT"
  FROM "layer_2_FNS_NM2_NEXT_STEP_ACTION_NM" AS input_0
  LEFT OUTER JOIN "layer_2_FNS_NM2_OCCURRENCES_STATUS" AS input_1
    ON input_0."TO_NO" = input_1."TO_NO"
  )
     ORDER BY "TO_NO"
    SEGMENTED BY HASH("TO_NO") ALL NODES
  ;

  -- Node: SELECT_MAX_SEQ
  PERFORM DROP TABLE IF EXISTS "layer_3_SELECT_MAX_SEQ" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_3_SELECT_MAX_SEQ" ON COMMIT PRESERVE ROWS AS 
  SELECT
    input_0."SEQ",
    input_1."TO_NO",
    input_1."BOOKING_STATUS_VARCHAR",
    input_1."RETURN_CARRIER_CODE",
    input_1."DIVISION_CD",
    input_1."MID_AREA_CD",
    input_1."RETURN_BOOKING_DATE",
    input_1."STATUS_NM",
    input_1."GR_DATE",
    input_1."SHIP_ID",
    input_1."COLLECT_DATE_TIME",
    input_1."NF_AMT",
    input_1."RETURN_NF_AMT"
  FROM "OW_SEDA_S".ODS_TSS_TC_OCCURRENCE AS input_0
  LEFT OUTER JOIN "layer_3_OCCURRENCES_STATUS" AS input_1
    ON input_0."DO_NO" = input_1."TO_NO"
  ;

  -- Node: Aggregation_3
  PERFORM DROP TABLE IF EXISTS "layer_3_Aggregation_3" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_3_Aggregation_3" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    "SEQ",
    "TO_NO",
    "BOOKING_STATUS_VARCHAR",
    "RETURN_CARRIER_CODE",
    "DIVISION_CD",
    "MID_AREA_CD",
    "RETURN_BOOKING_DATE",
    "STATUS_NM",
    "GR_DATE",
    "SHIP_ID",
    "COLLECT_DATE_TIME",
    "NF_AMT",
    "RETURN_NF_AMT"
  FROM "layer_3_SELECT_MAX_SEQ"
  GROUP BY
    "SEQ",
    "TO_NO",
    "BOOKING_STATUS_VARCHAR",
    "RETURN_CARRIER_CODE",
    "DIVISION_CD",
    "MID_AREA_CD",
    "RETURN_BOOKING_DATE",
    "STATUS_NM",
    "GR_DATE",
    "SHIP_ID",
    "COLLECT_DATE_TIME",
    "NF_AMT",
    "RETURN_NF_AMT"
  )
     ORDER BY "SEQ", "TO_NO", "BOOKING_STATUS_VARCHAR", "RETURN_CARRIER_CODE", "DIVISION_CD", "MID_AREA_CD", "RETURN_BOOKING_DATE", "STATUS_NM", "GR_DATE", "SHIP_ID", "COLLECT_DATE_TIME", "NF_AMT", "RETURN_NF_AMT"
    SEGMENTED BY HASH("SEQ") ALL NODES
  ;

  -- Node: SELECT_EVENT_CODE
  PERFORM DROP TABLE IF EXISTS "layer_3_SELECT_EVENT_CODE" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_3_SELECT_EVENT_CODE" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."EVENT_CODE",
    input_1."TO_NO",
    input_1."BOOKING_STATUS_VARCHAR",
    input_1."RETURN_CARRIER_CODE",
    input_1."DIVISION_CD",
    input_1."MID_AREA_CD",
    input_1."RETURN_BOOKING_DATE",
    input_1."STATUS_NM",
    input_1."GR_DATE",
    input_1."SHIP_ID",
    input_1."COLLECT_DATE_TIME",
    input_1."NF_AMT",
    input_1."RETURN_NF_AMT"
  FROM "OW_SEDA_S".ODS_TSS_TC_OCCURRENCE AS input_0
  LEFT OUTER JOIN "layer_3_Aggregation_3" AS input_1
    ON input_0."SEQ" = input_1."SEQ"
  )
     ORDER BY "EVENT_CODE"
    SEGMENTED BY HASH("EVENT_CODE") ALL NODES
  ;

  -- Node: SELECT_REASON_NM
  PERFORM DROP TABLE IF EXISTS "layer_3_SELECT_REASON_NM" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_3_SELECT_REASON_NM" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."REASON_NM" AS "LAST_OCCURRENCE",
    input_1."TO_NO",
    input_1."BOOKING_STATUS_VARCHAR",
    input_1."RETURN_CARRIER_CODE",
    input_1."DIVISION_CD",
    input_1."MID_AREA_CD",
    input_1."RETURN_BOOKING_DATE",
    input_1."STATUS_NM",
    input_1."GR_DATE",
    input_1."SHIP_ID",
    input_1."COLLECT_DATE_TIME",
    input_1."NF_AMT",
    input_1."RETURN_NF_AMT"
  FROM "OW_SEDA_S".ODS_TSS_M_REASON AS input_0
  LEFT OUTER JOIN "layer_3_SELECT_EVENT_CODE" AS input_1
    ON input_0."REASON_CD" = input_1."EVENT_CODE"
  )
     ORDER BY "TO_NO"
    SEGMENTED BY HASH("TO_NO") ALL NODES
  ;

  -- Node: LAST_OCCURRENCE
  PERFORM DROP TABLE IF EXISTS "layer_3_LAST_OCCURRENCE" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_3_LAST_OCCURRENCE" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."NEXT_STEP_ACTION_NM",
    input_0."COUNT",
    input_0."TO_NO",
    input_0."AUTHORIZATION_NUMBER",
    input_0."AUTHORIZATION_DATE",
    input_0."ORIG_DO_NO",
    input_0."RDO_NUMBER",
    input_0."ORIGINAL_NF",
    input_0."ORIGINAL_NF_SERIES",
    input_0."CUSTOMER_NF",
    input_0."CUSTOMER_NF_SERIES",
    input_0."SHIP_TO_PARTY_NM",
    input_0."SHIP_TO_PARTY_CD",
    input_0."MATERIAL",
    input_0."ORIGINAL_QTY",
    input_0."MATERIAL_CODE",
    input_0."RETURN_QTY",
    input_0."ORDER_GROSS_VOLUME",
    input_0."ORDER_GROSS_WEIGHT",
    input_0."RET_ORDER_GROSS_VOLUME",
    input_0."RET_ORDER_GROSS_WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."SHIPPING_POINT_CODE",
    input_0."SUB_TRANS_TYPE",
    input_0."RETURN_REASON_CODE",
    input_0."RETURN_REASON_DESC",
    input_0."TRANS_ZONE",
    input_0."RDO_INSERT_DATE",
    input_0."RET_COLLECT_YN",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."OCCURRENCES_STATUS",
    input_0."DIVISION_CD",
    input_1."LAST_OCCURRENCE",
    input_1."BOOKING_STATUS_VARCHAR",
    input_1."RETURN_CARRIER_CODE",
    input_1."MID_AREA_CD",
    input_1."RETURN_BOOKING_DATE",
    input_1."STATUS_NM",
    input_1."GR_DATE",
    input_1."SHIP_ID",
    input_1."COLLECT_DATE_TIME",
    input_1."NF_AMT",
    input_1."RETURN_NF_AMT"
  FROM "layer_3_OCCURRENCES_STATUS" AS input_0
  LEFT OUTER JOIN "layer_3_SELECT_REASON_NM" AS input_1
    ON input_0."TO_NO" = input_1."TO_NO"
  )
     ORDER BY "TO_NO"
    SEGMENTED BY HASH("TO_NO") ALL NODES
  ;

  -- Node: SELECT_MAX_SEQ_2
  PERFORM DROP TABLE IF EXISTS "layer_3_SELECT_MAX_SEQ_2" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_3_SELECT_MAX_SEQ_2" ON COMMIT PRESERVE ROWS AS 
  SELECT
    input_0."SEQ",
    input_1."TO_NO",
    input_1."BOOKING_STATUS_VARCHAR",
    input_1."RETURN_CARRIER_CODE",
    input_1."DIVISION_CD",
    input_1."MID_AREA_CD",
    input_1."RETURN_BOOKING_DATE",
    input_1."STATUS_NM",
    input_1."GR_DATE",
    input_1."SHIP_ID",
    input_1."COLLECT_DATE_TIME",
    input_1."NF_AMT",
    input_1."RETURN_NF_AMT"
  FROM "OW_SEDA_S".ODS_TSS_TC_OCCURRENCE AS input_0
  LEFT OUTER JOIN "layer_3_LAST_OCCURRENCE" AS input_1
    ON input_0."DO_NO" = input_1."TO_NO"
  ;

  -- Node: Aggregation_4
  PERFORM DROP TABLE IF EXISTS "layer_3_Aggregation_4" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_3_Aggregation_4" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    "SEQ",
    "TO_NO",
    "BOOKING_STATUS_VARCHAR",
    "RETURN_CARRIER_CODE",
    "DIVISION_CD",
    "MID_AREA_CD",
    "RETURN_BOOKING_DATE",
    "STATUS_NM",
    "GR_DATE",
    "SHIP_ID",
    "COLLECT_DATE_TIME",
    "NF_AMT",
    "RETURN_NF_AMT"
  FROM "layer_3_SELECT_MAX_SEQ_2"
  GROUP BY
    "SEQ",
    "TO_NO",
    "BOOKING_STATUS_VARCHAR",
    "RETURN_CARRIER_CODE",
    "DIVISION_CD",
    "MID_AREA_CD",
    "RETURN_BOOKING_DATE",
    "STATUS_NM",
    "GR_DATE",
    "SHIP_ID",
    "COLLECT_DATE_TIME",
    "NF_AMT",
    "RETURN_NF_AMT"
  )
     ORDER BY "SEQ", "TO_NO", "BOOKING_STATUS_VARCHAR", "RETURN_CARRIER_CODE", "DIVISION_CD", "MID_AREA_CD", "RETURN_BOOKING_DATE", "STATUS_NM", "GR_DATE", "SHIP_ID", "COLLECT_DATE_TIME", "NF_AMT", "RETURN_NF_AMT"
    SEGMENTED BY HASH("SEQ") ALL NODES
  ;

  -- Node: SELECT_REMARKS
  PERFORM DROP TABLE IF EXISTS "layer_3_SELECT_REMARKS" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_3_SELECT_REMARKS" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."REMARKS" AS "REMARKS_LAST_OCCURRENCE",
    input_1."TO_NO",
    input_1."BOOKING_STATUS_VARCHAR",
    input_1."RETURN_CARRIER_CODE",
    input_1."DIVISION_CD",
    input_1."MID_AREA_CD",
    input_1."RETURN_BOOKING_DATE",
    input_1."STATUS_NM",
    input_1."GR_DATE",
    input_1."SHIP_ID",
    input_1."COLLECT_DATE_TIME",
    input_1."NF_AMT",
    input_1."RETURN_NF_AMT"
  FROM "OW_SEDA_S".ODS_TSS_TC_OCCURRENCE AS input_0
  LEFT OUTER JOIN "layer_3_Aggregation_4" AS input_1
    ON input_0."SEQ" = input_1."SEQ"
  )
     ORDER BY "TO_NO"
    SEGMENTED BY HASH("TO_NO") ALL NODES
  ;

  -- Node: REMARKS_LAST_OCCURRENCE
  PERFORM DROP TABLE IF EXISTS "layer_3_REMARKS_LAST_OCCURRENCE" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_3_REMARKS_LAST_OCCURRENCE" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."LAST_OCCURRENCE",
    input_0."NEXT_STEP_ACTION_NM",
    input_0."COUNT",
    input_0."TO_NO",
    input_0."AUTHORIZATION_NUMBER",
    input_0."AUTHORIZATION_DATE",
    input_0."ORIG_DO_NO",
    input_0."RDO_NUMBER",
    input_0."ORIGINAL_NF",
    input_0."ORIGINAL_NF_SERIES",
    input_0."CUSTOMER_NF",
    input_0."CUSTOMER_NF_SERIES",
    input_0."SHIP_TO_PARTY_NM",
    input_0."SHIP_TO_PARTY_CD",
    input_0."MATERIAL",
    input_0."ORIGINAL_QTY",
    input_0."MATERIAL_CODE",
    input_0."RETURN_QTY",
    input_0."ORDER_GROSS_VOLUME",
    input_0."ORDER_GROSS_WEIGHT",
    input_0."RET_ORDER_GROSS_VOLUME",
    input_0."RET_ORDER_GROSS_WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."SHIPPING_POINT_CODE",
    input_0."SUB_TRANS_TYPE",
    input_0."RETURN_REASON_CODE",
    input_0."RETURN_REASON_DESC",
    input_0."TRANS_ZONE",
    input_0."RDO_INSERT_DATE",
    input_0."RET_COLLECT_YN",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."OCCURRENCES_STATUS",
    input_0."DIVISION_CD",
    input_1."REMARKS_LAST_OCCURRENCE",
    input_1."BOOKING_STATUS_VARCHAR",
    input_1."RETURN_CARRIER_CODE",
    input_1."MID_AREA_CD",
    input_1."RETURN_BOOKING_DATE",
    input_1."STATUS_NM",
    input_1."GR_DATE",
    input_1."SHIP_ID",
    input_1."COLLECT_DATE_TIME",
    input_1."NF_AMT",
    input_1."RETURN_NF_AMT",
    'B0006' AS "B0006"
  FROM "layer_3_LAST_OCCURRENCE" AS input_0
  LEFT OUTER JOIN "layer_3_SELECT_REMARKS" AS input_1
    ON input_0."TO_NO" = input_1."TO_NO"
  )
     ORDER BY "B0006", "BOOKING_STATUS_VARCHAR"
    SEGMENTED BY HASH("B0006", "BOOKING_STATUS_VARCHAR") ALL NODES
  ;

  -- Layer 4: 10 nodes

  -- Node: FNS_NM2_BOOKING_STATUS_NM
  PERFORM DROP TABLE IF EXISTS "layer_4_FNS_NM2_BOOKING_STATUS_NM" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_4_FNS_NM2_BOOKING_STATUS_NM" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."REMARKS_LAST_OCCURRENCE",
    input_0."LAST_OCCURRENCE",
    input_0."NEXT_STEP_ACTION_NM",
    input_0."COUNT",
    input_0."TO_NO",
    input_0."AUTHORIZATION_NUMBER",
    input_0."AUTHORIZATION_DATE",
    input_0."ORIG_DO_NO",
    input_0."RDO_NUMBER",
    input_0."ORIGINAL_NF",
    input_0."ORIGINAL_NF_SERIES",
    input_0."CUSTOMER_NF",
    input_0."CUSTOMER_NF_SERIES",
    input_0."SHIP_TO_PARTY_NM",
    input_0."SHIP_TO_PARTY_CD",
    input_0."MATERIAL",
    input_0."ORIGINAL_QTY",
    input_0."MATERIAL_CODE",
    input_0."RETURN_QTY",
    input_0."ORDER_GROSS_VOLUME",
    input_0."ORDER_GROSS_WEIGHT",
    input_0."RET_ORDER_GROSS_VOLUME",
    input_0."RET_ORDER_GROSS_WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."SHIPPING_POINT_CODE",
    input_0."SUB_TRANS_TYPE",
    input_0."RETURN_REASON_CODE",
    input_0."RETURN_REASON_DESC",
    input_0."TRANS_ZONE",
    input_0."RDO_INSERT_DATE",
    input_0."RET_COLLECT_YN",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."OCCURRENCES_STATUS",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."RETURN_CARRIER_CODE",
    input_0."DIVISION_CD",
    input_0."MID_AREA_CD",
    input_0."RETURN_BOOKING_DATE",
    input_0."STATUS_NM",
    input_0."GR_DATE",
    input_0."SHIP_ID",
    input_0."COLLECT_DATE_TIME",
    input_0."NF_AMT",
    input_0."RETURN_NF_AMT",
    input_1."CODE_NM" AS "BOOKING_STATUS_NM",
    CASE
      WHEN input_0."BOOKING_STATUS_VARCHAR" = '00010'
      THEN NULL
      ELSE input_0."SHIP_ID"
    END AS "RETURN_SHIPMENT",
    '6012803896' AS "6012803896"
  FROM "layer_3_REMARKS_LAST_OCCURRENCE" AS input_0
  LEFT OUTER JOIN "layer_0_Rank_1" AS input_1
    ON input_0."B0006" = input_1."CODE_TYPE_CD"
    AND input_0."BOOKING_STATUS_VARCHAR" = input_1."CODE_CD"
  )
     ORDER BY "6012803896"
    SEGMENTED BY HASH("6012803896") ALL NODES
  ;

  -- Node: PLANT
  PERFORM DROP TABLE IF EXISTS "layer_4_PLANT" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_4_PLANT" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."BOOKING_STATUS_NM",
    input_0."REMARKS_LAST_OCCURRENCE",
    input_0."LAST_OCCURRENCE",
    input_0."NEXT_STEP_ACTION_NM",
    input_0."COUNT",
    input_0."TO_NO",
    input_0."AUTHORIZATION_NUMBER",
    input_0."AUTHORIZATION_DATE",
    input_0."ORIG_DO_NO",
    input_0."RDO_NUMBER",
    input_0."ORIGINAL_NF",
    input_0."ORIGINAL_NF_SERIES",
    input_0."CUSTOMER_NF",
    input_0."CUSTOMER_NF_SERIES",
    input_0."SHIP_TO_PARTY_NM",
    input_0."SHIP_TO_PARTY_CD",
    input_0."MATERIAL",
    input_0."ORIGINAL_QTY",
    input_0."MATERIAL_CODE",
    input_0."RETURN_QTY",
    input_0."ORDER_GROSS_VOLUME",
    input_0."ORDER_GROSS_WEIGHT",
    input_0."RET_ORDER_GROSS_VOLUME",
    input_0."RET_ORDER_GROSS_WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."SHIPPING_POINT_CODE",
    input_0."SUB_TRANS_TYPE",
    input_0."RETURN_REASON_CODE",
    input_0."RETURN_REASON_DESC",
    input_0."TRANS_ZONE",
    input_0."RDO_INSERT_DATE",
    input_0."RET_COLLECT_YN",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."OCCURRENCES_STATUS",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."RETURN_SHIPMENT",
    input_0."RETURN_CARRIER_CODE",
    input_0."DIVISION_CD",
    input_0."MID_AREA_CD",
    input_0."RETURN_BOOKING_DATE",
    input_0."STATUS_NM",
    input_0."GR_DATE",
    input_0."COLLECT_DATE_TIME",
    input_0."NF_AMT",
    input_0."RETURN_NF_AMT",
    input_1."UDF8" AS "PLANT"
  FROM "layer_4_FNS_NM2_BOOKING_STATUS_NM" AS input_0
  LEFT OUTER JOIN "layer_0_Rank_3" AS input_1
    ON input_0."6012803896" = input_1."ORDER_NO"
  )
     ORDER BY "RETURN_CARRIER_CODE"
    SEGMENTED BY HASH("RETURN_CARRIER_CODE") ALL NODES
  ;

  -- Node: FNS_NM1_RETURN_CARRIER_NAME
  PERFORM DROP TABLE IF EXISTS "layer_4_FNS_NM1_RETURN_CARRIER_NAME" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_4_FNS_NM1_RETURN_CARRIER_NAME" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."BOOKING_STATUS_NM",
    input_0."REMARKS_LAST_OCCURRENCE",
    input_0."LAST_OCCURRENCE",
    input_0."NEXT_STEP_ACTION_NM",
    input_0."COUNT",
    input_0."TO_NO",
    input_0."AUTHORIZATION_NUMBER",
    input_0."AUTHORIZATION_DATE",
    input_0."ORIG_DO_NO",
    input_0."RDO_NUMBER",
    input_0."ORIGINAL_NF",
    input_0."ORIGINAL_NF_SERIES",
    input_0."CUSTOMER_NF",
    input_0."CUSTOMER_NF_SERIES",
    input_0."SHIP_TO_PARTY_NM",
    input_0."SHIP_TO_PARTY_CD",
    input_0."MATERIAL",
    input_0."ORIGINAL_QTY",
    input_0."MATERIAL_CODE",
    input_0."RETURN_QTY",
    input_0."ORDER_GROSS_VOLUME",
    input_0."ORDER_GROSS_WEIGHT",
    input_0."RET_ORDER_GROSS_VOLUME",
    input_0."RET_ORDER_GROSS_WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."SHIPPING_POINT_CODE",
    input_0."SUB_TRANS_TYPE",
    input_0."RETURN_REASON_CODE",
    input_0."RETURN_REASON_DESC",
    input_0."TRANS_ZONE",
    input_0."RDO_INSERT_DATE",
    input_0."RET_COLLECT_YN",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."OCCURRENCES_STATUS",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."RETURN_SHIPMENT",
    input_0."PLANT",
    input_0."RETURN_CARRIER_CODE",
    input_0."DIVISION_CD",
    input_0."MID_AREA_CD",
    input_0."RETURN_BOOKING_DATE",
    input_0."STATUS_NM",
    input_0."GR_DATE",
    input_0."COLLECT_DATE_TIME",
    input_0."NF_AMT",
    input_0."RETURN_NF_AMT",
    input_1."TRANS_NM" AS "RETURN_CARRIER_NAME"
  FROM "layer_4_PLANT" AS input_0
  LEFT OUTER JOIN "layer_0_Rank_4" AS input_1
    ON input_0."RETURN_CARRIER_CODE" = input_1."TRANS_CD"
  )
     ORDER BY "DIVISION_CD"
    SEGMENTED BY HASH("DIVISION_CD") ALL NODES
  ;

  -- Node: RETURN_CARRIER_NAME
  PERFORM DROP TABLE IF EXISTS "layer_4_RETURN_CARRIER_NAME" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_4_RETURN_CARRIER_NAME" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."COUNT",
    input_0."RETURN_CARRIER_NAME",
    input_0."BOOKING_STATUS_NM",
    input_0."REMARKS_LAST_OCCURRENCE",
    input_0."LAST_OCCURRENCE",
    input_0."NEXT_STEP_ACTION_NM",
    input_0."TO_NO",
    input_0."AUTHORIZATION_NUMBER",
    input_0."AUTHORIZATION_DATE",
    input_0."ORIG_DO_NO",
    input_0."RDO_NUMBER",
    input_0."ORIGINAL_NF",
    input_0."ORIGINAL_NF_SERIES",
    input_0."CUSTOMER_NF",
    input_0."CUSTOMER_NF_SERIES",
    input_0."SHIP_TO_PARTY_NM",
    input_0."SHIP_TO_PARTY_CD",
    input_0."MATERIAL",
    input_0."ORIGINAL_QTY",
    input_0."MATERIAL_CODE",
    input_0."RETURN_QTY",
    input_0."ORDER_GROSS_VOLUME",
    input_0."ORDER_GROSS_WEIGHT",
    input_0."RET_ORDER_GROSS_VOLUME",
    input_0."RET_ORDER_GROSS_WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."SHIPPING_POINT_CODE",
    input_0."SUB_TRANS_TYPE",
    input_0."RETURN_REASON_CODE",
    input_0."RETURN_REASON_DESC",
    input_0."TRANS_ZONE",
    input_0."RDO_INSERT_DATE",
    input_0."RET_COLLECT_YN",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."OCCURRENCES_STATUS",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."RETURN_SHIPMENT",
    input_0."PLANT",
    input_0."RETURN_CARRIER_CODE",
    input_0."MID_AREA_CD",
    input_0."RETURN_BOOKING_DATE",
    input_0."STATUS_NM",
    input_0."GR_DATE",
    input_0."DIVISION_CD",
    input_0."COLLECT_DATE_TIME",
    input_0."NF_AMT",
    input_0."RETURN_NF_AMT",
    input_1."DIVISION_NM"
  FROM "layer_4_FNS_NM1_RETURN_CARRIER_NAME" AS input_0
  LEFT OUTER JOIN "OW_SEDA_S".ODS_TSS_M_DIVISION AS input_1
    ON input_0."DIVISION_CD" = input_1."DIVISION_CD"
  )
     ORDER BY "MID_AREA_CD"
    SEGMENTED BY HASH("MID_AREA_CD") ALL NODES
  ;

  -- Node: UDF
  PERFORM DROP TABLE IF EXISTS "layer_4_UDF" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_4_UDF" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."RETURN_CARRIER_NAME",
    input_0."BOOKING_STATUS_NM",
    input_0."REMARKS_LAST_OCCURRENCE",
    input_0."LAST_OCCURRENCE",
    input_0."NEXT_STEP_ACTION_NM",
    input_0."TO_NO",
    input_0."AUTHORIZATION_NUMBER",
    input_0."AUTHORIZATION_DATE",
    input_0."ORIG_DO_NO",
    input_0."RDO_NUMBER",
    input_0."ORIGINAL_NF",
    input_0."ORIGINAL_NF_SERIES",
    input_0."CUSTOMER_NF",
    input_0."CUSTOMER_NF_SERIES",
    input_0."SHIP_TO_PARTY_NM",
    input_0."SHIP_TO_PARTY_CD",
    input_0."MATERIAL",
    input_0."ORIGINAL_QTY",
    input_0."MATERIAL_CODE",
    input_0."RETURN_QTY",
    input_0."ORDER_GROSS_VOLUME",
    input_0."ORDER_GROSS_WEIGHT",
    input_0."RET_ORDER_GROSS_VOLUME",
    input_0."RET_ORDER_GROSS_WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."SHIPPING_POINT_CODE",
    input_0."SUB_TRANS_TYPE",
    input_0."RETURN_REASON_CODE",
    input_0."RETURN_REASON_DESC",
    input_0."TRANS_ZONE",
    input_0."RDO_INSERT_DATE",
    input_0."RET_COLLECT_YN",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."OCCURRENCES_STATUS",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."RETURN_SHIPMENT",
    input_0."PLANT",
    input_0."RETURN_CARRIER_CODE",
    input_0."COUNT",
    input_0."RETURN_BOOKING_DATE",
    input_0."STATUS_NM",
    input_0."GR_DATE",
    input_0."DIVISION_CD",
    input_0."COLLECT_DATE_TIME",
    input_0."NF_AMT",
    input_0."RETURN_NF_AMT",
    input_1."UN_SUBD_CD" AS "UDF",
    'TR2010-10' AS "TR201010"
  FROM "layer_4_RETURN_CARRIER_NAME" AS input_0
  LEFT OUTER JOIN "layer_0_Rank_5" AS input_1
    ON input_0."MID_AREA_CD" = input_1."MID_AREA_CD"
  )
     ORDER BY "TR201010", "TO_NO"
    SEGMENTED BY HASH("TR201010", "TO_NO") ALL NODES
  ;

  -- Node: HUB_IN_CUSTOMER
  PERFORM DROP TABLE IF EXISTS "layer_4_HUB_IN_CUSTOMER" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_4_HUB_IN_CUSTOMER" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."RETURN_CARRIER_NAME",
    input_0."BOOKING_STATUS_NM",
    input_0."REMARKS_LAST_OCCURRENCE",
    input_0."LAST_OCCURRENCE",
    input_0."NEXT_STEP_ACTION_NM",
    input_0."TO_NO",
    input_0."AUTHORIZATION_NUMBER",
    input_0."AUTHORIZATION_DATE",
    input_0."ORIG_DO_NO",
    input_0."RDO_NUMBER",
    input_0."ORIGINAL_NF",
    input_0."ORIGINAL_NF_SERIES",
    input_0."CUSTOMER_NF",
    input_0."CUSTOMER_NF_SERIES",
    input_0."SHIP_TO_PARTY_NM",
    input_0."SHIP_TO_PARTY_CD",
    input_0."MATERIAL",
    input_0."ORIGINAL_QTY",
    input_0."MATERIAL_CODE",
    input_0."RETURN_QTY",
    input_0."ORDER_GROSS_VOLUME",
    input_0."ORDER_GROSS_WEIGHT",
    input_0."RET_ORDER_GROSS_VOLUME",
    input_0."RET_ORDER_GROSS_WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."SHIPPING_POINT_CODE",
    input_0."SUB_TRANS_TYPE",
    input_0."RETURN_REASON_CODE",
    input_0."RETURN_REASON_DESC",
    input_0."TRANS_ZONE",
    input_0."RDO_INSERT_DATE",
    input_0."RET_COLLECT_YN",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."OCCURRENCES_STATUS",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."RETURN_SHIPMENT",
    input_0."PLANT",
    input_0."RETURN_CARRIER_CODE",
    input_0."UDF",
    input_0."COUNT",
    input_0."RETURN_BOOKING_DATE",
    input_0."STATUS_NM",
    input_0."GR_DATE",
    input_0."DIVISION_CD",
    input_0."COLLECT_DATE_TIME",
    input_0."NF_AMT",
    input_0."RETURN_NF_AMT",
    input_1."TRANS_DT",
    DATS_IS_VALID(input_1."TRANS_DT") AS "VALIDA_DATA",
    CASE "VALIDA_DATA" WHEN '1' THEN input_1."TRANS_DT" WHEN '0' THEN NULL END AS "TRANS_DT_CASE",
    TO_DATE(("TRANS_DT_CASE")::VARCHAR, 'YYYY-MM-DD') AS "HUB_IN_CUSTOMER",
    TO_DATE(("TRANS_DT_CASE")::VARCHAR, 'YYYY-MM-DD') AS "HUB_OUT_CUSTOMER",
    'TR2040-10' AS "TR204010"
  FROM "layer_4_UDF" AS input_0
  LEFT OUTER JOIN "layer_0_Aggregation_5" AS input_1
    ON input_0."TR201010" = input_1."EVENT_CODE" AND input_0."TO_NO" = input_1."DO_NO"
  )
     ORDER BY "TR204010", "TO_NO"
    SEGMENTED BY HASH("TR204010", "TO_NO") ALL NODES
  ;

  -- Node: PORT_IN
  PERFORM DROP TABLE IF EXISTS "layer_4_PORT_IN" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_4_PORT_IN" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."RETURN_CARRIER_NAME",
    input_0."BOOKING_STATUS_NM",
    input_0."REMARKS_LAST_OCCURRENCE",
    input_0."LAST_OCCURRENCE",
    input_0."NEXT_STEP_ACTION_NM",
    input_0."TO_NO",
    input_0."AUTHORIZATION_NUMBER",
    input_0."AUTHORIZATION_DATE",
    input_0."ORIG_DO_NO",
    input_0."RDO_NUMBER",
    input_0."ORIGINAL_NF",
    input_0."ORIGINAL_NF_SERIES",
    input_0."CUSTOMER_NF",
    input_0."CUSTOMER_NF_SERIES",
    input_0."SHIP_TO_PARTY_NM",
    input_0."SHIP_TO_PARTY_CD",
    input_0."MATERIAL",
    input_0."ORIGINAL_QTY",
    input_0."MATERIAL_CODE",
    input_0."RETURN_QTY",
    input_0."ORDER_GROSS_VOLUME",
    input_0."ORDER_GROSS_WEIGHT",
    input_0."RET_ORDER_GROSS_VOLUME",
    input_0."RET_ORDER_GROSS_WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."SHIPPING_POINT_CODE",
    input_0."SUB_TRANS_TYPE",
    input_0."RETURN_REASON_CODE",
    input_0."RETURN_REASON_DESC",
    input_0."TRANS_ZONE",
    input_0."RDO_INSERT_DATE",
    input_0."RET_COLLECT_YN",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."OCCURRENCES_STATUS",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."RETURN_SHIPMENT",
    input_0."PLANT",
    input_0."RETURN_CARRIER_CODE",
    input_0."UDF",
    input_0."HUB_IN_CUSTOMER",
    input_0."HUB_OUT_CUSTOMER",
    input_0."COUNT",
    input_0."RETURN_BOOKING_DATE",
    input_0."STATUS_NM",
    input_0."GR_DATE",
    input_0."DIVISION_CD",
    input_0."COLLECT_DATE_TIME",
    input_0."NF_AMT",
    input_0."RETURN_NF_AMT",
    input_1."TRANS_DT",
    DATS_IS_VALID(input_1."TRANS_DT") AS "VALIDA_DATA",
    CASE "VALIDA_DATA" WHEN '1' THEN input_1."TRANS_DT" WHEN '0' THEN NULL END AS "TRANS_DT_CASE",
    TO_DATE(("TRANS_DT_CASE")::VARCHAR, 'YYYY-MM-DD') AS "PORT_IN",
    TO_DATE(("TRANS_DT_CASE")::VARCHAR, 'YYYY-MM-DD') AS "PORT_OUT",
    'TR2050-10' AS "TR205010"
  FROM "layer_4_HUB_IN_CUSTOMER" AS input_0
  LEFT OUTER JOIN "layer_0_Aggregation_5" AS input_1
    ON input_0."TR204010" = input_1."EVENT_CODE" AND input_0."TO_NO" = input_1."DO_NO"
  )
     ORDER BY "TR205010", "TO_NO"
    SEGMENTED BY HASH("TR205010", "TO_NO") ALL NODES
  ;

  -- Node: HUB_IN_SAMSUNG
  PERFORM DROP TABLE IF EXISTS "layer_4_HUB_IN_SAMSUNG" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_4_HUB_IN_SAMSUNG" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."RETURN_CARRIER_NAME",
    input_0."BOOKING_STATUS_NM",
    input_0."REMARKS_LAST_OCCURRENCE",
    input_0."LAST_OCCURRENCE",
    input_0."NEXT_STEP_ACTION_NM",
    input_0."TO_NO",
    input_0."AUTHORIZATION_NUMBER",
    input_0."AUTHORIZATION_DATE",
    input_0."ORIG_DO_NO",
    input_0."RDO_NUMBER",
    input_0."ORIGINAL_NF",
    input_0."ORIGINAL_NF_SERIES",
    input_0."CUSTOMER_NF",
    input_0."CUSTOMER_NF_SERIES",
    input_0."SHIP_TO_PARTY_NM",
    input_0."SHIP_TO_PARTY_CD",
    input_0."MATERIAL",
    input_0."ORIGINAL_QTY",
    input_0."MATERIAL_CODE",
    input_0."RETURN_QTY",
    input_0."ORDER_GROSS_VOLUME",
    input_0."ORDER_GROSS_WEIGHT",
    input_0."RET_ORDER_GROSS_VOLUME",
    input_0."RET_ORDER_GROSS_WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."SHIPPING_POINT_CODE",
    input_0."SUB_TRANS_TYPE",
    input_0."RETURN_REASON_CODE",
    input_0."RETURN_REASON_DESC",
    input_0."TRANS_ZONE",
    input_0."RDO_INSERT_DATE",
    input_0."RET_COLLECT_YN",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."OCCURRENCES_STATUS",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."RETURN_SHIPMENT",
    input_0."PLANT",
    input_0."RETURN_CARRIER_CODE",
    input_0."UDF",
    input_0."HUB_IN_CUSTOMER",
    input_0."HUB_OUT_CUSTOMER",
    input_0."COUNT",
    input_0."PORT_IN",
    input_0."PORT_OUT",
    input_0."RETURN_BOOKING_DATE",
    input_0."STATUS_NM",
    input_0."GR_DATE",
    input_0."DIVISION_CD",
    input_0."COLLECT_DATE_TIME",
    input_0."NF_AMT",
    input_0."RETURN_NF_AMT",
    input_1."TRANS_DT",
    DATS_IS_VALID(input_1."TRANS_DT") AS "VALIDA_DATA",
    CASE "VALIDA_DATA" WHEN '1' THEN input_1."TRANS_DT" WHEN '0' THEN NULL END AS "TRANS_DT_CASE",
    TO_DATE(("TRANS_DT_CASE")::VARCHAR, 'YYYY-MM-DD') AS "HUB_IN_SAMSUNG",
    TO_DATE(("TRANS_DT_CASE")::VARCHAR, 'YYYY-MM-DD') AS "HUB_OUT_SAMSUNG",
    'TR3020-10' AS "TR302010"
  FROM "layer_4_PORT_IN" AS input_0
  LEFT OUTER JOIN "layer_0_Aggregation_5" AS input_1
    ON input_0."TR205010" = input_1."EVENT_CODE" AND input_0."TO_NO" = input_1."DO_NO"
  )
     ORDER BY "TR302010", "TO_NO"
    SEGMENTED BY HASH("TR302010", "TO_NO") ALL NODES
  ;

  -- Node: ARRIVAL_DATE
  PERFORM DROP TABLE IF EXISTS "layer_4_ARRIVAL_DATE" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_4_ARRIVAL_DATE" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."RETURN_CARRIER_NAME",
    input_0."BOOKING_STATUS_NM",
    input_0."REMARKS_LAST_OCCURRENCE",
    input_0."LAST_OCCURRENCE",
    input_0."NEXT_STEP_ACTION_NM",
    input_0."TO_NO",
    input_0."AUTHORIZATION_NUMBER",
    input_0."AUTHORIZATION_DATE",
    input_0."ORIG_DO_NO",
    input_0."RDO_NUMBER",
    input_0."ORIGINAL_NF",
    input_0."ORIGINAL_NF_SERIES",
    input_0."CUSTOMER_NF",
    input_0."CUSTOMER_NF_SERIES",
    input_0."SHIP_TO_PARTY_NM",
    input_0."SHIP_TO_PARTY_CD",
    input_0."MATERIAL",
    input_0."ORIGINAL_QTY",
    input_0."MATERIAL_CODE",
    input_0."RETURN_QTY",
    input_0."ORDER_GROSS_VOLUME",
    input_0."ORDER_GROSS_WEIGHT",
    input_0."RET_ORDER_GROSS_VOLUME",
    input_0."RET_ORDER_GROSS_WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."SHIPPING_POINT_CODE",
    input_0."SUB_TRANS_TYPE",
    input_0."RETURN_REASON_CODE",
    input_0."RETURN_REASON_DESC",
    input_0."TRANS_ZONE",
    input_0."RDO_INSERT_DATE",
    input_0."RET_COLLECT_YN",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."OCCURRENCES_STATUS",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."RETURN_SHIPMENT",
    input_0."PLANT",
    input_0."RETURN_CARRIER_CODE",
    input_0."UDF",
    input_0."HUB_IN_CUSTOMER",
    input_0."HUB_OUT_CUSTOMER",
    input_0."COUNT",
    input_0."PORT_IN",
    input_0."PORT_OUT",
    input_0."HUB_IN_SAMSUNG",
    input_0."HUB_OUT_SAMSUNG",
    input_0."RETURN_BOOKING_DATE",
    input_0."STATUS_NM",
    input_0."GR_DATE",
    input_0."DIVISION_CD",
    input_0."COLLECT_DATE_TIME",
    input_0."NF_AMT",
    input_0."RETURN_NF_AMT",
    input_1."TRANS_DT",
    DATS_IS_VALID(input_1."TRANS_DT") AS "VALIDA_DATA",
    CASE "VALIDA_DATA" WHEN '1' THEN input_1."TRANS_DT" WHEN '0' THEN NULL END AS "TRANS_DT_CASE",
    TO_DATE(("TRANS_DT_CASE")::VARCHAR, 'YYYY-MM-DD') AS "ARRIVAL_DATE"
  FROM "layer_4_HUB_IN_SAMSUNG" AS input_0
  LEFT OUTER JOIN "layer_0_Aggregation_5" AS input_1
    ON input_0."TR302010" = input_1."EVENT_CODE" AND input_0."TO_NO" = input_1."DO_NO"
  )
     ORDER BY "ORIG_DO_NO"
    SEGMENTED BY HASH("ORIG_DO_NO") ALL NODES
  ;

  -- Node: RET_IOD_DT
  PERFORM DROP TABLE IF EXISTS "layer_4_RET_IOD_DT" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_4_RET_IOD_DT" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."RETURN_CARRIER_NAME",
    input_0."BOOKING_STATUS_NM",
    input_0."REMARKS_LAST_OCCURRENCE",
    input_0."LAST_OCCURRENCE",
    input_0."NEXT_STEP_ACTION_NM",
    input_0."TO_NO",
    input_0."AUTHORIZATION_NUMBER",
    input_0."AUTHORIZATION_DATE",
    input_0."ORIG_DO_NO",
    input_0."RDO_NUMBER",
    input_0."ORIGINAL_NF",
    input_0."ORIGINAL_NF_SERIES",
    input_0."CUSTOMER_NF",
    input_0."CUSTOMER_NF_SERIES",
    input_0."SHIP_TO_PARTY_NM",
    input_0."SHIP_TO_PARTY_CD",
    input_0."MATERIAL",
    input_0."ORIGINAL_QTY",
    input_0."MATERIAL_CODE",
    input_0."RETURN_QTY",
    input_0."ORDER_GROSS_VOLUME",
    input_0."ORDER_GROSS_WEIGHT",
    input_0."RET_ORDER_GROSS_VOLUME",
    input_0."RET_ORDER_GROSS_WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."SHIPPING_POINT_CODE",
    input_0."SUB_TRANS_TYPE",
    input_0."RETURN_REASON_CODE",
    input_0."RETURN_REASON_DESC",
    input_0."TRANS_ZONE",
    input_0."RDO_INSERT_DATE",
    input_0."RET_COLLECT_YN",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."OCCURRENCES_STATUS",
    input_0."BOOKING_STATUS_VARCHAR",
    input_0."RETURN_SHIPMENT",
    input_0."PLANT",
    input_0."RETURN_CARRIER_CODE",
    input_0."UDF",
    input_0."HUB_IN_CUSTOMER",
    input_0."HUB_OUT_CUSTOMER",
    input_0."COUNT",
    input_0."PORT_IN",
    input_0."PORT_OUT",
    input_0."HUB_IN_SAMSUNG",
    input_0."HUB_OUT_SAMSUNG",
    input_0."RETURN_BOOKING_DATE",
    input_0."ARRIVAL_DATE",
    input_0."STATUS_NM",
    input_0."GR_DATE",
    input_0."DIVISION_CD",
    input_0."COLLECT_DATE_TIME",
    input_0."NF_AMT",
    input_0."RETURN_NF_AMT",
    input_1."RET_IOD_DT"
  FROM "layer_4_ARRIVAL_DATE" AS input_0
  LEFT OUTER JOIN "layer_0_Aggregation_6" AS input_1
    ON input_0."ORIG_DO_NO" = input_1."REF_NO"
  )
     ORDER BY "DIVISION_CD"
    SEGMENTED BY HASH("DIVISION_CD") ALL NODES
  ;

  -- Layer 5: 2 nodes

  -- Node: DIVISION
  PERFORM DROP TABLE IF EXISTS "layer_5_DIVISION" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_5_DIVISION" ON COMMIT PRESERVE ROWS AS 
  SELECT
    input_0."RETURN_CARRIER_NAME",
    input_0."BOOKING_STATUS_NM",
    input_0."REMARKS_LAST_OCCURRENCE",
    input_0."LAST_OCCURRENCE",
    input_0."NEXT_STEP_ACTION_NM",
    input_0."TO_NO",
    input_0."AUTHORIZATION_NUMBER",
    input_0."AUTHORIZATION_DATE",
    input_0."ORIG_DO_NO",
    input_0."RDO_NUMBER",
    input_0."ORIGINAL_NF",
    input_0."ORIGINAL_NF_SERIES",
    input_0."CUSTOMER_NF",
    input_0."CUSTOMER_NF_SERIES",
    input_0."SHIP_TO_PARTY_NM",
    input_0."SHIP_TO_PARTY_CD",
    input_0."MATERIAL",
    input_0."ORIGINAL_QTY",
    input_0."MATERIAL_CODE",
    input_0."RETURN_QTY",
    input_0."ORDER_GROSS_VOLUME",
    input_0."ORDER_GROSS_WEIGHT",
    input_0."RET_ORDER_GROSS_VOLUME",
    input_0."RET_ORDER_GROSS_WEIGHT",
    input_0."TRUCK_PLATE",
    input_0."SHIPPING_POINT_CODE",
    input_0."SUB_TRANS_TYPE",
    input_0."RETURN_REASON_CODE",
    input_0."RETURN_REASON_DESC",
    input_0."TRANS_ZONE",
    input_0."RDO_INSERT_DATE",
    input_0."RET_COLLECT_YN",
    input_0."AGING",
    input_0."AGING_RANGE",
    input_0."RETURN_ETA",
    input_0."OCCURRENCES_STATUS",
    input_0."RETURN_SHIPMENT",
    input_0."PLANT",
    input_0."RETURN_CARRIER_CODE",
    input_0."UDF",
    input_0."HUB_IN_CUSTOMER",
    input_0."HUB_OUT_CUSTOMER",
    input_0."PORT_IN",
    input_0."PORT_OUT",
    input_0."HUB_IN_SAMSUNG",
    input_0."HUB_OUT_SAMSUNG",
    input_0."RETURN_BOOKING_DATE",
    input_0."ARRIVAL_DATE",
    input_0."STATUS_NM",
    input_0."GR_DATE",
    input_0."DIVISION_CD",
    input_0."COUNT",
    input_0."COLLECT_DATE_TIME",
    input_0."RET_IOD_DT",
    input_0."NF_AMT",
    input_0."RETURN_NF_AMT",
    input_1."DIVISION_NM",
    input_0."DIVISION_CD" || ' - ' || input_1."DIVISION_NM" AS "DIVISION"
  FROM "layer_4_RET_IOD_DT" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "DIVISION_NM",
      "DIVISION_CD"
    FROM "OW_SEDA_S".ODS_TSS_M_DIVISION
  ) AS input_1
    ON input_0."DIVISION_CD" = input_1."DIVISION_CD"
  ;

  -- Node: Projection
  PERFORM DROP TABLE IF EXISTS "layer_5_Projection" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_5_Projection" ON COMMIT PRESERVE ROWS AS 
  SELECT
    "RETURN_CARRIER_NAME",
    "BOOKING_STATUS_NM",
    "REMARKS_LAST_OCCURRENCE",
    "LAST_OCCURRENCE",
    "NEXT_STEP_ACTION_NM",
    "TO_NO",
    "AUTHORIZATION_NUMBER",
    "AUTHORIZATION_DATE",
    "ORIG_DO_NO",
    "RDO_NUMBER",
    "ORIGINAL_NF_SERIES",
    "CUSTOMER_NF",
    "ORIGINAL_NF",
    "CUSTOMER_NF_SERIES",
    "SHIP_TO_PARTY_NM",
    "SHIP_TO_PARTY_CD",
    "MATERIAL",
    "ORIGINAL_QTY",
    "MATERIAL_CODE",
    "RETURN_QTY",
    "ORDER_GROSS_VOLUME",
    "ORDER_GROSS_WEIGHT",
    "RET_ORDER_GROSS_VOLUME",
    "RET_ORDER_GROSS_WEIGHT",
    "TRUCK_PLATE",
    "SHIPPING_POINT_CODE",
    "SUB_TRANS_TYPE",
    "RETURN_REASON_CODE",
    "RETURN_REASON_DESC",
    "TRANS_ZONE",
    "RDO_INSERT_DATE",
    "RET_COLLECT_YN",
    "AGING",
    "AGING_RANGE",
    "RETURN_ETA",
    "OCCURRENCES_STATUS",
    "RETURN_SHIPMENT",
    "PLANT",
    "RETURN_CARRIER_CODE",
    "UDF",
    "HUB_IN_CUSTOMER",
    "HUB_OUT_CUSTOMER",
    "PORT_IN",
    "PORT_OUT",
    "HUB_IN_SAMSUNG",
    "HUB_OUT_SAMSUNG",
    "RETURN_BOOKING_DATE",
    "ARRIVAL_DATE",
    "STATUS_NM",
    "GR_DATE",
    "DIVISION",
    "COUNT",
    "COLLECT_DATE_TIME",
    "RET_IOD_DT",
    "NF_AMT",
    "RETURN_NF_AMT"
  FROM "layer_5_DIVISION"
  ;

  -- Materialize final result
  PERFORM CREATE TABLE IF NOT EXISTS OW_SEDA_S.VIEWCV_CV_TSS_IOD_RETURN_TRACKING AS
    SELECT * FROM "layer_5_Projection" WHERE 1=0;
  PERFORM TRUNCATE TABLE OW_SEDA_S.VIEWCV_CV_TSS_IOD_RETURN_TRACKING;
  PERFORM INSERT INTO OW_SEDA_S.VIEWCV_CV_TSS_IOD_RETURN_TRACKING
  SELECT * FROM "layer_5_Projection";

  PERFORM COMMIT;
  RAISE NOTICE 'Successfully loaded OW_SEDA_S.VIEWCV_CV_TSS_IOD_RETURN_TRACKING';

END;
$$;