CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_CV_TSS_IOD_STATUS_TOTAL_SDI" AS
SELECT
  "TRANSPORT_ID",
  "DISPATCH_GROUP_NO",
  "DISPATCH_NO",
  "ORDER_NO",
  "STATUS_NM",
  "BOOKING_STATUS_NM",
  "HEADER_DIVISION_NM",
  "DIVISION_NM",
  "DIVISION_CD",
  "SOURCE_CD",
  "ITEM_CD",
  "ITEM_NM",
  "ITEM_GRP_CD",
  "QTY",
  "SALES_QTY",
  "TRANS_CD",
  "TRANS_NM",
  "TRANS_PARENT_NM",
  "LAST_LEG_TRANS_CD",
  "LAST_LEG_TRANS_NM",
  "SUB_TRANS_TYPE",
  "BOOKING_TYPE",
  "SOLD_TO_CD",
  "SOLD_TO_NM",
  "DESTINATION_CD",
  "DESTINATION_NM",
  "CITY",
  "UDF",
  "VEHICLE_KIND_CD",
  "ETD",
  "GI_DT",
  "REAL_DEPT_DT",
  "REAL_ARRV_DT",
  "FINAL_PORT_ARRIVAL_DATE",
  "IOD_ORIGINAL_CREATE_DATE",
  "IOD_DT",
  "FIRSTBOOKING_DT",
  "BOOKING_DT",
  "TSS_ETA",
  "NF_SERIES",
  "NF_EXT_NO",
  "NF_INT_NO",
  "FIRST_DELAY_DAYS",
  "LAST_DELAY_DAYS",
  "TSSETA_DELAY_DAYS",
  "LEAD_TIME",
  "LAST_OCCR_RESP_VALID",
  "LAST_OCCR_RECEIVED",
  "LAST_OCCR_VALID",
  "LAST_OCCR_RESP_RECEIVED",
  "BOOKING_REQ_DATE",
  "FOLLOW_UP_NM",
  "FOLLOW_UP_UPDATE_ID",
  "FOLLOW_UP_UPDATE_DATE",
  "DO_NO",
  "RET_GR_UPDATE_DATE",
  "QTY_RET",
  "SALES_QTY_RET",
  "CUSTOMER_PO",
  "FINAL_ETA",
  "PRE_BOOKING_DATE",
  "IOD_CREATE_DATE",
  "NOTE",
  "RANGE_FIRST",
  "RANGE_LAST",
  "RANGE_TSSETA",
  "TRANS_PARENT_CD"
FROM (
  SELECT
    "TRANSPORT_ID",
    "TRANSPORT_ID" AS "TRANSPORT_ID_1",
    "DISPATCH_GROUP_NO",
    "DISPATCH_NO",
    "ORDER_NO",
    "STATUS_NM",
    "BOOKING_STATUS_NM",
    "HEADER_DIVISION_NM",
    "DIVISION_NM",
    "DIVISION_CD",
    "SOURCE_CD",
    "ITEM_CD",
    "ITEM_NM",
    "ITEM_GRP_CD",
    "QTY",
    "SALES_QTY",
    "TRANS_CD",
    "TRANS_NM",
    "TRANS_PARENT_NM",
    "LAST_LEG_TRANS_CD",
    "LAST_LEG_TRANS_NM",
    "SUB_TRANS_TYPE",
    "BOOKING_TYPE",
    "SOLD_TO_CD",
    "SOLD_TO_NM",
    "DESTINATION_CD",
    "DESTINATION_NM",
    "CITY",
    "UDF",
    "VEHICLE_KIND_CD",
    "ETD",
    "GI_DT",
    "REAL_DEPT_DT",
    "REAL_ARRV_DT",
    "FINAL_PORT_ARRIVAL_DATE",
    "IOD_ORIGINAL_CREATE_DATE",
    "IOD_DT",
    "FIRSTBOOKING_DT",
    "BOOKING_DT",
    "TSS_ETA",
    "NF_SERIES",
    "NF_EXT_NO",
    "NF_INT_NO",
    "FIRST_DELAY_DAYS",
    "LAST_DELAY_DAYS",
    "TSSETA_DELAY_DAYS",
    "LEAD_TIME",
    "LAST_OCCR_RESP_VALID",
    "LAST_OCCR_RECEIVED",
    "LAST_OCCR_VALID",
    "LAST_OCCR_RESP_RECEIVED",
    "BOOKING_REQ_DATE",
    "FOLLOW_UP_NM",
    "FOLLOW_UP_UPDATE_ID",
    "FOLLOW_UP_UPDATE_DATE",
    "DO_NO",
    "RET_GR_UPDATE_DATE",
    "QTY_RET",
    "SALES_QTY_RET",
    "CUSTOMER_PO",
    "FINAL_ETA",
    "PRE_BOOKING_DATE",
    "IOD_CREATE_DATE",
    "NOTE",
    "RANGE_FIRST",
    "RANGE_LAST",
    "RANGE_TSSETA",
    "TRANS_PARENT_CD"
  FROM (
    SELECT
      input_0."TRANSPORT_ID",
      input_1."DISPATCH_GROUP_NO",
      input_1."DISPATCH_NO",
      input_1."ORDER_NO",
      input_1."STATUS_NM",
      input_1."BOOKING_STATUS_NM",
      input_1."HEADER_DIVISION_NM",
      input_1."DIVISION_NM",
      input_1."DIVISION_CD",
      input_1."SOURCE_CD",
      input_1."ITEM_CD",
      input_1."ITEM_NM",
      input_1."ITEM_GRP_CD",
      input_1."QTY",
      input_1."SALES_QTY",
      input_1."TRANS_CD",
      input_1."TRANS_NM",
      input_1."TRANS_PARENT_NM",
      input_1."LAST_LEG_TRANS_CD",
      input_1."LAST_LEG_TRANS_NM",
      input_1."SUB_TRANS_TYPE",
      input_1."BOOKING_TYPE",
      input_1."SOLD_TO_CD",
      input_1."SOLD_TO_NM",
      input_1."DESTINATION_CD",
      input_1."DESTINATION_NM",
      input_1."CITY",
      input_1."UDF",
      input_1."VEHICLE_KIND_CD",
      input_1."ETD",
      input_1."GI_DT",
      input_1."REAL_DEPT_DT",
      input_1."REAL_ARRV_DT",
      input_1."FINAL_PORT_ARRIVAL_DATE",
      input_1."IOD_ORIGINAL_CREATE_DATE",
      input_1."IOD_DT",
      input_1."FIRSTBOOKING_DT",
      input_1."BOOKING_DT",
      input_1."TSS_ETA",
      input_1."NF_SERIES",
      input_1."NF_EXT_NO",
      input_1."NF_INT_NO",
      input_1."FIRST_DELAY_DAYS",
      input_1."LAST_DELAY_DAYS",
      input_1."TSSETA_DELAY_DAYS",
      input_1."LEAD_TIME",
      input_1."LAST_OCCR_RESP_VALID",
      input_1."LAST_OCCR_RECEIVED",
      input_1."LAST_OCCR_VALID",
      input_1."LAST_OCCR_RESP_RECEIVED",
      input_1."BOOKING_REQ_DATE",
      input_1."FOLLOW_UP_NM",
      input_1."FOLLOW_UP_UPDATE_ID",
      input_1."FOLLOW_UP_UPDATE_DATE",
      input_1."DO_NO",
      input_1."RET_GR_UPDATE_DATE",
      input_1."QTY_RET",
      input_1."SALES_QTY_RET",
      input_1."CUSTOMER_PO",
      input_1."FINAL_ETA",
      input_1."PRE_BOOKING_DATE",
      input_1."IOD_CREATE_DATE",
      input_1."NOTE",
      input_1."RANGE_FIRST",
      input_1."RANGE_LAST",
      input_1."RANGE_TSSETA",
      input_1."TRANS_PARENT_CD"
    FROM (
      SELECT
        "ORDER_NO",
        "TRANSPORT_ID"
      FROM "OW_SEDA_S".SDI_TSS_OD_ORDERS
    ) AS input_0
    LEFT OUTER JOIN (
      SELECT
        "DISPATCH_GROUP_NO",
        "DISPATCH_NO",
        "ORDER_NO",
        "STATUS_NM",
        "BOOKING_STATUS_NM",
        "HEADER_DIVISION_NM",
        "DIVISION_NM",
        "DIVISION_CD",
        "SOURCE_CD",
        "ITEM_CD",
        "ITEM_NM",
        "ITEM_GRP_CD",
        "QTY",
        "SALES_QTY",
        "TRANS_CD",
        "TRANS_NM",
        "TRANS_PARENT_NM",
        "LAST_LEG_TRANS_CD",
        "LAST_LEG_TRANS_NM",
        "SUB_TRANS_TYPE",
        "BOOKING_TYPE",
        "SOLD_TO_CD",
        "SOLD_TO_NM",
        "DESTINATION_CD",
        "DESTINATION_NM",
        "CITY",
        "UDF",
        "VEHICLE_KIND_CD",
        "ETD",
        "GI_DT",
        "REAL_DEPT_DT",
        "REAL_ARRV_DT",
        "FINAL_PORT_ARRIVAL_DATE",
        "IOD_ORIGINAL_CREATE_DATE",
        "IOD_DT",
        "FIRSTBOOKING_DT",
        "BOOKING_DT",
        "TSS_ETA",
        "NF_SERIES",
        "NF_EXT_NO",
        "NF_INT_NO",
        "FIRST_DELAY_DAYS",
        "LAST_DELAY_DAYS",
        "TSSETA_DELAY_DAYS",
        "LEAD_TIME",
        "LAST_OCCR_RESP_VALID",
        "LAST_OCCR_RECEIVED",
        "LAST_OCCR_VALID",
        "LAST_OCCR_RESP_RECEIVED",
        "BOOKING_REQ_DATE",
        "FOLLOW_UP_NM",
        "FOLLOW_UP_UPDATE_ID",
        "FOLLOW_UP_UPDATE_DATE",
        "DO_NO",
        "RET_GR_UPDATE_DATE",
        "QTY_RET",
        "SALES_QTY_RET",
        "CUSTOMER_PO",
        "FINAL_ETA",
        "PRE_BOOKING_DATE",
        "IOD_CREATE_DATE",
        "NOTE",
        "FIRST_DELAY_DESCRIPTION",
        "LAST_DELAY_DESCRIPTION",
        "TSSETA_DELAY_DESCRIPTION",
        "FORECAST_YN",
        "BOOKING_PENDING_CURRENT_MONTH",
        "TRANS_PARENT_CD",
        CASE "FIRST_DELAY_DESCRIPTION"
          WHEN 'IN_DUE_COMING'
          THEN 'In Due Upcomming'
          WHEN 'IN_DUE_TODAY'
          THEN 'In Due'
          WHEN 'IN_DUE'
          THEN '1 Day'
          WHEN 'TWO_FIVE'
          THEN '2-5 Days'
          WHEN 'SIX_SEVEN'
          THEN '6-7 Days'
          WHEN 'EIGHT_FOURTEEN'
          THEN '8-14 Days'
          WHEN 'FIFTEEN_THIRTY'
          THEN '15-30 Days'
          WHEN 'THIRTYONE_MORE'
          THEN 'Over 31 Days'
          ELSE ''
        END AS "RANGE_FIRST",
        CASE "LAST_DELAY_DESCRIPTION"
          WHEN 'IN_DUE_COMING'
          THEN 'In Due Upcomming'
          WHEN 'IN_DUE_TODAY'
          THEN 'In Due'
          WHEN 'IN_DUE'
          THEN '1 Day'
          WHEN 'TWO_FIVE'
          THEN '2-5 Days'
          WHEN 'SIX_SEVEN'
          THEN '6-7 Days'
          WHEN 'EIGHT_FOURTEEN'
          THEN '8-14 Days'
          WHEN 'FIFTEEN_THIRTY'
          THEN '15-30 Days'
          WHEN 'THIRTYONE_MORE'
          THEN 'Over 31 Days'
          ELSE ''
        END AS "RANGE_LAST",
        CASE "TSSETA_DELAY_DESCRIPTION"
          WHEN 'IN_DUE_COMING'
          THEN 'In Due Upcomming'
          WHEN 'IN_DUE_TODAY'
          THEN 'In Due'
          WHEN 'IN_DUE'
          THEN '1 Day'
          WHEN 'TWO_FIVE'
          THEN '2-5 Days'
          WHEN 'SIX_SEVEN'
          THEN '6-7 Days'
          WHEN 'EIGHT_FOURTEEN'
          THEN '8-14 Days'
          WHEN 'FIFTEEN_THIRTY'
          THEN '15-30 Days'
          WHEN 'THIRTYONE_MORE'
          THEN 'Over 31 Days'
          ELSE ''
        END AS "RANGE_TSSETA"
      FROM "OW_SEDA_S".SDI_TSS_MVW_IOD_STATUS_REPORT
    ) AS input_1
      ON input_0."ORDER_NO" = input_1."ORDER_NO"
  ) AS Join_1
) AS Projection_3