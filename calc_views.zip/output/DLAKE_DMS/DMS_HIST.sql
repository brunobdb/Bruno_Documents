CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_DMS_HIST" AS
SELECT
  "DC",
  "COMPANY",
  "COMPANYCD",
  "PRODUCTGROUP",
  "MARKETNAME",
  "SEGMENT",
  "SEGMENT_AGE",
  "PRODUCTTYPE",
  "ITEM",
  "DCID",
  "VRESELLER",
  "LOCATIONID",
  "DT_YW",
  "WR",
  "WWWMM",
  "LOCATIONNAME",
  "LATITUDE",
  "LONGITUDE",
  "BRANCH",
  "REGIONID",
  "REGIONNAME",
  "OUTFLOW",
  "START_DT",
  "EOH_R",
  "Sell-out_YW",
  "Sell-in_YW",
  "Sell-thru_YW",
  "EOH_YW"
FROM (
  SELECT
    input_0."DC",
    input_0."COMPANY",
    input_0."COMPANYCD",
    input_0."PRODUCTGROUP",
    input_0."MARKETNAME",
    input_0."PRODUCTTYPE",
    input_0."ITEM",
    input_0."DCID",
    input_0."VRESELLER",
    input_0."LOCATIONID",
    input_0."DT_YW",
    input_0."EOH_R",
    input_0."Sell-out_YW",
    input_0."Sell-in_YW",
    input_0."Sell-thru_YW",
    input_0."EOH_YW",
    input_0."LOCATIONNAME",
    input_0."LATITUDE",
    input_0."LONGITUDE",
    input_0."SEGMENT",
    input_0."SEGMENT_AGE",
    input_0."WR",
    input_0."WWWMM",
    input_0."START_DT",
    input_1."BRANCH",
    input_1."REGIONID",
    input_1."REGIONNAME",
    input_1."OUTFLOW"
  FROM (
    SELECT
      input_0."DC",
      input_0."COMPANY",
      input_0."COMPANYCD",
      input_0."PRODUCTGROUP",
      input_0."MARKETNAME",
      input_0."PRODUCTTYPE",
      input_0."ITEM",
      input_0."DCID",
      input_0."VRESELLER",
      input_0."LOCATIONID",
      input_0."DT_YW",
      input_0."WR",
      input_0."WWWMM",
      input_0."EOH_R",
      input_0."Sell-out_YW",
      input_0."Sell-in_YW",
      input_0."Sell-thru_YW",
      input_0."EOH_YW",
      input_0."LOCATIONNAME",
      input_0."LATITUDE",
      input_0."LONGITUDE",
      input_0."START_DT",
      input_1."SEGMENT",
      input_1."SEGMENT_AGE"
    FROM (
      SELECT
        input_0."DC",
        input_0."COMPANY",
        input_0."COMPANYCD",
        input_0."ITEM",
        input_0."DCID",
        input_0."VRESELLER",
        input_0."LOCATIONID",
        input_0."DT_YW",
        input_0."EOH_R",
        input_0."Sell-out_YW",
        input_0."Sell-in_YW",
        input_0."Sell-thru_YW",
        input_0."EOH_YW",
        input_0."LOCATIONNAME",
        input_0."LATITUDE",
        input_0."LONGITUDE",
        input_0."WR",
        input_0."WWWMM",
        input_0."START_DT",
        input_1."PRODUCTGROUP",
        input_1."MARKETNAME",
        input_1."PRODUCTTYPE"
      FROM (
        SELECT
          input_0."ITEM",
          input_0."DCID",
          input_0."VRESELLER",
          input_0."LOCATIONID",
          input_0."DT_YW",
          input_0."EOH_R",
          input_0."Sell-out_YW",
          input_0."Sell-in_YW",
          input_0."Sell-thru_YW",
          input_0."EOH_YW",
          input_0."LOCATIONNAME",
          input_0."LATITUDE",
          input_0."LONGITUDE",
          input_0."WR",
          input_0."WWWMM",
          input_0."START_DT",
          input_1."DC",
          input_1."COMPANY",
          input_1."COMPANYCD"
        FROM (
          SELECT
            input_0."ITEM",
            input_0."DCID",
            input_0."VRESELLER",
            input_0."LOCATIONID",
            input_0."DT_YW",
            input_0."EOH_R",
            input_0."Sell-out_YW",
            input_0."Sell-in_YW",
            input_0."Sell-thru_YW",
            input_0."EOH_YW",
            input_0."LOCATIONNAME",
            input_0."LATITUDE",
            input_0."LONGITUDE",
            input_1."WR",
            input_1."WWWMM",
            input_1."START_DT"
          FROM (
            SELECT
              input_0."ITEM",
              input_0."DCID",
              input_0."VRESELLER",
              input_0."LOCATIONID",
              input_0."DT_YW",
              input_0."EOH(R)_YW" AS "EOH_R",
              input_0."Sell-out_YW",
              input_0."Sell-in_YW",
              input_0."Sell-thru_YW",
              input_0."EOH_YW",
              input_1."LOCATIONNAME",
              input_1."LATITUDE",
              input_1."LONGITUDE"
            FROM "OW_SELA".FACT_STOCK_SALES AS input_0
            LEFT OUTER JOIN "OW_SELA".DIM_COUNTRY AS input_1
              ON input_0."LOCATIONID" = input_1."LOCATIONID"
          ) AS input_0
          INNER JOIN (
            SELECT
              input_0."MAXSTARTDT",
              input_1."YYYYWW",
              input_1."WWWMM",
              input_1."START_DT",
              CASE
                WHEN TRUNC((
                  TIMESTAMPDIFF(dd, input_0."MAXSTARTDT", START_DT) / 7
                ), 0) = 0
                THEN 'W-0'
                ELSE 'W' + REPLACE(
                  CAST(TRUNC((
                    TIMESTAMPDIFF(dd, input_0."MAXSTARTDT", START_DT) / 7
                  ), 0) AS VARCHAR),
                  '.000000',
                  ''
                )
              END AS "WR"
            FROM "OW_SELA".CURRENTWEEK AS input_0
            CROSS JOIN "OW_SELA".DIM_WEEK AS input_1
          ) AS input_1
            ON input_0."DT_YW" = input_1."YYYYWW"
        ) AS input_0
        LEFT OUTER JOIN (
          SELECT
            "DC",
            "DCID",
            "COMPANY",
            "COMPANYCD"
          FROM "OW_SELA".DIM_DC
        ) AS input_1
          ON input_0."DCID" = input_1."DCID"
      ) AS input_0
      LEFT OUTER JOIN (
        SELECT
          "PRODUCTGROUP",
          "MARKETNAME",
          "ITEM",
          "PRODUCTTYPE"
        FROM "OW_SELA".DIM_PRODUCT
      ) AS input_1
        ON input_0."ITEM" = input_1."ITEM"
    ) AS input_0
    LEFT OUTER JOIN "OW_SELA".DIM_MN_SEGMENT AS input_1
      ON input_0."MARKETNAME" = input_1."MARKETNAME"
  ) AS input_0
  LEFT OUTER JOIN "OW_SELA".DIM_COUNTRY_BRANCH AS input_1
    ON input_0."LOCATIONID" = input_1."LOCATIONID"
) AS CountryBranchMerge
GROUP BY
  "DC",
  "COMPANY",
  "COMPANYCD",
  "PRODUCTGROUP",
  "MARKETNAME",
  "SEGMENT",
  "SEGMENT_AGE",
  "PRODUCTTYPE",
  "ITEM",
  "DCID",
  "VRESELLER",
  "LOCATIONID",
  "DT_YW",
  "WR",
  "WWWMM",
  "LOCATIONNAME",
  "LATITUDE",
  "LONGITUDE",
  "BRANCH",
  "REGIONID",
  "REGIONNAME",
  "OUTFLOW",
  "START_DT",
  "EOH_R",
  "Sell-out_YW",
  "Sell-in_YW",
  "Sell-thru_YW",
  "EOH_YW"