CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_DMS_FCST_W3" AS
SELECT
  "COMPANYCD",
  "MARKETNAME",
  "PRODUCTTYPE",
  "DCID",
  "VRESELLER",
  "YYYYWW",
  "WR",
  "WWWMM",
  "Sell-in_YW",
  "Sell-out_YW",
  "Sell-thru_YW",
  "EOH_YW",
  "EOH_R"
FROM (
  SELECT
    "COMPANYCD",
    "MARKETNAME",
    "PRODUCTTYPE",
    "DCID",
    "VRESELLER",
    "YYYYWW",
    "WR",
    "WWWMM",
    NULL AS "SELL-IN_YW",
    "Sellout_CW_fcst" AS "SELL-OUT_YW",
    "SellThru_CW" AS "SELL-THRU_YW",
    NULL AS "EOH_YW",
    "EOH_R_CW" AS "EOH_R"
  FROM (
    SELECT
      "COMPANYCD",
      "MARKETNAME",
      "PRODUCTTYPE",
      "DCID",
      "VRESELLER",
      "YYYYWW",
      "WR",
      "WWWMM",
      "EOH_R_CW",
      "SellThru_CW",
      "Sellout_CW_fcst"
    FROM (
      SELECT
        input_0."TARGET_WOS_R",
        input_0."TARGET_WOS_DC",
        input_1."WWWMM",
        input_1."YYYYWW",
        input_1."WR",
        input_1."VL_GROWTH",
        input_1."COMPANYCD",
        input_1."MARKETNAME",
        input_1."PRODUCTTYPE",
        input_1."DCID",
        input_1."VRESELLER",
        input_1."Sell-in_YW",
        input_1."Sell-out_YW",
        input_1."Sell-thru_YW",
        input_1."EOH_YW",
        input_1."EOH_R",
        input_1."SelloutSum3W",
        input_1."SellThruSum3W",
        input_1."EOH_R_LW",
        input_1."Sellout_CW_fcst",
        input_1."SelloutSum4W",
        input_1."EOH_LW",
        CASE
          WHEN "EOH_R_TARGET" >= input_1."EOH_R_LW" - input_1."Sellout_CW_fcst"
          THEN "EOH_R_TARGET"
          ELSE input_1."EOH_R_LW" - input_1."Sellout_CW_fcst"
        END AS "EOH_R_CW",
        CASE
          WHEN input_1."EOH_R_LW" - "EOH_R_CW" < input_1."Sellout_CW_fcst"
          THEN "EOH_R_CW" + input_1."Sellout_CW_fcst" - input_1."EOH_R_LW"
          ELSE input_1."EOH_R_LW" - (
            input_1."Sellout_CW_fcst" + "EOH_R_CW"
          )
        END AS "SellThru_CW",
        ROUND(
          (
            (
              input_1."SelloutSum3W" + input_1."Sellout_CW_fcst"
            ) / 4
          ) * input_0."TARGET_WOS_R",
          0
        ) AS "EOH_R_TARGET"
      FROM (
        SELECT
          "TARGET_WOS_R",
          "TARGET_WOS_DC"
        FROM "OW_SELA".WOS_PARAMETERS
      ) AS input_0
      CROSS JOIN (
        SELECT
          input_0."VL_GROWTH",
          input_1."WWWMM",
          input_1."YYYYWW",
          input_1."WR",
          input_1."COMPANYCD",
          input_1."MARKETNAME",
          input_1."PRODUCTTYPE",
          input_1."DCID",
          input_1."VRESELLER",
          input_1."Sell-in_YW",
          input_1."Sell-out_YW",
          input_1."Sell-thru_YW",
          input_1."EOH_YW",
          input_1."EOH_R",
          input_1."SelloutSum3W",
          input_1."SellThruSum3W",
          input_1."EOH_R_LW",
          input_1."SelloutSum4W",
          input_1."EOH_LW",
          ROUND((
            input_1."SelloutSum4W" / 4
          ) * (
            1 + input_0."VL_GROWTH"
          ), 0) AS "Sellout_CW_fcst"
        FROM (
          SELECT
            "VL_GROWTH",
            "PRODUCTTYPE",
            "MONTH1"
          FROM "OW_SELA".DIM_GROWTH
        ) AS input_0
        INNER JOIN (
          SELECT
            input_0."COMPANYCD",
            input_0."MARKETNAME",
            input_0."PRODUCTTYPE",
            input_0."DCID",
            input_0."VRESELLER",
            input_0."Sell-in_YW",
            input_0."Sell-out_YW",
            input_0."Sell-thru_YW",
            input_0."EOH_YW",
            input_0."EOH_R",
            input_0."SelloutSum3W",
            input_0."SellThruSum3W",
            input_0."EOH_R_LW",
            input_0."SelloutSum4W",
            input_0."EOH_LW",
            input_1."WWWMM",
            input_1."YYYYWW",
            input_1."WR"
          FROM (
            SELECT
              "COMPANYCD",
              "MARKETNAME",
              "PRODUCTTYPE",
              "DCID",
              "VRESELLER",
              "Sell-in_YW",
              "Sell-out_YW",
              "Sell-thru_YW",
              "EOH_YW",
              "EOH_R",
              "SelloutSum3W",
              "SellThruSum3W",
              "EOH_R_LW",
              "SelloutSum4W",
              "EOH_LW"
            FROM (
              SELECT
                "COMPANYCD",
                "MARKETNAME",
                "PRODUCTTYPE",
                "DCID",
                "VRESELLER",
                "WWWMM",
                "YYYYWW",
                "WR",
                "Sell-in_YW",
                "Sell-out_YW",
                "Sell-thru_YW",
                "EOH_YW",
                "EOH_R",
                CASE
                  WHEN "WR" IN ('W2')
                  AND (
                    NOT (
                      (
                        "VRESELLER"
                      ) IS NULL
                    ) AND NOT (
                      "VRESELLER" IN ('-')
                    )
                  )
                  THEN "EOH_R"
                  ELSE NULL
                END AS "EOH_R_LW",
                CASE
                  WHEN (
                    "WR" IN ('W-0') OR "WR" IN ('W1') OR "WR" IN ('W2')
                  )
                  AND (
                    NOT (
                      (
                        "VRESELLER"
                      ) IS NULL
                    ) AND NOT (
                      "VRESELLER" IN ('-')
                    )
                  )
                  THEN "Sell-out_YW"
                  ELSE NULL
                END AS "SelloutSum3W",
                CASE
                  WHEN (
                    "WR" IN ('W-0') OR "WR" IN ('W1') OR "WR" IN ('W2')
                  )
                  AND (
                    NOT (
                      (
                        "VRESELLER"
                      ) IS NULL
                    ) AND NOT (
                      "VRESELLER" IN ('-')
                    )
                  )
                  THEN "Sell-thru_YW"
                  ELSE NULL
                END AS "SellThruSum3W",
                CASE WHEN "WR" IN ('W2') THEN "EOH_YW" ELSE NULL END AS "EOH_LW",
                CASE
                  WHEN NOT (
                    (
                      "VRESELLER"
                    ) IS NULL
                  ) AND NOT (
                    "VRESELLER" IN ('-')
                  )
                  THEN "Sell-out_YW"
                  ELSE NULL
                END AS "SelloutSum4W"
              FROM OW_SEDA_S.DMS_FCST_W2
            ) AS Projection_1
            GROUP BY
              "COMPANYCD",
              "MARKETNAME",
              "PRODUCTTYPE",
              "DCID",
              "VRESELLER",
              "Sell-in_YW",
              "Sell-out_YW",
              "Sell-thru_YW",
              "EOH_YW",
              "EOH_R",
              "SelloutSum3W",
              "SellThruSum3W",
              "EOH_R_LW",
              "SelloutSum4W",
              "EOH_LW"
          ) AS input_0
          CROSS JOIN (
            SELECT
              "YYYYWW",
              "WWWMM",
              "START_DT",
              "END_DT",
              "MAXSTARTDT",
              NULL AS "WR"
            FROM (
              SELECT
                input_0."MAXSTARTDT",
                input_1."YYYYWW",
                input_1."WWWMM",
                input_1."START_DT",
                input_1."END_DT"
              FROM "OW_SELA".CURRENTWEEK AS input_0
              CROSS JOIN "OW_SELA".DIM_WEEK AS input_1
            ) AS Join_3
          ) AS input_1
        ) AS input_1
          ON input_0."MONTH1" = input_1."WWWMM"
          AND input_0."PRODUCTTYPE" = input_1."PRODUCTTYPE"
      ) AS input_1
    ) AS Join_2
    GROUP BY
      "COMPANYCD",
      "MARKETNAME",
      "PRODUCTTYPE",
      "DCID",
      "VRESELLER",
      "YYYYWW",
      "WR",
      "WWWMM",
      "EOH_R_CW",
      "SellThru_CW",
      "Sellout_CW_fcst"
  ) AS DCwithReseller
  UNION ALL
  SELECT
    "COMPANYCD",
    "MARKETNAME",
    "PRODUCTTYPE",
    "DCID",
    NULL AS "VRESELLER",
    "YYYYWW",
    "WR",
    "WWWMM",
    "Sellin_CW" AS "SELL-IN_YW",
    NULL AS "SELL-OUT_YW",
    NULL AS "SELL-THRU_YW",
    "EOH_CW" AS "EOH_YW",
    NULL AS "EOH_R"
  FROM (
    SELECT
      "TARGET_WOS_DC",
      "COMPANYCD",
      "MARKETNAME",
      "PRODUCTTYPE",
      "DCID",
      "YYYYWW",
      "WR",
      "WWWMM",
      "SellThruSum3W",
      "SellThru_CW",
      "EOH_LW",
      NULL AS "EOH_CW_Target",
      NULL AS "Sellin_CW",
      NULL AS "EOH_CW"
    FROM (
      SELECT
        input_0."TARGET_WOS_R",
        input_0."TARGET_WOS_DC",
        input_1."WWWMM",
        input_1."YYYYWW",
        input_1."WR",
        input_1."VL_GROWTH",
        input_1."COMPANYCD",
        input_1."MARKETNAME",
        input_1."PRODUCTTYPE",
        input_1."DCID",
        input_1."VRESELLER",
        input_1."Sell-in_YW",
        input_1."Sell-out_YW",
        input_1."Sell-thru_YW",
        input_1."EOH_YW",
        input_1."EOH_R",
        input_1."SelloutSum3W",
        input_1."SellThruSum3W",
        input_1."EOH_R_LW",
        input_1."Sellout_CW_fcst",
        input_1."SelloutSum4W",
        input_1."EOH_LW",
        CASE
          WHEN "EOH_R_TARGET" >= input_1."EOH_R_LW" - input_1."Sellout_CW_fcst"
          THEN "EOH_R_TARGET"
          ELSE input_1."EOH_R_LW" - input_1."Sellout_CW_fcst"
        END AS "EOH_R_CW",
        CASE
          WHEN input_1."EOH_R_LW" - "EOH_R_CW" < input_1."Sellout_CW_fcst"
          THEN "EOH_R_CW" + input_1."Sellout_CW_fcst" - input_1."EOH_R_LW"
          ELSE input_1."EOH_R_LW" - (
            input_1."Sellout_CW_fcst" + "EOH_R_CW"
          )
        END AS "SellThru_CW",
        ROUND(
          (
            (
              input_1."SelloutSum3W" + input_1."Sellout_CW_fcst"
            ) / 4
          ) * input_0."TARGET_WOS_R",
          0
        ) AS "EOH_R_TARGET"
      FROM (
        SELECT
          "TARGET_WOS_R",
          "TARGET_WOS_DC"
        FROM "OW_SELA".WOS_PARAMETERS
      ) AS input_0
      CROSS JOIN (
        SELECT
          input_0."VL_GROWTH",
          input_1."WWWMM",
          input_1."YYYYWW",
          input_1."WR",
          input_1."COMPANYCD",
          input_1."MARKETNAME",
          input_1."PRODUCTTYPE",
          input_1."DCID",
          input_1."VRESELLER",
          input_1."Sell-in_YW",
          input_1."Sell-out_YW",
          input_1."Sell-thru_YW",
          input_1."EOH_YW",
          input_1."EOH_R",
          input_1."SelloutSum3W",
          input_1."SellThruSum3W",
          input_1."EOH_R_LW",
          input_1."SelloutSum4W",
          input_1."EOH_LW",
          ROUND((
            input_1."SelloutSum4W" / 4
          ) * (
            1 + input_0."VL_GROWTH"
          ), 0) AS "Sellout_CW_fcst"
        FROM (
          SELECT
            "VL_GROWTH",
            "PRODUCTTYPE",
            "MONTH1"
          FROM "OW_SELA".DIM_GROWTH
        ) AS input_0
        INNER JOIN (
          SELECT
            input_0."COMPANYCD",
            input_0."MARKETNAME",
            input_0."PRODUCTTYPE",
            input_0."DCID",
            input_0."VRESELLER",
            input_0."Sell-in_YW",
            input_0."Sell-out_YW",
            input_0."Sell-thru_YW",
            input_0."EOH_YW",
            input_0."EOH_R",
            input_0."SelloutSum3W",
            input_0."SellThruSum3W",
            input_0."EOH_R_LW",
            input_0."SelloutSum4W",
            input_0."EOH_LW",
            input_1."WWWMM",
            input_1."YYYYWW",
            input_1."WR"
          FROM (
            SELECT
              "COMPANYCD",
              "MARKETNAME",
              "PRODUCTTYPE",
              "DCID",
              "VRESELLER",
              "Sell-in_YW",
              "Sell-out_YW",
              "Sell-thru_YW",
              "EOH_YW",
              "EOH_R",
              "SelloutSum3W",
              "SellThruSum3W",
              "EOH_R_LW",
              "SelloutSum4W",
              "EOH_LW"
            FROM (
              SELECT
                "COMPANYCD",
                "MARKETNAME",
                "PRODUCTTYPE",
                "DCID",
                "VRESELLER",
                "WWWMM",
                "YYYYWW",
                "WR",
                "Sell-in_YW",
                "Sell-out_YW",
                "Sell-thru_YW",
                "EOH_YW",
                "EOH_R",
                CASE
                  WHEN "WR" IN ('W2')
                  AND (
                    NOT (
                      (
                        "VRESELLER"
                      ) IS NULL
                    ) AND NOT (
                      "VRESELLER" IN ('-')
                    )
                  )
                  THEN "EOH_R"
                  ELSE NULL
                END AS "EOH_R_LW",
                CASE
                  WHEN (
                    "WR" IN ('W-0') OR "WR" IN ('W1') OR "WR" IN ('W2')
                  )
                  AND (
                    NOT (
                      (
                        "VRESELLER"
                      ) IS NULL
                    ) AND NOT (
                      "VRESELLER" IN ('-')
                    )
                  )
                  THEN "Sell-out_YW"
                  ELSE NULL
                END AS "SelloutSum3W",
                CASE
                  WHEN (
                    "WR" IN ('W-0') OR "WR" IN ('W1') OR "WR" IN ('W2')
                  )
                  AND (
                    NOT (
                      (
                        "VRESELLER"
                      ) IS NULL
                    ) AND NOT (
                      "VRESELLER" IN ('-')
                    )
                  )
                  THEN "Sell-thru_YW"
                  ELSE NULL
                END AS "SellThruSum3W",
                CASE WHEN "WR" IN ('W2') THEN "EOH_YW" ELSE NULL END AS "EOH_LW",
                CASE
                  WHEN NOT (
                    (
                      "VRESELLER"
                    ) IS NULL
                  ) AND NOT (
                    "VRESELLER" IN ('-')
                  )
                  THEN "Sell-out_YW"
                  ELSE NULL
                END AS "SelloutSum4W"
              FROM OW_SEDA_S.DMS_FCST_W2
            ) AS Projection_1
            GROUP BY
              "COMPANYCD",
              "MARKETNAME",
              "PRODUCTTYPE",
              "DCID",
              "VRESELLER",
              "Sell-in_YW",
              "Sell-out_YW",
              "Sell-thru_YW",
              "EOH_YW",
              "EOH_R",
              "SelloutSum3W",
              "SellThruSum3W",
              "EOH_R_LW",
              "SelloutSum4W",
              "EOH_LW"
          ) AS input_0
          CROSS JOIN (
            SELECT
              "YYYYWW",
              "WWWMM",
              "START_DT",
              "END_DT",
              "MAXSTARTDT",
              NULL AS "WR"
            FROM (
              SELECT
                input_0."MAXSTARTDT",
                input_1."YYYYWW",
                input_1."WWWMM",
                input_1."START_DT",
                input_1."END_DT"
              FROM "OW_SELA".CURRENTWEEK AS input_0
              CROSS JOIN "OW_SELA".DIM_WEEK AS input_1
            ) AS Join_3
          ) AS input_1
        ) AS input_1
          ON input_0."MONTH1" = input_1."WWWMM"
          AND input_0."PRODUCTTYPE" = input_1."PRODUCTTYPE"
      ) AS input_1
    ) AS Join_2
    GROUP BY
      "TARGET_WOS_DC",
      "COMPANYCD",
      "MARKETNAME",
      "PRODUCTTYPE",
      "DCID",
      "YYYYWW",
      "WR",
      "WWWMM",
      "SellThruSum3W",
      "SellThru_CW",
      "EOH_LW"
  ) AS DCconsolidReseller
  UNION ALL
  SELECT
    "COMPANYCD",
    "MARKETNAME",
    "PRODUCTTYPE",
    "DCID",
    "VRESELLER",
    "YYYYWW",
    "WR",
    "WWWMM",
    "Sell-in_YW" AS "SELL-IN_YW",
    "Sell-out_YW" AS "SELL-OUT_YW",
    "Sell-thru_YW" AS "SELL-THRU_YW",
    "EOH_YW",
    "EOH_R"
  FROM (
    SELECT
      "COMPANYCD",
      "MARKETNAME",
      "PRODUCTTYPE",
      "DCID",
      "VRESELLER",
      "WWWMM",
      "YYYYWW",
      "WR",
      "Sell-in_YW",
      "Sell-out_YW",
      "Sell-thru_YW",
      "EOH_YW",
      "EOH_R",
      CASE
        WHEN "WR" IN ('W2')
        AND (
          NOT (
            (
              "VRESELLER"
            ) IS NULL
          ) AND NOT (
            "VRESELLER" IN ('-')
          )
        )
        THEN "EOH_R"
        ELSE NULL
      END AS "EOH_R_LW",
      CASE
        WHEN (
          "WR" IN ('W-0') OR "WR" IN ('W1') OR "WR" IN ('W2')
        )
        AND (
          NOT (
            (
              "VRESELLER"
            ) IS NULL
          ) AND NOT (
            "VRESELLER" IN ('-')
          )
        )
        THEN "Sell-out_YW"
        ELSE NULL
      END AS "SelloutSum3W",
      CASE
        WHEN (
          "WR" IN ('W-0') OR "WR" IN ('W1') OR "WR" IN ('W2')
        )
        AND (
          NOT (
            (
              "VRESELLER"
            ) IS NULL
          ) AND NOT (
            "VRESELLER" IN ('-')
          )
        )
        THEN "Sell-thru_YW"
        ELSE NULL
      END AS "SellThruSum3W",
      CASE WHEN "WR" IN ('W2') THEN "EOH_YW" ELSE NULL END AS "EOH_LW",
      CASE
        WHEN NOT (
          (
            "VRESELLER"
          ) IS NULL
        ) AND NOT (
          "VRESELLER" IN ('-')
        )
        THEN "Sell-out_YW"
        ELSE NULL
      END AS "SelloutSum4W"
    FROM OW_SEDA_S.DMS_FCST_W2
  ) AS Projection_1
) AS Union_1
GROUP BY
  "COMPANYCD",
  "MARKETNAME",
  "PRODUCTTYPE",
  "DCID",
  "VRESELLER",
  "YYYYWW",
  "WR",
  "WWWMM",
  "Sell-in_YW",
  "Sell-out_YW",
  "Sell-thru_YW",
  "EOH_YW",
  "EOH_R"