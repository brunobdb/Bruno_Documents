CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_DMS_FCST_SUM_TMP" AS
SELECT
  "COMPANYCD",
  "COMPANY",
  "MARKETNAME",
  "PRODUCTTYPE",
  "SEGMENT",
  "SEGMENT_AGE",
  "DCID",
  "DC",
  "VRESELLER",
  "YYYYWW",
  "START_DT",
  "WR",
  "WWWMM",
  "Sell-in_YW",
  "Sell-out_YW",
  "Sell-thru_YW",
  "EOH_YW",
  "EOH_R"
FROM (
  SELECT
    input_0."COMPANYCD",
    input_0."COMPANY",
    input_0."MARKETNAME",
    input_0."PRODUCTTYPE",
    input_0."DCID",
    input_0."DC",
    input_0."VRESELLER",
    input_0."YYYYWW",
    input_0."START_DT",
    input_0."WR",
    input_0."WWWMM",
    input_0."Sell-in_YW",
    input_0."Sell-out_YW",
    input_0."Sell-thru_YW",
    input_0."EOH_YW",
    input_0."EOH_R",
    input_1."SEGMENT",
    input_1."SEGMENT_AGE"
  FROM (
    SELECT
      input_0."COMPANYCD",
      input_0."MARKETNAME",
      input_0."PRODUCTTYPE",
      input_0."DCID",
      input_0."VRESELLER",
      input_0."YYYYWW",
      input_0."WR",
      input_0."WWWMM",
      input_0."Sell-in_YW",
      input_0."Sell-out_YW",
      input_0."Sell-thru_YW",
      input_0."EOH_YW",
      input_0."EOH_R",
      input_0."DC",
      input_0."COMPANY",
      input_1."START_DT"
    FROM (
      SELECT
        input_0."COMPANYCD",
        input_0."MARKETNAME",
        input_0."PRODUCTTYPE",
        input_0."DCID",
        input_0."VRESELLER",
        input_0."YYYYWW",
        input_0."WR",
        input_0."WWWMM",
        input_0."Sell-in_YW",
        input_0."Sell-out_YW",
        input_0."Sell-thru_YW",
        input_0."EOH_YW",
        input_0."EOH_R",
        input_1."DC",
        input_1."COMPANY"
      FROM (
        SELECT
          "COMPANYCD",
          "MARKETNAME",
          "PRODUCTTYPE",
          "DCID",
          "VRESELLER",
          "YYYYWW",
          "WR",
          "WWWMM",
          "Sell-in_YW" AS "SELL-IN_YW",
          "Sell-out_YW" AS "SELL-OUT_YW",
          "Sell-thru_YW" AS "SELL-THRU_YW",
          "EOH_YW",
          "EOH_R"
        FROM (
          SELECT
            "COMPANYCD",
            "MARKETNAME",
            "PRODUCTTYPE",
            "DCID",
            "VRESELLER",
            "YYYYWW",
            "WR",
            "WWWMM",
            "Sell-in_YW",
            "Sell-out_YW",
            "Sell-thru_YW",
            "EOH_YW",
            "EOH(R)_YW" AS "EOH_R"
          FROM "OW_SELA".TMP_DLAKE_W3
        ) AS Projection_1
        UNION ALL
        SELECT
          "COMPANYCD",
          "MARKETNAME",
          "PRODUCTTYPE",
          "DCID",
          "VRESELLER",
          "YYYYWW",
          "WR",
          "WWWMM",
          "Sell-in_YW" AS "SELL-IN_YW",
          "Sell-out_YW" AS "SELL-OUT_YW",
          "Sell-thru_YW" AS "SELL-THRU_YW",
          "EOH_YW",
          "EOH_R"
        FROM (
          SELECT
            "COMPANYCD",
            "MARKETNAME",
            "PRODUCTTYPE",
            "DCID",
            "VRESELLER",
            "YYYYWW",
            "WR",
            "WWWMM",
            "Sell-in_YW",
            "Sell-out_YW",
            "Sell-thru_YW",
            "EOH_YW",
            "EOH(R)_YW" AS "EOH_R"
          FROM "OW_SELA".TMP_DLAKE_W8
        ) AS Projection_2
        UNION ALL
        SELECT
          "COMPANYCD",
          "MARKETNAME",
          "PRODUCTTYPE",
          "DCID",
          "VRESELLER",
          "DT_YW" AS "YYYYWW",
          "WR",
          "WWWMM",
          "Sell-in_YW" AS "SELL-IN_YW",
          "Sell-out_YW" AS "SELL-OUT_YW",
          "Sell-thru_YW" AS "SELL-THRU_YW",
          "EOH_YW",
          "EOH_R"
        FROM (
          SELECT
            "COMPANYCD",
            "MARKETNAME",
            "PRODUCTTYPE",
            "DCID",
            "VRESELLER",
            "DT_YW",
            "WR",
            "WWWMM",
            "Sell-in_YW",
            "Sell-out_YW",
            "Sell-thru_YW",
            "EOH_YW",
            "EOH_R"
          FROM (
            SELECT
              "COMPANYCD",
              "MARKETNAME",
              "PRODUCTTYPE",
              "DCID",
              "VRESELLER",
              "DT_YW",
              "WR",
              "WWWMM",
              "Sell-in_YW",
              "Sell-out_YW",
              "Sell-thru_YW",
              "EOH_YW",
              "EOH(R)_YW" AS "EOH_R"
            FROM "OW_SELA".TMP_DLAKE_HIST
          ) AS Projection_4
          GROUP BY
            "COMPANYCD",
            "MARKETNAME",
            "PRODUCTTYPE",
            "DCID",
            "VRESELLER",
            "DT_YW",
            "WR",
            "WWWMM",
            "Sell-in_YW",
            "Sell-out_YW",
            "Sell-thru_YW",
            "EOH_YW",
            "EOH_R"
        ) AS Aggregation_1
      ) AS input_0
      LEFT OUTER JOIN "OW_SELA".DIM_DC AS input_1
        ON input_0."DCID" = input_1."DCID" AND input_0."COMPANYCD" = input_1."COMPANYCD"
    ) AS input_0
    INNER JOIN "OW_SELA".DIM_WEEK AS input_1
      ON input_0."YYYYWW" = input_1."YYYYWW"
  ) AS input_0
  LEFT OUTER JOIN "OW_SELA".DIM_MN_SEGMENT AS input_1
    ON input_0."MARKETNAME" = input_1."MARKETNAME"
) AS Join_3
GROUP BY
  "COMPANYCD",
  "COMPANY",
  "MARKETNAME",
  "PRODUCTTYPE",
  "SEGMENT",
  "SEGMENT_AGE",
  "DCID",
  "DC",
  "VRESELLER",
  "YYYYWW",
  "START_DT",
  "WR",
  "WWWMM",
  "Sell-in_YW",
  "Sell-out_YW",
  "Sell-thru_YW",
  "EOH_YW",
  "EOH_R"