CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_CV_ECOM_CATALOG_SSG_VTEX_SYNAPCOM" AS
SELECT
  "PRODUCT_NAME" AS "Product_Name",
  "SKU_NAME" AS "Sku_Name",
  "REFERENCE_CODE" AS "Reference_Code",
  "EAN",
  "ACTIVE" AS "Active",
  "COST_PRICE" AS "Cost_Price",
  "BASE_PRICE" AS "Base_Price",
  "PHYSICAL_STOCK" AS "Physical_Stock",
  "HAS_UNLIMITED_STOCK" AS "Has_Unlimited_Stock",
  "IS_KIT" AS "Is_Kit",
  "SKU_ORIGIN" AS "Sku_Origin",
  "SUBSIDIARY_ID" AS "Subsidiary_Id",
  "SKU",
  "DIVISION" AS "Division",
  "FAMILY_GROUP" AS "Family_Group",
  "PRODUCT_GROUP" AS "Product_Group",
  "CATEGORY" AS "Category",
  "MARKET_NAME" AS "Market_Name",
  "SUBSIDIARY" AS "Subsidiary",
  "FLAGSHIP" AS "Flagship"
FROM (
  SELECT
    input_0."SUBSIDIARY",
    input_0."SUBSIDIARY_ID",
    input_0."IS_KIT",
    input_0."SKU_ORIGIN",
    input_0."HAS_UNLIMITED_STOCK",
    input_0."PHYSICAL_STOCK",
    input_0."BASE_PRICE",
    input_0."COST_PRICE",
    input_0."ACTIVE",
    input_0."EAN",
    input_0."REFERENCE_CODE",
    input_0."SKU_NAME",
    input_0."PRODUCT_NAME",
    input_1."DIVISION",
    input_1."SKU",
    input_1."PRODUCT_GROUP",
    input_1."CATEGORY",
    input_1."MARKET_NAME",
    input_1."FLAGSHIP",
    input_1."FAMILY_GROUP"
  FROM (
    SELECT
      input_0."SUBSIDIARY_ID",
      input_0."IS_KIT",
      input_0."SKU_ORIGIN",
      input_0."HAS_UNLIMITED_STOCK",
      input_0."PHYSICAL_STOCK",
      input_0."BASE_PRICE",
      input_0."COST_PRICE",
      input_0."ACTIVE",
      input_0."EAN",
      input_0."REFERENCE_CODE",
      input_0."SKU_NAME",
      input_0."PRODUCT_NAME",
      input_1."SUBSIDIARY"
    FROM (
      SELECT
        "PRODUCT_NAME",
        "SKU_NAME",
        "REFERENCE_CODE",
        "EAN",
        "ACTIVE",
        "COST_PRICE",
        "BASE_PRICE",
        "PHYSICAL_STOCK",
        "HAS_UNLIMITED_STOCK",
        "IS_KIT",
        "SKU_ORIGIN",
        "SUBSIDIARY_ID"
      FROM "OW_SEDA_S".DIM_ECOM_SKU
    ) AS input_0
    INNER JOIN (
      SELECT
        "ID",
        "SUBSIDIARY"
      FROM "U_PRJ_ECOM".DIM_SUBSIDIARY
    ) AS input_1
      ON input_0."SUBSIDIARY_ID" = input_1."ID"
  ) AS input_0
  LEFT OUTER JOIN (
    SELECT
      "DIVISION",
      "SKU",
      "PRODUCT_GROUP",
      "CATEGORY",
      "MARKET_NAME",
      "FLAGSHIP",
      "FAMILY_GROUP"
    FROM "U_PRJ_ECOM".DIM_PRODUCT_CATEGORY
  ) AS input_1
    ON input_0."REFERENCE_CODE" = input_1."SKU"
) AS Join_2