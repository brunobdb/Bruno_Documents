CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_CV_ECOM_SEDA_RAW_DATA" AS
SELECT
  "ID",
  "Creation_Date",
  "SUBSIDIARY_ID" AS "Subsidiary_Id",
  "ORDER_ID" AS "Order_Id",
  "MARKETPLACE_ORDER_ID" AS "Marketplace_Order_Id",
  "MARKETPLACE_NAME" AS "Marketplace_Name",
  "STATUS" AS "Status",
  "SUPPLIER_ID" AS "Reference_Code",
  "NAME" AS "Product_Name",
  "DIVISION" AS "Division",
  "PRODUCT_GROUP" AS "Product_Group",
  "CATEGORY" AS "Category",
  "FLAGSHIP" AS "Flagship",
  "QTY" AS "Units",
  "UNIT_PRICE" AS "Price_BRL",
  "Dummy"
FROM (
  SELECT
    input_0."ORDER_ID",
    input_0."SUBSIDIARY_ID",
    input_0."STATUS",
    input_0."MARKETPLACE_ORDER_ID",
    input_0."MARKETPLACE_NAME",
    input_0."QTY",
    input_0."UNIT_PRICE",
    input_0."SUPPLIER_ID",
    input_0."NAME",
    input_0."Creation_Date",
    input_0."Dummy",
    input_0."ID",
    input_1."DIVISION",
    input_1."PRODUCT_GROUP",
    input_1."CATEGORY",
    input_1."FLAGSHIP"
  FROM (
    SELECT
      input_0."ORDER_ID",
      input_0."SUBSIDIARY_ID",
      input_0."STATUS",
      input_0."MARKETPLACE_ORDER_ID",
      input_0."MARKETPLACE_NAME",
      input_0."Creation_Date",
      input_0."Dummy",
      input_1."QTY",
      input_1."UNIT_PRICE",
      input_1."SUPPLIER_ID",
      input_1."NAME",
      input_1."ID"
    FROM (
      SELECT
        "ORDER_ID",
        "SUBSIDIARY_ID",
        "STATUS",
        "MARKETPLACE_ORDER_ID",
        "MARKETPLACE_NAME",
        "API_ID",
        "CREATED_AT",
        TO_DATE(("CREATED_AT")::VARCHAR, 'YYYY-MM-DD') AS "Creation_Date",
        1 AS "Dummy"
      FROM "U_PRJ_ECOM".TMP_MGLU_ORDER
    ) AS input_0
    INNER JOIN (
      SELECT
        "QTY",
        "UNIT_PRICE",
        "ORDER_API_ID",
        "SUPPLIER_ID",
        "NAME",
        "ID"
      FROM "U_PRJ_ECOM".TMP_MGLU_ORDER_ITEM
    ) AS input_1
      ON input_0."API_ID" = input_1."ORDER_API_ID"
  ) AS input_0
  INNER JOIN (
    SELECT
      "SKU",
      "DIVISION",
      "PRODUCT_GROUP",
      "CATEGORY",
      "FLAGSHIP"
    FROM "U_PRJ_ECOM".DIM_PRODUCT_CATEGORY
  ) AS input_1
    ON input_0."SUPPLIER_ID" = input_1."SKU"
) AS Join_2