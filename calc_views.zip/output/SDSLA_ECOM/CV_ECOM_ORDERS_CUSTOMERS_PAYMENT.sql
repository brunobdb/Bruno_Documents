CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_CV_ECOM_ORDERS_CUSTOMERS_PAYMENT" AS
SELECT
  "ID",
  "EXTERNAL_ORDER_ID" AS "Order_Id",
  "SUBSIDIARY_ID" AS "Subsidiary_Id",
  "CREATION_DATETIME" AS "Creation_Datetime",
  "CREATION_DATE" AS "Creation_Date",
  "STATUS" AS "Status",
  "INTERNAL_STATUS" AS "Internal_Status",
  "ORDER_VALUE" AS "Order_Value",
  "DISCOUNT" AS "Discount",
  "STATUS_PAYMENT_PENDING_DATE" AS "Status_Payment_Pending_Date",
  "STATUS_PAYMENT_APPROVED_DATE" AS "Status_Payment_Approved_Date",
  "STATUS_PAYMENT_DENIED_DATE" AS "Status_Payment_Denied_Date",
  "STATUS_START_HANDLING_DATE" AS "Status_Start_Handling_Date",
  "STATUS_HANDLING_SHIPPING_DATE" AS "Status_Handling_Shipping_Date",
  "STATUS_INVOICED_DATE" AS "Status_Invoiced_Date",
  "STATUS_DELIVERED_DATE" AS "Status_Delivered_Date",
  "STATUS_CANCELED_DATE" AS "Status_Canceled_Date",
  "CANCELLATION_REASON" AS "Cancellation_Reason",
  "COMPLETE" AS "Complete",
  "ACQUIRER_MESSAGE" AS "Acquirer_Message",
  "SHIPPING_COST" AS "Shipping_Cost",
  "VENDOR" AS "Vendor",
  "INVOICE_NUMBER" AS "Invoice_Number",
  "HOSTNAME" AS "Hostname",
  "MKT_UTM_SRC" AS "Mkt_Utm_Src",
  "MKT_UTM_PARTNER" AS "Mkt_Utm_Partner",
  "MKT_UTM_MEDIUM" AS "Mkt_Utm_Medium",
  "MKT_UTM_CAMPAIGN" AS "Mkt_Utm_Campaign",
  "MKT_UTM_COUPON" AS "Mkt_Utm_Coupon",
  "SELLER_NAME" AS "Seller_Name",
  "SELLER_ID" AS "Seller_Id",
  "REFERENCE_CURRENCY" AS "Reference_Currency",
  "REFERENCE_DATE" AS "Reference_Date",
  "TAX_CONVERTER" AS "Tax_Converter",
  "PAYMENT_TYPE" AS "Payment_Type",
  "VALUE" AS "Payment_Value_Local",
  "PAYMENT_DATE" AS "Payment_Date",
  "INSTALLMENT" AS "Installment",
  "BRAND" AS "Brand",
  "ACQUIRER" AS "Acquirer",
  "PAYMENT_ID" AS "Payment_Id",
  "TRANSACTION_ID" AS "Transaction_Id",
  "PAYMENT_AUTH_ID" AS "Payment_Auth_Id",
  "FIRST_DIGITS" AS "First_Digits",
  "SELLER" AS "Seller",
  "TRANSACTION_RETURN_CODE" AS "Transaction_Return_Code",
  "SUBSIDIARY" AS "Subsidiary",
  "BIRTHDAY" AS "Birthday",
  "GENDER" AS "Gender",
  "NAME" AS "Name",
  "OPT_IN" AS "Opt_In",
  "CUSTOMER_CREATION_DATE" AS "Customer_Creation_Date",
  "CHANNEL" AS "Channel",
  "Payment_Value_Local" * "Tax_Converter" AS "Payment_Value_USD"
FROM (
  SELECT
    input_0."PAYMENT_TYPE",
    input_0."VALUE",
    input_0."BRAND",
    input_0."INSTALLMENT",
    input_0."ACQUIRER",
    input_0."PAYMENT_ID",
    input_0."TRANSACTION_ID",
    input_0."PAYMENT_AUTH_ID",
    input_0."FIRST_DIGITS",
    input_0."SELLER",
    input_0."TRANSACTION_RETURN_CODE",
    input_0."PAYMENT_DATE",
    input_0."CUSTOMER_CREATION_DATE",
    input_0."NAME",
    input_0."GENDER",
    input_0."BIRTHDAY",
    input_0."OPT_IN",
    input_0."SUBSIDIARY",
    input_0."EXTERNAL_ORDER_ID",
    input_0."CREATION_DATETIME",
    input_0."STATUS",
    input_0."INTERNAL_STATUS",
    input_0."ORDER_VALUE",
    input_0."DISCOUNT",
    input_0."STATUS_PAYMENT_PENDING_DATE",
    input_0."STATUS_PAYMENT_APPROVED_DATE",
    input_0."STATUS_PAYMENT_DENIED_DATE",
    input_0."STATUS_INVOICED_DATE",
    input_0."STATUS_START_HANDLING_DATE",
    input_0."STATUS_HANDLING_SHIPPING_DATE",
    input_0."STATUS_DELIVERED_DATE",
    input_0."STATUS_CANCELED_DATE",
    input_0."CANCELLATION_REASON",
    input_0."COMPLETE",
    input_0."ACQUIRER_MESSAGE",
    input_0."SHIPPING_COST",
    input_0."VENDOR",
    input_0."INVOICE_NUMBER",
    input_0."HOSTNAME",
    input_0."MKT_UTM_SRC",
    input_0."MKT_UTM_PARTNER",
    input_0."MKT_UTM_MEDIUM",
    input_0."MKT_UTM_CAMPAIGN",
    input_0."MKT_UTM_COUPON",
    input_0."SELLER_NAME",
    input_0."SELLER_ID",
    input_0."CREATION_DATE",
    input_0."SUBSIDIARY_ID",
    input_0."ID",
    input_0."AFFILIATE_ID",
    input_0."CHANNEL",
    input_1."REFERENCE_DATE",
    input_1."REFERENCE_CURRENCY",
    input_1."VALUE" AS "TAX_CONVERTER"
  FROM (
    SELECT
      input_0."CUSTOMER_CREATION_DATE",
      input_0."NAME",
      input_0."GENDER",
      input_0."BIRTHDAY",
      input_0."OPT_IN",
      input_0."SUBSIDIARY",
      input_0."EXTERNAL_ORDER_ID",
      input_0."CREATION_DATETIME",
      input_0."STATUS",
      input_0."INTERNAL_STATUS",
      input_0."ORDER_VALUE",
      input_0."DISCOUNT",
      input_0."STATUS_PAYMENT_PENDING_DATE",
      input_0."STATUS_PAYMENT_APPROVED_DATE",
      input_0."STATUS_PAYMENT_DENIED_DATE",
      input_0."STATUS_INVOICED_DATE",
      input_0."STATUS_START_HANDLING_DATE",
      input_0."STATUS_HANDLING_SHIPPING_DATE",
      input_0."STATUS_DELIVERED_DATE",
      input_0."STATUS_CANCELED_DATE",
      input_0."CANCELLATION_REASON",
      input_0."COMPLETE",
      input_0."ACQUIRER_MESSAGE",
      input_0."SHIPPING_COST",
      input_0."VENDOR",
      input_0."INVOICE_NUMBER",
      input_0."HOSTNAME",
      input_0."MKT_UTM_SRC",
      input_0."MKT_UTM_PARTNER",
      input_0."MKT_UTM_MEDIUM",
      input_0."MKT_UTM_CAMPAIGN",
      input_0."MKT_UTM_COUPON",
      input_0."SELLER_NAME",
      input_0."SELLER_ID",
      input_0."CREATION_DATE",
      input_0."SUBSIDIARY_ID",
      input_0."ID",
      input_0."AFFILIATE_ID",
      input_0."CHANNEL",
      input_1."PAYMENT_TYPE",
      input_1."VALUE",
      input_1."BRAND",
      input_1."INSTALLMENT",
      input_1."ACQUIRER",
      input_1."PAYMENT_ID",
      input_1."TRANSACTION_ID",
      input_1."PAYMENT_AUTH_ID",
      input_1."FIRST_DIGITS",
      input_1."SELLER",
      input_1."TRANSACTION_RETURN_CODE",
      input_1."PAYMENT_DATE"
    FROM (
      SELECT
        input_0."SUBSIDIARY",
        input_0."ID",
        input_0."EXTERNAL_ORDER_ID",
        input_0."CREATION_DATETIME",
        input_0."STATUS",
        input_0."INTERNAL_STATUS",
        input_0."ORDER_VALUE",
        input_0."DISCOUNT",
        input_0."STATUS_PAYMENT_PENDING_DATE",
        input_0."STATUS_PAYMENT_APPROVED_DATE",
        input_0."STATUS_PAYMENT_DENIED_DATE",
        input_0."STATUS_INVOICED_DATE",
        input_0."STATUS_START_HANDLING_DATE",
        input_0."STATUS_HANDLING_SHIPPING_DATE",
        input_0."STATUS_DELIVERED_DATE",
        input_0."STATUS_CANCELED_DATE",
        input_0."CANCELLATION_REASON",
        input_0."COMPLETE",
        input_0."ACQUIRER_MESSAGE",
        input_0."SHIPPING_COST",
        input_0."VENDOR",
        input_0."INVOICE_NUMBER",
        input_0."HOSTNAME",
        input_0."MKT_UTM_SRC",
        input_0."MKT_UTM_PARTNER",
        input_0."MKT_UTM_MEDIUM",
        input_0."MKT_UTM_CAMPAIGN",
        input_0."MKT_UTM_COUPON",
        input_0."SELLER_NAME",
        input_0."SELLER_ID",
        input_0."CREATION_DATE",
        input_0."SUBSIDIARY_ID",
        input_0."AFFILIATE_ID",
        input_0."CHANNEL",
        input_1."CUSTOMER_CREATION_DATE",
        input_1."NAME",
        input_1."GENDER",
        input_1."BIRTHDAY",
        input_1."OPT_IN"
      FROM (
        SELECT
          input_0."ID",
          input_0."EXTERNAL_ORDER_ID",
          input_0."CREATION_DATETIME",
          input_0."STATUS",
          input_0."INTERNAL_STATUS",
          input_0."ORDER_VALUE",
          input_0."CUSTOMER_ID",
          input_0."DISCOUNT",
          input_0."STATUS_PAYMENT_PENDING_DATE",
          input_0."STATUS_PAYMENT_APPROVED_DATE",
          input_0."STATUS_PAYMENT_DENIED_DATE",
          input_0."STATUS_INVOICED_DATE",
          input_0."STATUS_START_HANDLING_DATE",
          input_0."STATUS_HANDLING_SHIPPING_DATE",
          input_0."STATUS_DELIVERED_DATE",
          input_0."STATUS_CANCELED_DATE",
          input_0."CANCELLATION_REASON",
          input_0."COMPLETE",
          input_0."ACQUIRER_MESSAGE",
          input_0."SHIPPING_COST",
          input_0."VENDOR",
          input_0."INVOICE_NUMBER",
          input_0."HOSTNAME",
          input_0."MKT_UTM_SRC",
          input_0."MKT_UTM_PARTNER",
          input_0."MKT_UTM_MEDIUM",
          input_0."MKT_UTM_CAMPAIGN",
          input_0."MKT_UTM_COUPON",
          input_0."SELLER_NAME",
          input_0."SELLER_ID",
          input_0."CREATION_DATE",
          input_0."SUBSIDIARY_ID",
          input_0."AFFILIATE_ID",
          input_0."CHANNEL",
          input_1."SUBSIDIARY"
        FROM (
          SELECT
            "ID",
            "EXTERNAL_ORDER_ID",
            "SUBSIDIARY_ID",
            "CREATION_DATE" AS "CREATION_DATETIME",
            "STATUS",
            "INTERNAL_STATUS",
            "ORDER_VALUE",
            "CUSTOMER_ID",
            "DISCOUNT",
            "STATUS_PAYMENT_PENDING_DATE",
            "STATUS_PAYMENT_APPROVED_DATE",
            "STATUS_PAYMENT_DENIED_DATE",
            "STATUS_INVOICED_DATE",
            "STATUS_START_HANDLING_DATE",
            "STATUS_HANDLING_SHIPPING_DATE",
            "STATUS_DELIVERED_DATE",
            "STATUS_CANCELED_DATE",
            "CANCELLATION_REASON",
            "COMPLETE",
            "ACQUIRER_MESSAGE",
            "SHIPPING_COST",
            "VENDOR",
            "INVOICE_NUMBER",
            "HOSTNAME",
            "MKT_UTM_SRC",
            "MKT_UTM_PARTNER",
            "MKT_UTM_MEDIUM",
            "MKT_UTM_CAMPAIGN",
            "MKT_UTM_COUPON",
            "SELLER_NAME",
            "SELLER_ID",
            "AFFILIATE_ID",
            "TRADE_POLICY",
            TO_DATE(("CREATION_DATETIME")::VARCHAR, 'YYYY-MM-DD') AS "CREATION_DATE",
            CASE
              WHEN "SUBSIDIARY_ID" = 3 AND "AFFILIATE_ID" = 'MLC'
              THEN 'MERCADO LIBRE'
              WHEN "SUBSIDIARY_ID" = 3
              THEN "TRADE_POLICY"
              WHEN "AFFILIATE_ID" IN ('MRC', 'MCL')
              THEN 'MERCADO LIVRE'
              WHEN "AFFILIATE_ID" IN ('SSG', 'SAMSUNG', 'SSP')
              THEN 'SAMSUNG'
              WHEN "AFFILIATE_ID" = 'BWW'
              THEN 'B2W'
              WHEN "AFFILIATE_ID" = 'VVJ'
              THEN 'VIA VAREJO'
              WHEN "AFFILIATE_ID" = 'VVT'
              THEN 'VIVO'
              WHEN "AFFILIATE_ID" = 'SNG'
              THEN 'EPP B2B2C'
              WHEN "AFFILIATE_ID" = 'SMG'
              THEN 'EPP FUNCIONÁRIOS'
              WHEN "AFFILIATE_ID" = 'CDR'
              THEN 'CREDITAS'
              WHEN "AFFILIATE_ID" = 'BNT'
              THEN 'INTER'
              WHEN "AFFILIATE_ID" = 'NVM'
              THEN 'NOVO MUNDO'
              WHEN "AFFILIATE_ID" = 'ZMM'
              THEN 'ZOOM'
              WHEN "AFFILIATE_ID" = 'PSG'
              THEN 'PORTO'
              WHEN "AFFILIATE_ID" IN ('SPV', 'SVC')
              THEN 'SSG P/VC'
              WHEN "AFFILIATE_ID" = 'CRF'
              THEN 'CARREFOUR'
              WHEN "AFFILIATE_ID" = 'PLC'
              THEN 'OI'
              WHEN "AFFILIATE_ID" = 'DDV'
              THEN 'INDEVA'
              WHEN "AFFILIATE_ID" = 'MGZ'
              THEN 'MAGALU'
              WHEN "AFFILIATE_ID" = 'RDT'
              THEN 'RICARDO'
              WHEN "AFFILIATE_ID" = 'HTG'
              THEN 'HOMETOGO'
              WHEN "AFFILIATE_ID" = 'BCR'
              THEN 'BALCAO RURAL'
              WHEN "AFFILIATE_ID" = 'LTM'
              THEN 'IUPP/ITAU'
              WHEN "AFFILIATE_ID" = 'KBM'
              THEN 'KABUM'
              WHEN "AFFILIATE_ID" = 'CLR'
              THEN 'CLARO'
              WHEN "AFFILIATE_ID" = 'NTS'
              THEN 'NETSHOES'
              WHEN "AFFILIATE_ID" = 'SMS'
              THEN 'C.CERTA'
              WHEN "AFFILIATE_ID" = 'LRM'
              THEN 'L.MERLIN'
              WHEN "AFFILIATE_ID" = 'SSC'
              THEN 'SSG ITAUCARD'
              ELSE "AFFILIATE_ID"
            END AS "CHANNEL"
          FROM "U_PRJ_ECOM".FT_ECOM_ORDER
        ) AS input_0
        INNER JOIN (
          SELECT
            "ID",
            "SUBSIDIARY"
          FROM "U_PRJ_ECOM".DIM_SUBSIDIARY
        ) AS input_1
          ON input_0."SUBSIDIARY_ID" = input_1."ID"
      ) AS input_0
      INNER JOIN (
        SELECT
          "OPT_IN",
          "BIRTHDAY",
          "ID",
          "GENDER",
          "NAME",
          "CREATION_DATE" AS "CUSTOMER_CREATION_DATE",
          "SUBSIDIARY_ID"
        FROM "U_PRJ_ECOM".DIM_CUSTOMER
      ) AS input_1
        ON input_0."SUBSIDIARY_ID" = input_1."SUBSIDIARY_ID"
        AND input_0."CUSTOMER_ID" = input_1."ID"
    ) AS input_0
    LEFT OUTER JOIN (
      SELECT
        "ORDER_ID",
        "PAYMENT_TYPE",
        "VALUE",
        "BRAND",
        "INSTALLMENT",
        "ACQUIRER",
        "PAYMENT_ID",
        "TRANSACTION_ID",
        "PAYMENT_AUTH_ID",
        "FIRST_DIGITS",
        "SELLER",
        "TRANSACTION_RETURN_CODE",
        "PAYMENT_DATE"
      FROM "U_PRJ_ECOM".FT_ECOM_ORDER_PAYMENT
    ) AS input_1
      ON input_0."ID" = input_1."ORDER_ID"
  ) AS input_0
  INNER JOIN (
    SELECT
      "SUBSIDIARY_ID",
      "REFERENCE_DATE",
      "REFERENCE_CURRENCY",
      "VALUE"
    FROM "U_PRJ_ECOM".DIM_EXCHANGE_RATE
  ) AS input_1
    ON input_0."SUBSIDIARY_ID" = input_1."SUBSIDIARY_ID"
    AND input_0."CREATION_DATE" = input_1."REFERENCE_DATE"
) AS Join_4