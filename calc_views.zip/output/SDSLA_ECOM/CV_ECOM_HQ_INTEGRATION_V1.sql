CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_CV_ECOM_HQ_INTEGRATION_V1" AS
SELECT
  "COUNTRY_CD",
  "SITE",
  "SALES_APPLICATION",
  "PRODUCT_CODE",
  "ORDER_CODE",
  "ORDER_STATUS",
  "ORDER_TYPE",
  "ORDER_CREATION_DATE",
  "PLATFORM",
  "VOUCHER_CODE",
  "ITEM_TAX_AMOUNT",
  "IS_TRADED_IN",
  "IS_TRADE_IN_ELIGIBLE",
  "IS_FINANCED_ORDER",
  "IS_FINANCING_ELIGIBLE",
  "IS_UPGRADE",
  "IS_UPGRADE_ELIGIBLE",
  "IS_SAMSUNG_CARE_ORDER",
  "IS_SAMSUNG_CARE_ELIGIBLE",
  "PAYMENT_METHOD_NAME",
  "PAYMENT_GATEWAY",
  "LAST_UPDATE",
  "REMARKS",
  "ORDER_ENTRY_TOTAL_PRICE",
  "ORDER_ENTRY_QUANTITY",
  "UNIT_LIST_PRICE",
  "UNIT_SALES_PRICE",
  "SALES_PRICE",
  "DISCOUNT_AMOUNT",
  "COD_SALES_CHANNEL",
  "HOSTNAME",
  CASE
    WHEN "DISCOUNT_AMOUNT" > "SALES_PRICE"
    THEN "SALES_PRICE"
    ELSE "DISCOUNT_AMOUNT"
  END AS "DISCOUNT_AMOUNT_CALC",
  CASE
    WHEN "DISCOUNT_AMOUNT" > "SALES_PRICE"
    THEN 0
    ELSE "ORDER_ENTRY_TOTAL_PRICE"
  END AS "ORDER_ENTRY_TOTAL_PRICE_CALC"
FROM (
  SELECT
    input_0."COUNTRY_CD",
    input_0."SITE",
    input_0."SALES_APPLICATION",
    input_0."PRODUCT_CODE",
    input_0."ORDER_CODE",
    input_0."ORDER_STATUS",
    input_0."ORDER_TYPE" AS "ORDER_TYPE_1",
    input_0."ORDER_CREATION_DATE",
    input_0."PLATFORM",
    input_0."VOUCHER_CODE",
    input_0."ITEM_TAX_AMOUNT",
    input_0."IS_TRADED_IN",
    input_0."IS_TRADE_IN_ELIGIBLE",
    input_0."IS_FINANCED_ORDER",
    input_0."IS_FINANCING_ELIGIBLE",
    input_0."IS_UPGRADE",
    input_0."IS_UPGRADE_ELIGIBLE",
    input_0."IS_SAMSUNG_CARE_ORDER",
    input_0."IS_SAMSUNG_CARE_ELIGIBLE",
    input_0."PAYMENT_METHOD_NAME",
    input_0."PAYMENT_GATEWAY",
    input_0."LAST_UPDATE",
    input_0."REMARKS",
    input_0."ORDER_ENTRY_TOTAL_PRICE",
    input_0."ORDER_ENTRY_QUANTITY",
    input_0."UNIT_LIST_PRICE",
    input_0."UNIT_SALES_PRICE",
    input_0."SALES_PRICE",
    input_0."DISCOUNT_AMOUNT",
    input_0."COD_SALES_CHANNEL",
    input_0."HOSTNAME",
    input_1."ORDER_TYPE"
  FROM (
    SELECT
      input_0."COUNTRY_CD",
      input_0."SITE",
      input_0."SALES_APPLICATION",
      input_0."PRODUCT_CODE",
      input_0."ORDER_CODE",
      input_0."ORDER_STATUS",
      input_0."ORDER_CREATION_DATE",
      input_0."PLATFORM",
      input_0."VOUCHER_CODE",
      input_0."ITEM_TAX_AMOUNT",
      input_0."IS_TRADED_IN",
      input_0."IS_TRADE_IN_ELIGIBLE",
      input_0."IS_FINANCED_ORDER",
      input_0."IS_FINANCING_ELIGIBLE",
      input_0."IS_UPGRADE",
      input_0."IS_UPGRADE_ELIGIBLE",
      input_0."IS_SAMSUNG_CARE_ORDER",
      input_0."IS_SAMSUNG_CARE_ELIGIBLE",
      input_0."PAYMENT_METHOD_NAME",
      input_0."PAYMENT_GATEWAY",
      input_0."LAST_UPDATE",
      input_0."REMARKS",
      input_0."ORDER_ENTRY_TOTAL_PRICE",
      input_0."ORDER_ENTRY_QUANTITY",
      input_0."UNIT_LIST_PRICE",
      input_0."UNIT_SALES_PRICE",
      input_0."SALES_PRICE",
      input_0."DISCOUNT_AMOUNT",
      input_0."ORDER_TYPE",
      input_1."COD_SALES_CHANNEL",
      input_1."HOSTNAME"
    FROM (
      SELECT
        "COUNTRY_CD",
        "SITE",
        "SALES_APPLICATION",
        "PRODUCT_CODE",
        "ORDER_CODE",
        "ORDER_STATUS",
        "ORDER_TYPE",
        "ORDER_CREATION_DATE",
        "PLATFORM",
        "VOUCHER_CODE",
        "ITEM_TAX_AMOUNT",
        "IS_TRADED_IN",
        "IS_TRADE_IN_ELIGIBLE",
        "IS_FINANCED_ORDER",
        "IS_FINANCING_ELIGIBLE",
        "IS_UPGRADE",
        "IS_UPGRADE_ELIGIBLE",
        "IS_SAMSUNG_CARE_ORDER",
        "IS_SAMSUNG_CARE_ELIGIBLE",
        "PAYMENT_METHOD_NAME",
        "PAYMENT_GATEWAY",
        "LAST_UPDATE",
        "REMARKS",
        "ORDER_ENTRY_TOTAL_PRICE",
        "ORDER_ENTRY_QUANTITY",
        "UNIT_LIST_PRICE",
        "UNIT_SALES_PRICE",
        "SALES_PRICE",
        "DISCOUNT_AMOUNT"
      FROM "U_PRJ_ECOM".VIEW_ECOM_HQ_ORDERS_PRODUCTS_PAYMENT_DEV
    ) AS input_0
    LEFT OUTER JOIN "U_PRJ_ECOM".FT_ECOM_ORDER AS input_1
      ON input_0."ORDER_CODE" = input_1."EXTERNAL_ORDER_ID"
      AND input_0."COUNTRY_CD" = input_1."COUNTRY"
  ) AS input_0
  LEFT OUTER JOIN "U_PRJ_ECOM".BI_ECOM_EPP_LAO AS input_1
    ON input_0."COUNTRY_CD" = input_1."COUNTRY"
    AND input_0."HOSTNAME" = input_1."HOSTNAME"
    AND input_0."COD_SALES_CHANNEL" = input_1."COD_SALES_CHANNEL"
) AS Join_2