-- Migrated from HANA Calculation View: OW_SEDA_S.VIEWCV_CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS_SYNAPCOM
-- Description: CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS_SYNAPCOM

CREATE OR REPLACE PROCEDURE OW_SEDA_S.load_VIEWCV_CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS_SYNAPCOM()
LANGUAGE PLvSQL AS $$
BEGIN

  -- Layer 0: 33 nodes

  -- Node: Join_7
  PERFORM DROP TABLE IF EXISTS "layer_0_Join_7" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Join_7" ON COMMIT PRESERVE ROWS AS 
  SELECT
    input_0."ORDER_ID",
    input_0."PRODUCT_NAME" AS "PRODUCT_NAME_ITEM",
    input_0."REFERENCE_CODE" AS "REFERENCE_CODE_ITEM",
    input_0."QUANTITY" AS "QUANTITY_ITEM",
    input_0."EAN" AS "EAN_ITEM",
    input_0."SHIPPING_ESTIMATE_DATE" AS "SHIPPING_ESTIMATE_DATE_ITEM",
    input_0."CARRIER" AS "CARRIER_ITEM",
    input_0."KIT" AS "KIT_FLAG",
    input_0."DISCOUNT" AS "DISCOUNT_ITEM",
    input_0."PRICE" AS "PRICE_ITEM",
    input_0."SHIPPING_COST" AS "SHIPPING_COST_ITEM",
    input_0."IS_SAMSUNG_CARE",
    input_0."SKU_ID",
    input_1."SHIPPING_COST" AS "SHIPPING_COST_COMPONENT",
    input_1."PRICE" AS "PRICE_COMPONENT",
    input_1."DISCOUNT" AS "DISCOUNT_COMPONENT",
    input_1."REFERENCE_CODE" AS "REFERENCE_CODE_COMPONENT",
    input_1."PRODUCT_NAME" AS "PRODUCT_NAME_COMPONENT",
    input_1."QUANTITY" AS "QUANTITY_COMPONENT",
    input_1."EAN" AS "EAN_COMPONENT",
    input_1."CARRIER" AS "CARRIER_COMPONENT",
    input_1."SHIPPING_ESTIMATE_DATE" AS "SHIPPING_ESTIMATE_DATE_COMPONENT"
  FROM (
    SELECT
      "ORDER_ID",
      "PRODUCT_NAME",
      "REFERENCE_CODE",
      "QUANTITY",
      "EAN",
      "DISCOUNT",
      "SHIPPING_ESTIMATE_DATE",
      "CARRIER",
      "PRICE",
      "SHIPPING_COST",
      "KIT",
      "ID",
      "IS_SAMSUNG_CARE",
      "SKU_ID"
    FROM "U_PRJ_ECOM".FT_ECOM_ORDER_ITEM
  ) AS input_0
  LEFT OUTER JOIN (
    SELECT
      "ORDER_ID",
      "PRODUCT_NAME",
      "REFERENCE_CODE",
      "QUANTITY",
      "EAN",
      "CARRIER",
      "SHIPPING_ESTIMATE_DATE",
      "DISCOUNT",
      "PRICE",
      "SHIPPING_COST",
      "ITEM_ID"
    FROM "U_PRJ_ECOM".FT_ECOM_ORDER_KIT_COMPONENT
  ) AS input_1
    ON input_0."ID" = input_1."ITEM_ID" AND input_0."ORDER_ID" = input_1."ORDER_ID"
  ;

  -- Node: Join_1
  PERFORM DROP TABLE IF EXISTS "layer_0_Join_1" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Join_1" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."ID",
    input_0."EXTERNAL_ORDER_ID",
    input_0."SUBSIDIARY_ID",
    input_0."CREATION_DATE",
    input_0."STATUS",
    input_0."INTERNAL_STATUS",
    input_0."CUSTOMER_ID",
    input_0."STATUS_PAYMENT_PENDING_DATE",
    input_0."STATUS_PAYMENT_APPROVED_DATE",
    input_0."STATUS_PAYMENT_DENIED_DATE",
    input_0."STATUS_START_HANDLING_DATE",
    input_0."STATUS_HANDLING_SHIPPING_DATE",
    input_0."STATUS_INVOICED_DATE",
    input_0."STATUS_DELIVERED_DATE",
    input_0."STATUS_CANCELED_DATE",
    input_0."CANCELLATION_REASON",
    input_0."COMPLETE",
    input_0."ACQUIRER_MESSAGE",
    input_0."VENDOR",
    input_0."INVOICE_NUMBER",
    input_0."HOSTNAME",
    input_0."SELLER_ID",
    input_0."SELLER_NAME",
    input_0."MKT_UTM_COUPON",
    input_0."MKT_UTM_CAMPAIGN",
    input_0."MKT_UTM_MEDIUM",
    input_0."MKT_UTM_PARTNER",
    input_0."MKT_UTM_SRC",
    input_0."COUNTRY",
    input_0."ADDRESS_STATE",
    input_0."CITY",
    input_0."SELLER_ORDER_ID",
    input_0."MKT_UTMI_CAMPAIGN",
    input_0."MKT_UTMI_PAGE",
    input_0."MKT_UTMI_PART",
    input_0."TRADE_POLICY",
    input_0."AFFILIATE_ID",
    input_0."MKT_CAMPAIGN_TAGS",
    input_0."LAST_UPDATE_DATE",
    input_0."INSERT_DATE",
    input_0."CHANNEL",
    input_0."MACRO_CHANNEL",
    input_0."COD_SALES_CHANNEL",
    input_0."MKTPLACE_ORDER_ID",
    input_0."SELLER_INSTANCE_ID",
    input_0."IS_TRADE_IN",
    input_1."SHIPPING_COST",
    input_1."REFERENCE_CODE",
    input_1."DISCOUNT",
    input_1."PRICE",
    input_1."QUANTITY",
    input_1."REFERENCE_CODE_KIT",
    input_1."KIT_COMPONENT",
    input_1."CARRIER",
    input_1."EAN",
    input_1."SHIPPING_ESTIMATE_DATE",
    input_1."PRODUCT_NAME",
    input_1."IS_SAMSUNG_CARE",
    input_1."SKU_ID"
  FROM (
    SELECT
      "ID",
      "EXTERNAL_ORDER_ID",
      "SUBSIDIARY_ID",
      "CREATION_DATE",
      "STATUS",
      "INTERNAL_STATUS",
      "CUSTOMER_ID",
      "STATUS_PAYMENT_PENDING_DATE",
      "STATUS_PAYMENT_APPROVED_DATE",
      "STATUS_PAYMENT_DENIED_DATE",
      "STATUS_START_HANDLING_DATE",
      "STATUS_HANDLING_SHIPPING_DATE",
      "STATUS_INVOICED_DATE",
      "STATUS_DELIVERED_DATE",
      "STATUS_CANCELED_DATE",
      "CANCELLATION_REASON",
      "COMPLETE",
      "ACQUIRER_MESSAGE",
      "VENDOR",
      "INVOICE_NUMBER",
      "HOSTNAME",
      "SELLER_ID",
      "SELLER_NAME",
      "MKT_UTM_COUPON",
      "MKT_UTM_CAMPAIGN",
      "MKT_UTM_MEDIUM",
      "MKT_UTM_PARTNER",
      "MKT_UTM_SRC",
      "COUNTRY",
      "ADDRESS_STATE",
      "CITY",
      "SELLER_ORDER_ID",
      "MKT_UTMI_CAMPAIGN",
      "MKT_UTMI_PAGE",
      "MKT_UTMI_PART",
      "TRADE_POLICY",
      "AFFILIATE_ID",
      "MKT_CAMPAIGN_TAGS",
      "LAST_UPDATE_DATE",
      "INSERT_DATE",
      "COD_SALES_CHANNEL",
      "MKTPLACE_ORDER_ID",
      "SELLER_INSTANCE_ID",
      "IS_TRADE_IN",
      CASE
        WHEN "SUBSIDIARY_ID" = 3 AND "AFFILIATE_ID" = 'MLC'
        THEN 'MERCADO LIVRE'
        WHEN "SUBSIDIARY_ID" = 3
        THEN "TRADE_POLICY"
        WHEN "AFFILIATE_ID" IN ('MRC', 'MCL')
        THEN 'MERCADO LIVRE'
        WHEN "AFFILIATE_ID" IN ('SSG', 'SAMSUNG', 'SSP')
        THEN 'SAMSUNG'
        WHEN "AFFILIATE_ID" = 'BWW'
        THEN 'B2W'
        WHEN "AFFILIATE_ID" = 'VVJ'
        THEN 'VIA VAREJO'
        WHEN "AFFILIATE_ID" = 'VVT'
        THEN 'VIVO'
        WHEN "AFFILIATE_ID" = 'SNG'
        THEN 'EPP B2B2C'
        WHEN "AFFILIATE_ID" = 'SMG'
        THEN 'EPP FUNCIONÁRIOS'
        WHEN "AFFILIATE_ID" = 'CDR'
        THEN 'CREDITAS'
        WHEN "AFFILIATE_ID" = 'BNT'
        THEN 'INTER'
        WHEN "AFFILIATE_ID" = 'NVM'
        THEN 'NOVO MUNDO'
        WHEN "AFFILIATE_ID" = 'ZMM'
        THEN 'ZOOM'
        WHEN "AFFILIATE_ID" = 'PSG'
        THEN 'PORTO'
        WHEN "AFFILIATE_ID" IN ('SPV', 'SVC')
        THEN 'SSG P/VC'
        WHEN "AFFILIATE_ID" = 'CRF'
        THEN 'CARREFOUR'
        WHEN "AFFILIATE_ID" = 'PLC'
        THEN 'OI'
        WHEN "AFFILIATE_ID" = 'DDV'
        THEN 'INDEVA'
        WHEN "AFFILIATE_ID" = 'MGZ'
        THEN 'MAGALU'
        WHEN "AFFILIATE_ID" = 'RDT'
        THEN 'RICARDO'
        WHEN "AFFILIATE_ID" = 'HTG'
        THEN 'HOMETOGO'
        WHEN "AFFILIATE_ID" = 'BCR'
        THEN 'BALCAO RURAL'
        WHEN "AFFILIATE_ID" = 'LTM'
        THEN 'IUPP/ITAU'
        WHEN "AFFILIATE_ID" = 'KBM'
        THEN 'KABUM'
        WHEN "AFFILIATE_ID" = 'CLR'
        THEN 'CLARO'
        WHEN "AFFILIATE_ID" = 'NTS'
        THEN 'NETSHOES'
        WHEN "AFFILIATE_ID" = 'SMS'
        THEN 'C.CERTA'
        WHEN "AFFILIATE_ID" = 'LRM'
        THEN 'L.MERLIN'
        WHEN "AFFILIATE_ID" = 'SSC'
        THEN 'SSG ITAUCARD'
        WHEN "AFFILIATE_ID" = 'GDF'
        THEN 'G.OFERTAS'
        WHEN "AFFILIATE_ID" = 'NNT'
        THEN '99TAXI'
        WHEN "AFFILIATE_ID" = 'SHM'
        THEN 'H.AUTO'
        WHEN "AFFILIATE_ID" IN ('SFF', 'SFB')
        THEN 'SHOPFACIL'
        WHEN "AFFILIATE_ID" = 'BST'
        THEN 'BESTOFF'
        WHEN "AFFILIATE_ID" IN ('SPP')
        THEN 'EPP ESTUDANTES'
        WHEN "AFFILIATE_ID" IN ('SGP')
        THEN 'FUNCIONÁRIOS 2'
        ELSE "AFFILIATE_ID"
      END AS "CHANNEL",
      CASE
        WHEN "AFFILIATE_ID" IN ('SNG', 'PSG', 'SSC', 'BNT', 'BST', 'CDR', 'HTG', 'LTM', 'SFB', 'SFF', 'SHM')
        THEN 'B2B2C'
        WHEN "AFFILIATE_ID" IN ('SMG')
        THEN 'EPP'
        WHEN "AFFILIATE_ID" IN (
          'MRC',
          'MCL',
          'BWW',
          'VVJ',
          'VVT',
          'NVM',
          'ZMM',
          'CRF',
          'PLC',
          'DDV',
          'MGZ',
          'RDT',
          'BCR',
          'KBM',
          'CLR',
          'NTS',
          'SMS',
          'LRM',
          'GCM',
          'GDF',
          'NNT'
        )
        THEN 'Market Place-Out'
        WHEN "AFFILIATE_ID" IN ('SSG', 'SSP')
        THEN 'Shop'
        WHEN "AFFILIATE_ID" IN ('SVC', 'SPV')
        THEN 'SSG P/VC'
        ELSE "AFFILIATE_ID"
      END AS "MACRO_CHANNEL"
    FROM "U_PRJ_ECOM".FT_ECOM_ORDER
  ) AS input_0
  INNER JOIN (
    SELECT
      "ORDER_ID",
      "PRODUCT_NAME_ITEM",
      "REFERENCE_CODE_ITEM",
      "QUANTITY_ITEM",
      "EAN_ITEM",
      "SHIPPING_ESTIMATE_DATE_ITEM",
      "CARRIER_ITEM",
      "KIT_FLAG" AS "KIT_ITEM",
      "DISCOUNT_ITEM",
      "PRICE_ITEM",
      "SHIPPING_COST_ITEM",
      "SHIPPING_COST_COMPONENT",
      "PRICE_COMPONENT",
      "DISCOUNT_COMPONENT",
      "REFERENCE_CODE_COMPONENT",
      "PRODUCT_NAME_COMPONENT",
      "QUANTITY_COMPONENT",
      "EAN_COMPONENT",
      "CARRIER_COMPONENT",
      "SHIPPING_ESTIMATE_DATE_COMPONENT",
      "IS_SAMSUNG_CARE",
      "SKU_ID",
      CASE
        WHEN (
          "SHIPPING_COST_COMPONENT"
        ) IS NULL
        THEN "SHIPPING_COST_ITEM"
        ELSE "SHIPPING_COST_COMPONENT"
      END AS "SHIPPING_COST",
      CASE
        WHEN (
          "REFERENCE_CODE_COMPONENT"
        ) IS NULL
        THEN "REFERENCE_CODE_ITEM"
        ELSE "REFERENCE_CODE_COMPONENT"
      END AS "REFERENCE_CODE",
      CASE
        WHEN (
          "PRICE_COMPONENT"
        ) IS NULL
        THEN "PRICE_ITEM"
        ELSE "PRICE_COMPONENT"
      END AS "PRICE",
      CASE
        WHEN (
          "DISCOUNT_COMPONENT"
        ) IS NULL
        THEN "DISCOUNT_ITEM"
        ELSE CASE
          WHEN ABS("DISCOUNT_COMPONENT") > "PRICE"
          THEN "DISCOUNT_COMPONENT" / 100
          ELSE "DISCOUNT_COMPONENT"
        END
      END AS "DISCOUNT",
      CASE
        WHEN (
          "QUANTITY_COMPONENT"
        ) IS NULL
        THEN "QUANTITY_ITEM"
        ELSE "QUANTITY_COMPONENT" * "QUANTITY_ITEM"
      END AS "QUANTITY",
      CASE WHEN "KIT_ITEM" = 1 THEN "REFERENCE_CODE_ITEM" ELSE NULL END AS "REFERENCE_CODE_KIT",
      CASE WHEN (
        "REFERENCE_CODE_COMPONENT"
      ) IS NULL THEN 0 ELSE 1 END AS "KIT_COMPONENT",
      CASE
        WHEN (
          "PRODUCT_NAME_COMPONENT"
        ) IS NULL
        THEN "PRODUCT_NAME_ITEM"
        ELSE "PRODUCT_NAME_COMPONENT"
      END AS "PRODUCT_NAME",
      CASE
        WHEN (
          "SHIPPING_ESTIMATE_DATE_COMPONENT"
        ) IS NULL
        THEN "SHIPPING_ESTIMATE_DATE_ITEM"
        ELSE "SHIPPING_ESTIMATE_DATE_COMPONENT"
      END AS "SHIPPING_ESTIMATE_DATE",
      CASE WHEN (
        "EAN_COMPONENT"
      ) IS NULL THEN "EAN_ITEM" ELSE "EAN_COMPONENT" END AS "EAN",
      CASE
        WHEN (
          "CARRIER_COMPONENT"
        ) IS NULL
        THEN "CARRIER_ITEM"
        ELSE "CARRIER_COMPONENT"
      END AS "CARRIER"
    FROM "layer_0_Join_7"
  ) AS input_1
    ON input_0."ID" = input_1."ORDER_ID"
  )
     ORDER BY "SUBSIDIARY_ID"
    SEGMENTED BY HASH("SUBSIDIARY_ID") ALL NODES
  ;

  -- Node: Join_2
  PERFORM DROP TABLE IF EXISTS "layer_0_Join_2" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Join_2" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."SUBSIDIARY",
    input_1."EXTERNAL_ORDER_ID",
    input_1."SUBSIDIARY_ID",
    input_1."CREATION_DATE",
    input_1."STATUS",
    input_1."INTERNAL_STATUS",
    input_1."CUSTOMER_ID",
    input_1."STATUS_PAYMENT_PENDING_DATE",
    input_1."STATUS_PAYMENT_APPROVED_DATE",
    input_1."STATUS_PAYMENT_DENIED_DATE",
    input_1."STATUS_START_HANDLING_DATE",
    input_1."STATUS_HANDLING_SHIPPING_DATE",
    input_1."STATUS_INVOICED_DATE",
    input_1."STATUS_DELIVERED_DATE",
    input_1."STATUS_CANCELED_DATE",
    input_1."CANCELLATION_REASON",
    input_1."COMPLETE",
    input_1."ACQUIRER_MESSAGE",
    input_1."VENDOR",
    input_1."INVOICE_NUMBER",
    input_1."HOSTNAME",
    input_1."SELLER_ID",
    input_1."SELLER_NAME",
    input_1."MKT_UTM_COUPON",
    input_1."MKT_UTM_CAMPAIGN",
    input_1."MKT_UTM_MEDIUM",
    input_1."MKT_UTM_PARTNER",
    input_1."MKT_UTM_SRC",
    input_1."ID",
    input_1."MKT_CAMPAIGN_TAGS",
    input_1."AFFILIATE_ID",
    input_1."TRADE_POLICY",
    input_1."MKT_UTMI_PART",
    input_1."MKT_UTMI_PAGE",
    input_1."MKT_UTMI_CAMPAIGN",
    input_1."SELLER_ORDER_ID",
    input_1."CITY",
    input_1."ADDRESS_STATE",
    input_1."COUNTRY",
    input_1."LAST_UPDATE_DATE",
    input_1."INSERT_DATE",
    input_1."SHIPPING_COST",
    input_1."REFERENCE_CODE",
    input_1."PRICE",
    input_1."DISCOUNT",
    input_1."QUANTITY",
    input_1."REFERENCE_CODE_KIT",
    input_1."PRODUCT_NAME",
    input_1."SHIPPING_ESTIMATE_DATE",
    input_1."EAN",
    input_1."CARRIER",
    input_1."KIT_COMPONENT",
    input_1."CHANNEL",
    input_1."MACRO_CHANNEL",
    input_1."COD_SALES_CHANNEL",
    input_1."MKTPLACE_ORDER_ID",
    input_1."SELLER_INSTANCE_ID",
    input_1."IS_TRADE_IN",
    input_1."IS_SAMSUNG_CARE",
    input_1."SKU_ID"
  FROM (
    SELECT
      "ID",
      "SUBSIDIARY"
    FROM "U_PRJ_ECOM".DIM_SUBSIDIARY
  ) AS input_0
  INNER JOIN "layer_0_Join_1" AS input_1
    ON input_0."ID" = input_1."SUBSIDIARY_ID"
  )
     ORDER BY "CUSTOMER_ID", "SUBSIDIARY_ID"
    SEGMENTED BY HASH("CUSTOMER_ID", "SUBSIDIARY_ID") ALL NODES
  ;

  -- Node: Join_3
  PERFORM DROP TABLE IF EXISTS "layer_0_Join_3" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Join_3" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."EXTERNAL_ORDER_ID",
    input_0."SUBSIDIARY_ID",
    input_0."CREATION_DATE" AS "CREATION_DATETIME",
    input_0."STATUS",
    input_0."INTERNAL_STATUS",
    input_0."STATUS_PAYMENT_PENDING_DATE",
    input_0."STATUS_PAYMENT_APPROVED_DATE",
    input_0."STATUS_PAYMENT_DENIED_DATE",
    input_0."STATUS_START_HANDLING_DATE",
    input_0."STATUS_HANDLING_SHIPPING_DATE",
    input_0."STATUS_INVOICED_DATE",
    input_0."STATUS_DELIVERED_DATE",
    input_0."STATUS_CANCELED_DATE",
    input_0."CANCELLATION_REASON",
    input_0."COMPLETE",
    input_0."ACQUIRER_MESSAGE",
    input_0."VENDOR",
    input_0."INVOICE_NUMBER",
    input_0."HOSTNAME",
    input_0."SELLER_ID",
    input_0."SELLER_NAME",
    input_0."MKT_UTM_COUPON",
    input_0."MKT_UTM_CAMPAIGN",
    input_0."MKT_UTM_MEDIUM",
    input_0."MKT_UTM_PARTNER",
    input_0."MKT_UTM_SRC",
    input_0."SUBSIDIARY",
    input_0."ID",
    input_0."MKT_CAMPAIGN_TAGS",
    input_0."AFFILIATE_ID",
    input_0."TRADE_POLICY",
    input_0."COUNTRY",
    input_0."ADDRESS_STATE",
    input_0."CITY",
    input_0."SELLER_ORDER_ID",
    input_0."MKT_UTMI_CAMPAIGN",
    input_0."MKT_UTMI_PAGE",
    input_0."MKT_UTMI_PART",
    input_0."LAST_UPDATE_DATE",
    input_0."INSERT_DATE",
    input_0."SHIPPING_COST",
    input_0."REFERENCE_CODE",
    input_0."DISCOUNT",
    input_0."PRICE",
    input_0."QUANTITY",
    input_0."REFERENCE_CODE_KIT",
    input_0."KIT_COMPONENT",
    input_0."CARRIER",
    input_0."EAN",
    input_0."SHIPPING_ESTIMATE_DATE",
    input_0."PRODUCT_NAME",
    input_0."CHANNEL",
    input_0."MACRO_CHANNEL",
    input_0."COD_SALES_CHANNEL",
    input_0."MKTPLACE_ORDER_ID",
    input_0."SELLER_INSTANCE_ID",
    input_0."IS_TRADE_IN",
    input_0."IS_SAMSUNG_CARE",
    input_0."SKU_ID",
    input_1."BIRTHDAY",
    input_1."GENDER",
    input_1."NAME",
    input_1."OPT_IN",
    input_1."CREATION_DATE" AS "CUSTOMER_CREATION_DATE",
    TO_DATE(("CREATION_DATETIME")::VARCHAR, 'YYYY-MM-DD') AS "CREATION_DATE"
  FROM "layer_0_Join_2" AS input_0
  INNER JOIN (
    SELECT
      "ID",
      "BIRTHDAY",
      "GENDER",
      "NAME",
      "OPT_IN",
      "SUBSIDIARY_ID",
      "CREATION_DATE"
    FROM "U_PRJ_ECOM".DIM_CUSTOMER
  ) AS input_1
    ON input_0."CUSTOMER_ID" = input_1."ID"
    AND input_0."SUBSIDIARY_ID" = input_1."SUBSIDIARY_ID"
  )
     ORDER BY "CREATION_DATE", "SUBSIDIARY_ID"
    SEGMENTED BY HASH("CREATION_DATE", "SUBSIDIARY_ID") ALL NODES
  ;

  -- Node: Join_4
  PERFORM DROP TABLE IF EXISTS "layer_0_Join_4" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Join_4" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."BIRTHDAY",
    input_0."GENDER",
    input_0."NAME",
    input_0."OPT_IN",
    input_0."CUSTOMER_CREATION_DATE",
    input_0."EXTERNAL_ORDER_ID",
    input_0."SUBSIDIARY_ID",
    input_0."CREATION_DATETIME",
    input_0."STATUS",
    input_0."INTERNAL_STATUS",
    input_0."STATUS_PAYMENT_PENDING_DATE",
    input_0."STATUS_PAYMENT_APPROVED_DATE",
    input_0."STATUS_PAYMENT_DENIED_DATE",
    input_0."STATUS_START_HANDLING_DATE",
    input_0."STATUS_HANDLING_SHIPPING_DATE",
    input_0."STATUS_INVOICED_DATE",
    input_0."STATUS_DELIVERED_DATE",
    input_0."STATUS_CANCELED_DATE",
    input_0."CANCELLATION_REASON",
    input_0."COMPLETE",
    input_0."ACQUIRER_MESSAGE",
    input_0."VENDOR",
    input_0."INVOICE_NUMBER",
    input_0."HOSTNAME",
    input_0."SELLER_ID",
    input_0."SELLER_NAME",
    input_0."MKT_UTM_COUPON",
    input_0."MKT_UTM_CAMPAIGN",
    input_0."MKT_UTM_MEDIUM",
    input_0."MKT_UTM_PARTNER",
    input_0."MKT_UTM_SRC",
    input_0."SUBSIDIARY",
    input_0."CREATION_DATE",
    input_0."ID",
    input_0."MKT_CAMPAIGN_TAGS",
    input_0."AFFILIATE_ID",
    input_0."TRADE_POLICY",
    input_0."COUNTRY",
    input_0."ADDRESS_STATE",
    input_0."CITY",
    input_0."SELLER_ORDER_ID",
    input_0."MKT_UTMI_CAMPAIGN",
    input_0."MKT_UTMI_PAGE",
    input_0."MKT_UTMI_PART",
    input_0."LAST_UPDATE_DATE",
    input_0."INSERT_DATE",
    input_0."SHIPPING_COST",
    input_0."REFERENCE_CODE",
    input_0."PRICE",
    input_0."DISCOUNT",
    input_0."QUANTITY",
    input_0."REFERENCE_CODE_KIT",
    input_0."KIT_COMPONENT",
    input_0."CARRIER",
    input_0."EAN",
    input_0."SHIPPING_ESTIMATE_DATE",
    input_0."PRODUCT_NAME",
    input_0."CHANNEL",
    input_0."MACRO_CHANNEL",
    input_0."COD_SALES_CHANNEL",
    input_0."MKTPLACE_ORDER_ID",
    input_0."SELLER_INSTANCE_ID",
    input_0."IS_TRADE_IN",
    input_0."IS_SAMSUNG_CARE",
    input_0."SKU_ID",
    input_1."VALUE",
    input_1."REFERENCE_DATE",
    input_1."REFERENCE_CURRENCY"
  FROM "layer_0_Join_3" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "SUBSIDIARY_ID",
      "REFERENCE_CURRENCY",
      "REFERENCE_DATE",
      "VALUE"
    FROM "U_PRJ_ECOM".DIM_EXCHANGE_RATE
  ) AS input_1
    ON input_0."CREATION_DATE" = input_1."REFERENCE_DATE"
    AND input_0."SUBSIDIARY_ID" = input_1."SUBSIDIARY_ID"
  )
     ORDER BY "REFERENCE_CODE"
    SEGMENTED BY HASH("REFERENCE_CODE") ALL NODES
  ;

  -- Node: Join_5
  PERFORM DROP TABLE IF EXISTS "layer_0_Join_5" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Join_5" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."VALUE",
    input_0."REFERENCE_DATE",
    input_0."REFERENCE_CURRENCY",
    input_0."BIRTHDAY",
    input_0."GENDER",
    input_0."NAME",
    input_0."OPT_IN",
    input_0."CUSTOMER_CREATION_DATE",
    input_0."EXTERNAL_ORDER_ID",
    input_0."SUBSIDIARY_ID",
    input_0."CREATION_DATETIME",
    input_0."STATUS",
    input_0."INTERNAL_STATUS",
    input_0."STATUS_PAYMENT_PENDING_DATE",
    input_0."STATUS_PAYMENT_APPROVED_DATE",
    input_0."STATUS_PAYMENT_DENIED_DATE",
    input_0."STATUS_START_HANDLING_DATE",
    input_0."STATUS_HANDLING_SHIPPING_DATE",
    input_0."STATUS_INVOICED_DATE",
    input_0."STATUS_DELIVERED_DATE",
    input_0."STATUS_CANCELED_DATE",
    input_0."CANCELLATION_REASON",
    input_0."COMPLETE",
    input_0."ACQUIRER_MESSAGE",
    input_0."VENDOR",
    input_0."INVOICE_NUMBER",
    input_0."HOSTNAME",
    input_0."SELLER_ID",
    input_0."SELLER_NAME",
    input_0."MKT_UTM_COUPON",
    input_0."MKT_UTM_CAMPAIGN",
    input_0."MKT_UTM_MEDIUM",
    input_0."MKT_UTM_PARTNER",
    input_0."MKT_UTM_SRC",
    input_0."SUBSIDIARY",
    input_0."CREATION_DATE",
    input_0."ID",
    input_0."MKT_CAMPAIGN_TAGS",
    input_0."AFFILIATE_ID",
    input_0."TRADE_POLICY",
    input_0."COUNTRY",
    input_0."ADDRESS_STATE",
    input_0."CITY",
    input_0."SELLER_ORDER_ID",
    input_0."MKT_UTMI_CAMPAIGN",
    input_0."MKT_UTMI_PAGE",
    input_0."MKT_UTMI_PART",
    input_0."LAST_UPDATE_DATE",
    input_0."INSERT_DATE",
    input_0."SHIPPING_COST",
    input_0."REFERENCE_CODE",
    input_0."DISCOUNT",
    input_0."PRICE",
    input_0."QUANTITY",
    input_0."REFERENCE_CODE_KIT",
    input_0."KIT_COMPONENT",
    input_0."CARRIER",
    input_0."EAN",
    input_0."SHIPPING_ESTIMATE_DATE",
    input_0."PRODUCT_NAME",
    input_0."CHANNEL",
    input_0."MACRO_CHANNEL",
    input_0."COD_SALES_CHANNEL",
    input_0."MKTPLACE_ORDER_ID",
    input_0."SELLER_INSTANCE_ID",
    input_0."IS_TRADE_IN",
    input_0."IS_SAMSUNG_CARE",
    input_0."SKU_ID",
    input_1."MARKET_NAME",
    input_1."CATEGORY",
    input_1."PRODUCT_GROUP",
    input_1."SKU",
    input_1."DIVISION",
    input_1."FLAGSHIP",
    input_1."FAMILY_GROUP"
  FROM "layer_0_Join_4" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "MARKET_NAME",
      "CATEGORY",
      "PRODUCT_GROUP",
      "SKU",
      "DIVISION",
      "FLAGSHIP",
      "FAMILY_GROUP"
    FROM "U_PRJ_ECOM".DIM_PRODUCT_CATEGORY
  ) AS input_1
    ON input_0."REFERENCE_CODE" = input_1."SKU"
  )
     ORDER BY "SUBSIDIARY_ID", "REFERENCE_CODE"
    SEGMENTED BY HASH("SUBSIDIARY_ID", "REFERENCE_CODE") ALL NODES
  ;

  -- Node: Join_6
  PERFORM DROP TABLE IF EXISTS "layer_0_Join_6" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Join_6" ON COMMIT PRESERVE ROWS AS 
  SELECT
    input_0."MARKET_NAME",
    input_0."CATEGORY",
    input_0."PRODUCT_GROUP",
    input_0."SKU",
    input_0."DIVISION",
    input_0."VALUE",
    input_0."REFERENCE_DATE",
    input_0."REFERENCE_CURRENCY",
    input_0."BIRTHDAY",
    input_0."GENDER",
    input_0."NAME",
    input_0."OPT_IN",
    input_0."CUSTOMER_CREATION_DATE",
    input_0."EXTERNAL_ORDER_ID",
    input_0."SUBSIDIARY_ID",
    input_0."CREATION_DATETIME",
    input_0."STATUS",
    input_0."INTERNAL_STATUS",
    input_0."STATUS_PAYMENT_PENDING_DATE",
    input_0."STATUS_PAYMENT_APPROVED_DATE",
    input_0."STATUS_PAYMENT_DENIED_DATE",
    input_0."STATUS_START_HANDLING_DATE",
    input_0."STATUS_HANDLING_SHIPPING_DATE",
    input_0."STATUS_INVOICED_DATE",
    input_0."STATUS_DELIVERED_DATE",
    input_0."STATUS_CANCELED_DATE",
    input_0."CANCELLATION_REASON",
    input_0."COMPLETE",
    input_0."ACQUIRER_MESSAGE",
    input_0."VENDOR",
    input_0."INVOICE_NUMBER",
    input_0."HOSTNAME",
    input_0."SELLER_ID",
    input_0."SELLER_NAME",
    input_0."MKT_UTM_COUPON",
    input_0."MKT_UTM_CAMPAIGN",
    input_0."MKT_UTM_MEDIUM",
    input_0."MKT_UTM_PARTNER",
    input_0."MKT_UTM_SRC",
    input_0."SUBSIDIARY",
    input_0."CREATION_DATE",
    input_0."ID",
    input_0."FLAGSHIP",
    input_0."MKT_CAMPAIGN_TAGS",
    input_0."AFFILIATE_ID",
    input_0."TRADE_POLICY",
    input_0."COUNTRY",
    input_0."ADDRESS_STATE",
    input_0."CITY",
    input_0."SELLER_ORDER_ID",
    input_0."MKT_UTMI_CAMPAIGN",
    input_0."MKT_UTMI_PAGE",
    input_0."MKT_UTMI_PART",
    input_0."LAST_UPDATE_DATE",
    input_0."INSERT_DATE",
    input_0."FAMILY_GROUP",
    input_0."SHIPPING_COST",
    input_0."REFERENCE_CODE",
    input_0."PRICE",
    input_0."DISCOUNT",
    input_0."QUANTITY",
    input_0."REFERENCE_CODE_KIT",
    input_0."KIT_COMPONENT",
    input_0."CARRIER",
    input_0."EAN",
    input_0."SHIPPING_ESTIMATE_DATE",
    input_0."PRODUCT_NAME",
    input_0."CHANNEL",
    input_0."MACRO_CHANNEL",
    input_0."COD_SALES_CHANNEL",
    input_0."MKTPLACE_ORDER_ID",
    input_0."SELLER_INSTANCE_ID",
    input_0."IS_TRADE_IN",
    input_0."IS_SAMSUNG_CARE",
    input_0."SKU_ID",
    input_1."ACTIVE",
    input_1."IS_KIT",
    input_1."COST_PRICE",
    input_1."BASE_PRICE"
  FROM "layer_0_Join_5" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "REFERENCE_CODE",
      "ACTIVE",
      "IS_KIT",
      "SKU_ORIGIN",
      "SUBSIDIARY_ID",
      "COST_PRICE",
      "BASE_PRICE"
    FROM "U_PRJ_ECOM".DIM_ECOM_SKU
  ) AS input_1
    ON input_0."SUBSIDIARY_ID" = input_1."SUBSIDIARY_ID"
    AND input_0."REFERENCE_CODE" = input_1."REFERENCE_CODE"
  ;

  -- Node: Projection
  PERFORM DROP TABLE IF EXISTS "layer_0_Projection" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Projection" ON COMMIT PRESERVE ROWS AS 
  SELECT
    "ID",
    "EXTERNAL_ORDER_ID" AS "Order_Id",
    "SUBSIDIARY_ID" AS "Subsidiary_Id",
    "CREATION_DATETIME" AS "Creation_Datetime",
    "CREATION_DATE" AS "Creation_Date",
    "STATUS" AS "Status",
    "INTERNAL_STATUS" AS "Internal_Status",
    "STATUS_PAYMENT_PENDING_DATE" AS "Status_Payment_Pending_Date",
    "STATUS_PAYMENT_APPROVED_DATE" AS "Status_Payment_Approved_Date",
    "STATUS_PAYMENT_DENIED_DATE" AS "Status_Payment_Denied_Date",
    "STATUS_START_HANDLING_DATE" AS "Status_Start_Handling_Date",
    "STATUS_HANDLING_SHIPPING_DATE" AS "Status_Handling_Shipping_Date",
    "STATUS_INVOICED_DATE" AS "Status_Invoiced_Date",
    "STATUS_DELIVERED_DATE" AS "Status_Delivered_Date",
    "STATUS_CANCELED_DATE" AS "Status_Canceled_Date",
    "CANCELLATION_REASON" AS "Cancellation_Reason",
    "COMPLETE" AS "Complete",
    "ACQUIRER_MESSAGE" AS "Acquirer_Message",
    "VENDOR" AS "Vendor",
    "INVOICE_NUMBER" AS "Invoice_Number",
    "HOSTNAME" AS "Hostname",
    "MKT_UTM_SRC" AS "Mkt_Utm_Src",
    "MKT_UTM_PARTNER" AS "Mkt_Utm_Partner",
    "MKT_UTM_MEDIUM" AS "Mkt_Utm_Medium",
    "MKT_UTM_CAMPAIGN" AS "Mkt_Utm_Campaign",
    "MKT_UTM_COUPON" AS "Mkt_Utm_Coupon",
    "MKT_UTMI_PART" AS "Mkt_Utmi_Part",
    "MKT_UTMI_PAGE" AS "Mkt_Utmi_Page",
    "MKT_UTMI_CAMPAIGN" AS "Mkt_Utmi_Campaign",
    "SELLER_NAME" AS "Seller_Name",
    "SELLER_ID" AS "Seller_Id",
    "MKT_CAMPAIGN_TAGS" AS "Mkt_Campaign_Tags",
    "AFFILIATE_ID" AS "Affiliate_Id",
    "TRADE_POLICY" AS "Trade_Policy",
    "SELLER_ORDER_ID" AS "Seller_Order_Id",
    "REFERENCE_DATE" AS "Reference_Date",
    "REFERENCE_CURRENCY" AS "Reference_Currency",
    "VALUE" AS "Tax_Converter",
    "PRODUCT_NAME" AS "Product_Name",
    "REFERENCE_CODE" AS "Reference_Code",
    "QUANTITY" AS "Units",
    "EAN",
    "DISCOUNT" AS "Item_Discount",
    "SHIPPING_ESTIMATE_DATE" AS "Shipping_Estimate_Date",
    "CARRIER" AS "Carrier",
    "PRICE" AS "Price",
    "SHIPPING_COST" AS "Shipping_Cost_Item",
    "KIT_COMPONENT" AS "Kit_Component",
    "REFERENCE_CODE_KIT" AS "Reference_Code_Kit",
    "ACTIVE" AS "Active",
    "IS_KIT" AS "Is_Kit",
    "SUBSIDIARY" AS "Subsidiary",
    "SKU" AS "Sku",
    "DIVISION" AS "Division",
    "FAMILY_GROUP" AS "Family_Group",
    "PRODUCT_GROUP" AS "Product_Group",
    "CATEGORY" AS "Category",
    "MARKET_NAME" AS "Market_Name",
    "FLAGSHIP" AS "Flagship",
    "BIRTHDAY" AS "Birthday",
    "GENDER" AS "Gender",
    "NAME" AS "Name",
    "OPT_IN" AS "Opt_In",
    "CUSTOMER_CREATION_DATE" AS "Customer_Creation_Date",
    "COUNTRY" AS "Country",
    "ADDRESS_STATE" AS "Address_State",
    "CITY" AS "City",
    "LAST_UPDATE_DATE" AS "Last_Update_Date",
    "INSERT_DATE" AS "Insert_Date",
    "COST_PRICE" AS "Price_To",
    "BASE_PRICE" AS "Price_From",
    "CHANNEL" AS "Channel",
    "MACRO_CHANNEL" AS "Macro_Channel",
    "COD_SALES_CHANNEL",
    "MKTPLACE_ORDER_ID",
    "SELLER_INSTANCE_ID",
    "IS_TRADE_IN",
    "IS_SAMSUNG_CARE",
    "SKU_ID",
    (
      "Units" * "Price"
    ) - ABS("Item_Discount") + "Shipping_Cost_Item" AS "Total_Item",
    (
      (
        (
          "Units" * "Price"
        ) - "Item_Discount"
      ) + "Shipping_Cost_Item"
    ) * "Tax_Converter" AS "Total_Item_USD"
  FROM "layer_0_Join_6"
  ;

  -- Materialize final result
  PERFORM CREATE TABLE IF NOT EXISTS OW_SEDA_S.VIEWCV_CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS_SYNAPCOM AS
    SELECT * FROM "layer_0_Projection" WHERE 1=0;
  PERFORM TRUNCATE TABLE OW_SEDA_S.VIEWCV_CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS_SYNAPCOM;
  PERFORM INSERT INTO OW_SEDA_S.VIEWCV_CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS_SYNAPCOM
  SELECT * FROM "layer_0_Projection";

  PERFORM COMMIT;
  RAISE NOTICE 'Successfully loaded OW_SEDA_S.VIEWCV_CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS_SYNAPCOM';

END;
$$;