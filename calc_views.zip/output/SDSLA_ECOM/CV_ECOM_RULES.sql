CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_CV_ECOM_RULES" AS
SELECT
  "ID",
  "Order_Id",
  "Subsidiary_Id",
  "Subsidiary",
  "Creation_Date",
  "Status",
  "Channel",
  "Name",
  "Product_Name",
  "Reference_Code",
  "Division",
  "Family_Group",
  "Product_Group",
  "Category",
  "Flagship",
  "Is_Kit",
  "Units",
  "Price",
  "Item_Discount",
  "Shipping_Cost_Item",
  "Tax_Converter",
  "Mkt_Utm_Campaign",
  "Mkt_Utmi_Campaign",
  "Dummy",
  (
    (
      "Units" * "Price"
    ) - "Item_Discount"
  ) + "Shipping_Cost_Item" AS "Total_Item",
  (
    (
      (
        "Units" * "Price"
      ) - "Item_Discount"
    ) + "Shipping_Cost_Item"
  ) * "Tax_Converter" AS "Total_Item_USD"
FROM (
  SELECT
    "Order_Id" AS "ORDER_ID",
    "Subsidiary_Id" AS "SUBSIDIARY_ID",
    "Subsidiary" AS "SUBSIDIARY",
    "Creation_Date" AS "CREATION_DATE",
    "Status" AS "STATUS",
    "Product_Name" AS "PRODUCT_NAME",
    "Reference_Code" AS "REFERENCE_CODE",
    "Division" AS "DIVISION",
    "Product_Group" AS "PRODUCT_GROUP",
    "Category" AS "CATEGORY",
    "Flagship" AS "FLAGSHIP",
    "Units" AS "UNITS",
    "Price" AS "PRICE",
    "Item_Discount" AS "ITEM_DISCOUNT",
    "Shipping_Cost_Item" AS "SHIPPING_COST_ITEM",
    "Tax_Converter" AS "TAX_CONVERTER",
    "ID",
    "Dummy" AS "DUMMY",
    "Is_Kit" AS "IS_KIT",
    "Channel" AS "CHANNEL",
    "Name" AS "NAME",
    "Mkt_Utm_Campaign" AS "MKT_UTM_CAMPAIGN",
    "Mkt_Utmi_Campaign" AS "MKT_UTMI_CAMPAIGN",
    "Family_Group" AS "FAMILY_GROUP"
  FROM (
    SELECT
      "Order_Id",
      "Subsidiary_Id",
      "Creation_Date",
      "Status",
      "Tax_Converter",
      "Product_Name",
      "Reference_Code",
      "Units",
      "Item_Discount",
      "Price",
      "Shipping_Cost_Item",
      "Subsidiary",
      "Division",
      "Product_Group",
      "Category",
      "Flagship",
      "ID",
      "Is_Kit",
      "Channel",
      "Name",
      "Mkt_Utm_Campaign",
      "Mkt_Utmi_Campaign",
      "Family_Group",
      1 AS "Dummy"
    FROM "OW_SEDA_S"."VIEWCV_CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS"
  ) AS Projection_1
  UNION ALL
  SELECT
    "Marketplace_Order_Id" AS "ORDER_ID",
    "Subsidiary_Id" AS "SUBSIDIARY_ID",
    "Subsidiary" AS "SUBSIDIARY",
    "Creation_Date" AS "CREATION_DATE",
    "Status" AS "STATUS",
    "Product_Name" AS "PRODUCT_NAME",
    "Reference_Code" AS "REFERENCE_CODE",
    "Division" AS "DIVISION",
    "Product_Group" AS "PRODUCT_GROUP",
    "Category" AS "CATEGORY",
    "Flagship" AS "FLAGSHIP",
    "Units" AS "UNITS",
    "Price" AS "PRICE",
    "Item_Discount" AS "ITEM_DISCOUNT",
    "Shipping_Cost_Item" AS "SHIPPING_COST_ITEM",
    "Tax_Converter" AS "TAX_CONVERTER",
    "ID",
    "Dummy" AS "DUMMY",
    "Is_Kit" AS "IS_KIT",
    "Channel" AS "CHANNEL",
    "Name" AS "NAME",
    NULL AS "MKT_UTM_CAMPAIGN",
    NULL AS "MKT_UTMI_CAMPAIGN",
    "Family_Group" AS "FAMILY_GROUP"
  FROM (
    SELECT
      "Subsidiary_Id",
      "Subsidiary",
      "Creation_Date",
      "Status",
      "Marketplace_Order_Id",
      "Reference_Code",
      "Product_Name",
      "Division",
      "Product_Group",
      "Category",
      "Flagship",
      "Units",
      "Price",
      "Tax_Converter",
      "ID",
      "Name",
      "Family_Group",
      0 AS "Shipping_Cost_Item",
      0 AS "Item_Discount",
      1 AS "Dummy",
      0 AS "Is_Kit",
      'MGZ' AS "Channel"
    FROM OW_SEDA_S.CV_ECOM_MGLU_ORDERS_CUSTOMERS_PRODUCTS
  ) AS Projection_2
) AS Union_1