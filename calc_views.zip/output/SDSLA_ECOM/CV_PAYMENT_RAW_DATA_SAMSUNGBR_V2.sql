-- Migrated from HANA Calculation View: OW_SEDA_S.VIEWCV_CV_PAYMENT_RAW_DATA_SAMSUNGBR_V2
-- Description: CV_PAYMENT_RAW_DATA_SAMSUNGBR_V3

CREATE OR REPLACE PROCEDURE OW_SEDA_S.load_VIEWCV_CV_PAYMENT_RAW_DATA_SAMSUNGBR_V2()
LANGUAGE PLvSQL AS $$
BEGIN

  -- Layer 0: 31 nodes

  -- Node: Join_1
  PERFORM DROP TABLE IF EXISTS "layer_0_Join_1" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Join_1" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."ID",
    input_0."EXTERNAL_ORDER_ID",
    input_0."SUBSIDIARY_ID",
    input_0."CREATION_DATE",
    input_0."STATUS",
    input_0."INTERNAL_STATUS",
    input_0."ORDER_VALUE",
    input_0."CUSTOMER_ID",
    input_0."DISCOUNT",
    input_0."STATUS_PAYMENT_PENDING_DATE",
    input_0."STATUS_PAYMENT_APPROVED_DATE",
    input_0."STATUS_PAYMENT_DENIED_DATE",
    input_0."STATUS_START_HANDLING_DATE",
    input_0."STATUS_HANDLING_SHIPPING_DATE",
    input_0."STATUS_INVOICED_DATE",
    input_0."STATUS_DELIVERED_DATE",
    input_0."STATUS_CANCELED_DATE",
    input_0."CANCELLATION_REASON",
    input_0."COMPLETE",
    input_0."ACQUIRER_MESSAGE",
    input_0."SHIPPING_COST",
    input_0."VENDOR",
    input_0."INVOICE_NUMBER",
    input_0."HOSTNAME",
    input_0."SELLER_ID",
    input_0."SELLER_NAME",
    input_0."MKT_UTM_COUPON",
    input_0."MKT_UTM_CAMPAIGN",
    input_0."MKT_UTM_MEDIUM",
    input_0."MKT_UTM_PARTNER",
    input_0."MKT_UTM_SRC",
    input_0."ID" AS "ID_1",
    input_0."EXTERNAL_ORDER_ID" AS "EXTERNAL_ORDER_ID_1",
    input_0."SUBSIDIARY_ID" AS "SUBSIDIARY_ID_1",
    input_0."CREATION_DATE" AS "CREATION_DATE_1",
    input_0."STATUS" AS "STATUS_1",
    input_0."INTERNAL_STATUS" AS "INTERNAL_STATUS_1",
    input_0."ORDER_VALUE" AS "ORDER_VALUE_1",
    input_0."CUSTOMER_ID" AS "CUSTOMER_ID_1",
    input_0."DISCOUNT" AS "DISCOUNT_1",
    input_0."STATUS_PAYMENT_PENDING_DATE" AS "STATUS_PAYMENT_PENDING_DATE_1",
    input_0."STATUS_PAYMENT_APPROVED_DATE" AS "STATUS_PAYMENT_APPROVED_DATE_1",
    input_0."STATUS_PAYMENT_DENIED_DATE" AS "STATUS_PAYMENT_DENIED_DATE_1",
    input_0."STATUS_START_HANDLING_DATE" AS "STATUS_START_HANDLING_DATE_1",
    input_0."STATUS_HANDLING_SHIPPING_DATE" AS "STATUS_HANDLING_SHIPPING_DATE_1",
    input_0."STATUS_INVOICED_DATE" AS "STATUS_INVOICED_DATE_1",
    input_0."STATUS_DELIVERED_DATE" AS "STATUS_DELIVERED_DATE_1",
    input_0."STATUS_CANCELED_DATE" AS "STATUS_CANCELED_DATE_1",
    input_0."CANCELLATION_REASON" AS "CANCELLATION_REASON_1",
    input_0."COMPLETE" AS "COMPLETE_1",
    input_0."ACQUIRER_MESSAGE" AS "ACQUIRER_MESSAGE_1",
    input_0."SHIPPING_COST" AS "SHIPPING_COST_1",
    input_0."VENDOR" AS "VENDOR_1",
    input_0."INVOICE_NUMBER" AS "INVOICE_NUMBER_1",
    input_0."HOSTNAME" AS "HOSTNAME_1",
    input_0."SELLER_ID" AS "SELLER_ID_1",
    input_0."SELLER_NAME" AS "SELLER_NAME_1",
    input_0."MKT_UTM_COUPON" AS "MKT_UTM_COUPON_1",
    input_0."MKT_UTM_CAMPAIGN" AS "MKT_UTM_CAMPAIGN_1",
    input_0."MKT_UTM_MEDIUM" AS "MKT_UTM_MEDIUM_1",
    input_0."MKT_UTM_PARTNER" AS "MKT_UTM_PARTNER_1",
    input_0."MKT_UTM_SRC" AS "MKT_UTM_SRC_1",
    input_0."COUNTRY",
    input_0."ADDRESS_STATE",
    input_0."CITY",
    input_0."SELLER_ORDER_ID",
    input_0."MKT_UTMI_CAMPAIGN",
    input_0."MKT_UTMI_PAGE",
    input_0."MKT_UTMI_PART",
    input_0."TRADE_POLICY",
    input_0."MKT_CAMPAIGN_TAGS",
    input_0."Channel",
    input_0."LAST_UPDATE_DATE",
    input_0."INSERT_DATE",
    input_0."AFFILIATE_ID",
    input_0."SOURCE",
    input_0."SELLER_INSTANCE_ID",
    input_0."COD_SALES_CHANNEL",
    input_0."IS_TRADE_IN",
    input_0."ORDER_SEQUENCE",
    input_0."ADDRESS_TYPE",
    input_1."PRODUCT_NAME",
    input_1."REFERENCE_CODE",
    input_1."QUANTITY",
    input_1."EAN",
    input_1."DISCOUNT" AS "ITEM_DISCOUNT",
    input_1."SHIPPING_ESTIMATE_DATE",
    input_1."CARRIER",
    input_1."PRICE",
    input_1."SHIPPING_COST" AS "SHIPPING_COST_ITEM",
    input_1."IS_SAMSUNG_CARE"
  FROM (
    SELECT
      "ID",
      "EXTERNAL_ORDER_ID",
      "SUBSIDIARY_ID",
      "CREATION_DATE",
      "STATUS",
      "INTERNAL_STATUS",
      "ORDER_VALUE",
      "CUSTOMER_ID",
      "DISCOUNT",
      "STATUS_PAYMENT_PENDING_DATE",
      "STATUS_PAYMENT_APPROVED_DATE",
      "STATUS_PAYMENT_DENIED_DATE",
      "STATUS_START_HANDLING_DATE",
      "STATUS_HANDLING_SHIPPING_DATE",
      "STATUS_INVOICED_DATE",
      "STATUS_DELIVERED_DATE",
      "STATUS_CANCELED_DATE",
      "CANCELLATION_REASON",
      "COMPLETE",
      "ACQUIRER_MESSAGE",
      "SHIPPING_COST",
      "VENDOR",
      "INVOICE_NUMBER",
      "HOSTNAME",
      "SELLER_ID",
      "SELLER_NAME",
      "MKT_UTM_COUPON",
      "MKT_UTM_CAMPAIGN",
      "MKT_UTM_MEDIUM",
      "MKT_UTM_PARTNER",
      "MKT_UTM_SRC",
      "COUNTRY",
      "ADDRESS_STATE",
      "CITY",
      "SELLER_ORDER_ID",
      "MKT_UTMI_CAMPAIGN",
      "MKT_UTMI_PAGE",
      "MKT_UTMI_PART",
      "TRADE_POLICY",
      "MKT_CAMPAIGN_TAGS",
      "AFFILIATE_ID",
      "LAST_UPDATE_DATE",
      "INSERT_DATE",
      "SOURCE",
      "SELLER_INSTANCE_ID",
      "COD_SALES_CHANNEL",
      "ADDRESS_TYPE",
      "ORDER_SEQUENCE",
      "IS_TRADE_IN",
      CASE
        WHEN "SUBSIDIARY_ID" = 3 AND "AFFILIATE_ID" = 'MLC'
        THEN 'MERCADO LIBRE'
        WHEN "SUBSIDIARY_ID" = 3
        THEN "TRADE_POLICY"
        WHEN "AFFILIATE_ID" IN ('MRC', 'MCL')
        THEN 'MERCADO LIVRE'
        WHEN "AFFILIATE_ID" IN ('SSG', 'SAMSUNG', 'SSP')
        THEN 'SAMSUNG'
        WHEN "AFFILIATE_ID" = 'BWW'
        THEN 'B2W'
        WHEN "AFFILIATE_ID" = 'VVJ'
        THEN 'VIA VAREJO'
        WHEN "AFFILIATE_ID" = 'VVT'
        THEN 'VIVO'
        WHEN "AFFILIATE_ID" = 'SNG'
        THEN 'EPP B2B2C'
        WHEN "AFFILIATE_ID" = 'SMG'
        THEN 'EPP FUNCIONÁRIOS'
        WHEN "AFFILIATE_ID" = 'CDR'
        THEN 'CREDITAS'
        WHEN "AFFILIATE_ID" = 'BNT'
        THEN 'INTER'
        WHEN "AFFILIATE_ID" = 'NVM'
        THEN 'NOVO MUNDO'
        WHEN "AFFILIATE_ID" = 'ZMM'
        THEN 'ZOOM'
        WHEN "AFFILIATE_ID" = 'PSG'
        THEN 'PORTO'
        WHEN "AFFILIATE_ID" IN ('SPV', 'SVC')
        THEN 'SSG P/VC'
        WHEN "AFFILIATE_ID" = 'CRF'
        THEN 'CARREFOUR'
        WHEN "AFFILIATE_ID" = 'PLC'
        THEN 'OI'
        WHEN "AFFILIATE_ID" = 'DDV'
        THEN 'INDEVA'
        WHEN "AFFILIATE_ID" = 'MGZ'
        THEN 'MAGALU'
        WHEN "AFFILIATE_ID" = 'RDT'
        THEN 'RICARDO'
        WHEN "AFFILIATE_ID" = 'HTG'
        THEN 'HOMETOGO'
        WHEN "AFFILIATE_ID" = 'BCR'
        THEN 'BALCAO RURAL'
        WHEN "AFFILIATE_ID" = 'LTM'
        THEN 'IUPP/ITAU'
        WHEN "AFFILIATE_ID" = 'KBM'
        THEN 'KABUM'
        WHEN "AFFILIATE_ID" = 'CLR'
        THEN 'CLARO'
        WHEN "AFFILIATE_ID" = 'NTS'
        THEN 'NETSHOES'
        WHEN "AFFILIATE_ID" = 'SMS'
        THEN 'C.CERTA'
        WHEN "AFFILIATE_ID" = 'LRM'
        THEN 'L.MERLIN'
        WHEN "AFFILIATE_ID" = 'SSC'
        THEN 'SSG ITAUCARD'
        ELSE "AFFILIATE_ID"
      END AS "Channel"
    FROM "U_PRJ_ECOM".FT_ECOM_ORDER
  ) AS input_0
  INNER JOIN (
    SELECT
      "ORDER_ID",
      "PRODUCT_NAME",
      "REFERENCE_CODE",
      "QUANTITY",
      "EAN",
      "DISCOUNT",
      "SHIPPING_ESTIMATE_DATE",
      "CARRIER",
      "PRICE",
      "SHIPPING_COST",
      "IS_SAMSUNG_CARE",
      "INVOICE_NUMBER"
    FROM "U_PRJ_ECOM".FT_ECOM_ORDER_ITEM
  ) AS input_1
    ON input_0."ID" = input_1."ORDER_ID"
  )
     ORDER BY "SUBSIDIARY_ID"
    SEGMENTED BY HASH("SUBSIDIARY_ID") ALL NODES
  ;

  -- Node: Join_2
  PERFORM DROP TABLE IF EXISTS "layer_0_Join_2" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Join_2" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."PRODUCT_NAME",
    input_0."REFERENCE_CODE",
    input_0."QUANTITY",
    input_0."EAN",
    input_0."ITEM_DISCOUNT",
    input_0."SHIPPING_ESTIMATE_DATE",
    input_0."CARRIER",
    input_0."PRICE",
    input_0."SHIPPING_COST_ITEM",
    input_0."EXTERNAL_ORDER_ID",
    input_0."SUBSIDIARY_ID",
    input_0."CREATION_DATE",
    input_0."STATUS",
    input_0."INTERNAL_STATUS",
    input_0."ORDER_VALUE",
    input_0."CUSTOMER_ID",
    input_0."DISCOUNT",
    input_0."STATUS_PAYMENT_PENDING_DATE",
    input_0."STATUS_PAYMENT_APPROVED_DATE",
    input_0."STATUS_PAYMENT_DENIED_DATE",
    input_0."STATUS_START_HANDLING_DATE",
    input_0."STATUS_HANDLING_SHIPPING_DATE",
    input_0."STATUS_INVOICED_DATE",
    input_0."STATUS_DELIVERED_DATE",
    input_0."STATUS_CANCELED_DATE",
    input_0."CANCELLATION_REASON",
    input_0."COMPLETE",
    input_0."ACQUIRER_MESSAGE",
    input_0."SHIPPING_COST",
    input_0."VENDOR",
    input_0."INVOICE_NUMBER",
    input_0."HOSTNAME",
    input_0."SELLER_ID",
    input_0."SELLER_NAME",
    input_0."MKT_UTM_COUPON",
    input_0."MKT_UTM_CAMPAIGN",
    input_0."MKT_UTM_MEDIUM",
    input_0."MKT_UTM_PARTNER",
    input_0."MKT_UTM_SRC",
    input_0."ID",
    input_0."MKT_CAMPAIGN_TAGS",
    input_0."TRADE_POLICY",
    input_0."MKT_UTMI_PART",
    input_0."MKT_UTMI_PAGE",
    input_0."MKT_UTMI_CAMPAIGN",
    input_0."SELLER_ORDER_ID",
    input_0."CITY",
    input_0."ADDRESS_STATE",
    input_0."COUNTRY",
    input_0."Channel",
    input_0."LAST_UPDATE_DATE",
    input_0."INSERT_DATE",
    input_0."AFFILIATE_ID",
    input_0."SOURCE",
    input_0."SELLER_INSTANCE_ID",
    input_0."COD_SALES_CHANNEL",
    input_0."IS_SAMSUNG_CARE",
    input_0."IS_TRADE_IN",
    input_0."ORDER_SEQUENCE",
    input_0."ADDRESS_TYPE",
    input_1."SUBSIDIARY"
  FROM "layer_0_Join_1" AS input_0
  INNER JOIN (
    SELECT
      "ID",
      "SUBSIDIARY"
    FROM "U_PRJ_ECOM".DIM_SUBSIDIARY
  ) AS input_1
    ON input_0."SUBSIDIARY_ID" = input_1."ID"
  )
     ORDER BY "CUSTOMER_ID", "SUBSIDIARY_ID"
    SEGMENTED BY HASH("CUSTOMER_ID", "SUBSIDIARY_ID") ALL NODES
  ;

  -- Node: Join_3
  PERFORM DROP TABLE IF EXISTS "layer_0_Join_3" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Join_3" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."PRODUCT_NAME",
    input_0."REFERENCE_CODE",
    input_0."QUANTITY",
    input_0."EAN",
    input_0."ITEM_DISCOUNT",
    input_0."SHIPPING_ESTIMATE_DATE",
    input_0."CARRIER",
    input_0."PRICE",
    input_0."SHIPPING_COST_ITEM",
    input_0."EXTERNAL_ORDER_ID",
    input_0."SUBSIDIARY_ID",
    input_0."CREATION_DATE" AS "CREATION_DATETIME",
    input_0."STATUS",
    input_0."INTERNAL_STATUS",
    input_0."ORDER_VALUE",
    input_0."DISCOUNT",
    input_0."STATUS_PAYMENT_PENDING_DATE",
    input_0."STATUS_PAYMENT_APPROVED_DATE",
    input_0."STATUS_PAYMENT_DENIED_DATE",
    input_0."STATUS_START_HANDLING_DATE",
    input_0."STATUS_HANDLING_SHIPPING_DATE",
    input_0."STATUS_INVOICED_DATE",
    input_0."STATUS_DELIVERED_DATE",
    input_0."STATUS_CANCELED_DATE",
    input_0."CANCELLATION_REASON",
    input_0."COMPLETE",
    input_0."ACQUIRER_MESSAGE",
    input_0."SHIPPING_COST",
    input_0."VENDOR",
    input_0."INVOICE_NUMBER",
    input_0."HOSTNAME",
    input_0."SELLER_ID",
    input_0."SELLER_NAME",
    input_0."MKT_UTM_COUPON",
    input_0."MKT_UTM_CAMPAIGN",
    input_0."MKT_UTM_MEDIUM",
    input_0."MKT_UTM_PARTNER",
    input_0."MKT_UTM_SRC",
    input_0."SUBSIDIARY",
    input_0."ID",
    input_0."MKT_CAMPAIGN_TAGS",
    input_0."TRADE_POLICY",
    input_0."COUNTRY",
    input_0."ADDRESS_STATE",
    input_0."CITY",
    input_0."SELLER_ORDER_ID",
    input_0."MKT_UTMI_CAMPAIGN",
    input_0."MKT_UTMI_PAGE",
    input_0."MKT_UTMI_PART",
    input_0."Channel",
    input_0."LAST_UPDATE_DATE",
    input_0."INSERT_DATE",
    input_0."AFFILIATE_ID",
    input_0."SOURCE",
    input_0."SELLER_INSTANCE_ID",
    input_0."COD_SALES_CHANNEL",
    input_0."CUSTOMER_ID",
    input_0."ADDRESS_TYPE",
    input_0."ORDER_SEQUENCE",
    input_0."IS_TRADE_IN",
    input_0."IS_SAMSUNG_CARE",
    input_1."BIRTHDAY",
    input_1."GENDER",
    input_1."NAME",
    input_1."OPT_IN",
    input_1."CREATION_DATE" AS "CUSTOMER_CREATION_DATE",
    TO_DATE(("CREATION_DATETIME")::VARCHAR, 'YYYY-MM-DD') AS "CREATION_DATE"
  FROM "layer_0_Join_2" AS input_0
  INNER JOIN (
    SELECT
      "ID",
      "BIRTHDAY",
      "GENDER",
      "NAME",
      "OPT_IN",
      "SUBSIDIARY_ID",
      "CREATION_DATE"
    FROM "U_PRJ_ECOM".DIM_CUSTOMER
  ) AS input_1
    ON input_0."CUSTOMER_ID" = input_1."ID"
    AND input_0."SUBSIDIARY_ID" = input_1."SUBSIDIARY_ID"
  )
     ORDER BY "SUBSIDIARY_ID", "CREATION_DATE"
    SEGMENTED BY HASH("SUBSIDIARY_ID", "CREATION_DATE") ALL NODES
  ;

  -- Node: Join_4
  PERFORM DROP TABLE IF EXISTS "layer_0_Join_4" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Join_4" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."BIRTHDAY",
    input_0."GENDER",
    input_0."NAME",
    input_0."OPT_IN",
    input_0."CUSTOMER_CREATION_DATE",
    input_0."PRODUCT_NAME",
    input_0."REFERENCE_CODE",
    input_0."QUANTITY",
    input_0."EAN",
    input_0."ITEM_DISCOUNT",
    input_0."SHIPPING_ESTIMATE_DATE",
    input_0."CARRIER",
    input_0."PRICE",
    input_0."SHIPPING_COST_ITEM",
    input_0."EXTERNAL_ORDER_ID",
    input_0."SUBSIDIARY_ID",
    input_0."CREATION_DATETIME",
    input_0."STATUS",
    input_0."INTERNAL_STATUS",
    input_0."ORDER_VALUE",
    input_0."DISCOUNT",
    input_0."STATUS_PAYMENT_PENDING_DATE",
    input_0."STATUS_PAYMENT_APPROVED_DATE",
    input_0."STATUS_PAYMENT_DENIED_DATE",
    input_0."STATUS_START_HANDLING_DATE",
    input_0."STATUS_HANDLING_SHIPPING_DATE",
    input_0."STATUS_INVOICED_DATE",
    input_0."STATUS_DELIVERED_DATE",
    input_0."STATUS_CANCELED_DATE",
    input_0."CANCELLATION_REASON",
    input_0."COMPLETE",
    input_0."ACQUIRER_MESSAGE",
    input_0."SHIPPING_COST",
    input_0."VENDOR",
    input_0."INVOICE_NUMBER",
    input_0."HOSTNAME",
    input_0."SELLER_ID",
    input_0."SELLER_NAME",
    input_0."MKT_UTM_COUPON",
    input_0."MKT_UTM_CAMPAIGN",
    input_0."MKT_UTM_MEDIUM",
    input_0."MKT_UTM_PARTNER",
    input_0."MKT_UTM_SRC",
    input_0."SUBSIDIARY",
    input_0."CREATION_DATE",
    input_0."ID",
    input_0."MKT_CAMPAIGN_TAGS",
    input_0."TRADE_POLICY",
    input_0."COUNTRY",
    input_0."ADDRESS_STATE",
    input_0."CITY",
    input_0."SELLER_ORDER_ID",
    input_0."MKT_UTMI_CAMPAIGN",
    input_0."MKT_UTMI_PAGE",
    input_0."MKT_UTMI_PART",
    input_0."Channel",
    input_0."LAST_UPDATE_DATE",
    input_0."INSERT_DATE",
    input_0."AFFILIATE_ID",
    input_0."SOURCE",
    input_0."SELLER_INSTANCE_ID",
    input_0."COD_SALES_CHANNEL",
    input_0."CUSTOMER_ID",
    input_0."IS_SAMSUNG_CARE",
    input_0."IS_TRADE_IN",
    input_0."ORDER_SEQUENCE",
    input_0."ADDRESS_TYPE",
    input_1."REFERENCE_DATE",
    input_1."VALUE",
    input_1."REFERENCE_CURRENCY"
  FROM "layer_0_Join_3" AS input_0
  INNER JOIN (
    SELECT
      "SUBSIDIARY_ID",
      "REFERENCE_CURRENCY",
      "REFERENCE_DATE",
      "VALUE"
    FROM "U_PRJ_ECOM".DIM_EXCHANGE_RATE_RAWDATA
  ) AS input_1
    ON input_0."SUBSIDIARY_ID" = input_1."SUBSIDIARY_ID"
    AND input_0."CREATION_DATE" = CAST(input_1."REFERENCE_DATE" AS DATE)
  )
     ORDER BY "REFERENCE_CODE"
    SEGMENTED BY HASH("REFERENCE_CODE") ALL NODES
  ;

  -- Node: Join_5
  PERFORM DROP TABLE IF EXISTS "layer_0_Join_5" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Join_5" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."BIRTHDAY",
    input_0."GENDER",
    input_0."NAME",
    input_0."OPT_IN",
    input_0."CUSTOMER_CREATION_DATE",
    input_0."PRODUCT_NAME",
    input_0."REFERENCE_CODE",
    input_0."QUANTITY",
    input_0."EAN",
    input_0."ITEM_DISCOUNT",
    input_0."SHIPPING_ESTIMATE_DATE",
    input_0."CARRIER",
    input_0."PRICE",
    input_0."SHIPPING_COST_ITEM",
    input_0."EXTERNAL_ORDER_ID",
    input_0."SUBSIDIARY_ID",
    input_0."CREATION_DATETIME",
    input_0."STATUS",
    input_0."INTERNAL_STATUS",
    input_0."ORDER_VALUE",
    input_0."DISCOUNT",
    input_0."STATUS_PAYMENT_PENDING_DATE",
    input_0."STATUS_PAYMENT_APPROVED_DATE",
    input_0."STATUS_PAYMENT_DENIED_DATE",
    input_0."STATUS_START_HANDLING_DATE",
    input_0."STATUS_HANDLING_SHIPPING_DATE",
    input_0."STATUS_INVOICED_DATE",
    input_0."STATUS_DELIVERED_DATE",
    input_0."STATUS_CANCELED_DATE",
    input_0."CANCELLATION_REASON",
    input_0."COMPLETE",
    input_0."ACQUIRER_MESSAGE",
    input_0."SHIPPING_COST",
    input_0."VENDOR",
    input_0."INVOICE_NUMBER",
    input_0."HOSTNAME",
    input_0."SELLER_ID",
    input_0."SELLER_NAME",
    input_0."MKT_UTM_COUPON",
    input_0."MKT_UTM_CAMPAIGN",
    input_0."MKT_UTM_MEDIUM",
    input_0."MKT_UTM_PARTNER",
    input_0."MKT_UTM_SRC",
    input_0."SUBSIDIARY",
    input_0."CREATION_DATE",
    input_0."ID",
    input_0."MKT_CAMPAIGN_TAGS",
    input_0."TRADE_POLICY",
    input_0."COUNTRY",
    input_0."ADDRESS_STATE",
    input_0."CITY",
    input_0."SELLER_ORDER_ID",
    input_0."MKT_UTMI_CAMPAIGN",
    input_0."MKT_UTMI_PAGE",
    input_0."MKT_UTMI_PART",
    input_0."Channel",
    input_0."LAST_UPDATE_DATE",
    input_0."INSERT_DATE",
    input_0."AFFILIATE_ID",
    input_0."SOURCE",
    input_0."SELLER_INSTANCE_ID",
    input_0."COD_SALES_CHANNEL",
    input_0."CUSTOMER_ID",
    input_0."IS_SAMSUNG_CARE",
    input_0."IS_TRADE_IN",
    input_0."ORDER_SEQUENCE",
    input_0."ADDRESS_TYPE",
    input_0."REFERENCE_DATE",
    input_0."VALUE",
    input_0."REFERENCE_CURRENCY",
    input_1."MARKET_NAME",
    input_1."CATEGORY",
    input_1."PRODUCT_GROUP",
    input_1."SKU",
    input_1."DIVISION",
    input_1."FLAGSHIP",
    input_1."FAMILY_GROUP"
  FROM "layer_0_Join_4" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "MARKET_NAME",
      "CATEGORY",
      "PRODUCT_GROUP",
      "SKU",
      "DIVISION",
      "FLAGSHIP",
      "FAMILY_GROUP"
    FROM "U_PRJ_ECOM".DIM_PRODUCT_CATEGORY
  ) AS input_1
    ON input_0."REFERENCE_CODE" = input_1."SKU"
  )
     ORDER BY "REFERENCE_CODE", "SUBSIDIARY_ID"
    SEGMENTED BY HASH("REFERENCE_CODE", "SUBSIDIARY_ID") ALL NODES
  ;

  -- Node: Join_6
  PERFORM DROP TABLE IF EXISTS "layer_0_Join_6" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Join_6" ON COMMIT PRESERVE ROWS
  AS (
  SELECT
    input_0."MARKET_NAME",
    input_0."CATEGORY",
    input_0."PRODUCT_GROUP",
    input_0."SKU",
    input_0."DIVISION",
    input_0."BIRTHDAY",
    input_0."GENDER",
    input_0."NAME",
    input_0."OPT_IN",
    input_0."CUSTOMER_CREATION_DATE",
    input_0."PRODUCT_NAME",
    input_0."REFERENCE_CODE",
    input_0."QUANTITY",
    input_0."EAN",
    input_0."ITEM_DISCOUNT",
    input_0."SHIPPING_ESTIMATE_DATE",
    input_0."CARRIER",
    input_0."PRICE",
    input_0."SHIPPING_COST_ITEM",
    input_0."EXTERNAL_ORDER_ID",
    input_0."SUBSIDIARY_ID",
    input_0."CREATION_DATETIME",
    input_0."STATUS",
    input_0."INTERNAL_STATUS",
    input_0."ORDER_VALUE",
    input_0."DISCOUNT",
    input_0."STATUS_PAYMENT_PENDING_DATE",
    input_0."STATUS_PAYMENT_APPROVED_DATE",
    input_0."STATUS_PAYMENT_DENIED_DATE",
    input_0."STATUS_START_HANDLING_DATE",
    input_0."STATUS_HANDLING_SHIPPING_DATE",
    input_0."STATUS_INVOICED_DATE",
    input_0."STATUS_DELIVERED_DATE",
    input_0."STATUS_CANCELED_DATE",
    input_0."CANCELLATION_REASON",
    input_0."COMPLETE",
    input_0."ACQUIRER_MESSAGE",
    input_0."SHIPPING_COST",
    input_0."VENDOR",
    input_0."INVOICE_NUMBER",
    input_0."HOSTNAME",
    input_0."SELLER_ID",
    input_0."SELLER_NAME",
    input_0."MKT_UTM_COUPON",
    input_0."MKT_UTM_CAMPAIGN",
    input_0."MKT_UTM_MEDIUM",
    input_0."MKT_UTM_PARTNER",
    input_0."MKT_UTM_SRC",
    input_0."SUBSIDIARY",
    input_0."CREATION_DATE",
    input_0."ID",
    input_0."FLAGSHIP",
    input_0."MKT_CAMPAIGN_TAGS",
    input_0."TRADE_POLICY",
    input_0."COUNTRY",
    input_0."ADDRESS_STATE",
    input_0."CITY",
    input_0."SELLER_ORDER_ID",
    input_0."MKT_UTMI_CAMPAIGN",
    input_0."MKT_UTMI_PAGE",
    input_0."MKT_UTMI_PART",
    input_0."Channel",
    input_0."LAST_UPDATE_DATE",
    input_0."INSERT_DATE",
    input_0."FAMILY_GROUP",
    input_0."AFFILIATE_ID",
    input_0."SOURCE",
    input_0."SELLER_INSTANCE_ID",
    input_0."COD_SALES_CHANNEL",
    input_0."CUSTOMER_ID",
    input_0."ADDRESS_TYPE",
    input_0."ORDER_SEQUENCE",
    input_0."IS_TRADE_IN",
    input_0."IS_SAMSUNG_CARE",
    input_0."REFERENCE_DATE",
    input_0."VALUE",
    input_0."REFERENCE_CURRENCY",
    input_1."ACTIVE",
    input_1."IS_KIT"
  FROM "layer_0_Join_5" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "REFERENCE_CODE",
      "ACTIVE",
      "IS_KIT",
      "SKU_ORIGIN",
      "SUBSIDIARY_ID"
    FROM "U_PRJ_ECOM".DIM_ECOM_SKU
  ) AS input_1
    ON input_0."REFERENCE_CODE" = input_1."REFERENCE_CODE"
    AND input_0."SUBSIDIARY_ID" = input_1."SUBSIDIARY_ID"
  )
     ORDER BY "ID"
    SEGMENTED BY HASH("ID") ALL NODES
  ;

  -- Node: Join_7
  PERFORM DROP TABLE IF EXISTS "layer_0_Join_7" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Join_7" ON COMMIT PRESERVE ROWS AS 
  SELECT
    input_0."MARKET_NAME",
    input_0."CATEGORY",
    input_0."PRODUCT_GROUP",
    input_0."SKU",
    input_0."DIVISION",
    input_0."BIRTHDAY",
    input_0."GENDER",
    input_0."NAME",
    input_0."OPT_IN",
    input_0."CUSTOMER_CREATION_DATE",
    input_0."PRODUCT_NAME",
    input_0."REFERENCE_CODE",
    input_0."QUANTITY",
    input_0."EAN",
    input_0."ITEM_DISCOUNT",
    input_0."SHIPPING_ESTIMATE_DATE",
    input_0."CARRIER",
    input_0."PRICE",
    input_0."SHIPPING_COST_ITEM",
    input_0."EXTERNAL_ORDER_ID",
    input_0."SUBSIDIARY_ID",
    input_0."CREATION_DATETIME",
    input_0."STATUS",
    input_0."INTERNAL_STATUS",
    input_0."ORDER_VALUE",
    input_0."DISCOUNT",
    input_0."STATUS_PAYMENT_PENDING_DATE",
    input_0."STATUS_PAYMENT_APPROVED_DATE",
    input_0."STATUS_PAYMENT_DENIED_DATE",
    input_0."STATUS_START_HANDLING_DATE",
    input_0."STATUS_HANDLING_SHIPPING_DATE",
    input_0."STATUS_INVOICED_DATE",
    input_0."STATUS_DELIVERED_DATE",
    input_0."STATUS_CANCELED_DATE",
    input_0."CANCELLATION_REASON",
    input_0."COMPLETE",
    input_0."ACQUIRER_MESSAGE",
    input_0."SHIPPING_COST",
    input_0."VENDOR",
    input_0."INVOICE_NUMBER",
    input_0."HOSTNAME",
    input_0."SELLER_ID",
    input_0."SELLER_NAME",
    input_0."MKT_UTM_COUPON",
    input_0."MKT_UTM_CAMPAIGN",
    input_0."MKT_UTM_MEDIUM",
    input_0."MKT_UTM_PARTNER",
    input_0."MKT_UTM_SRC",
    input_0."SUBSIDIARY",
    input_0."CREATION_DATE",
    input_0."ID",
    input_0."FLAGSHIP",
    input_0."MKT_CAMPAIGN_TAGS",
    input_0."TRADE_POLICY",
    input_0."COUNTRY",
    input_0."ADDRESS_STATE",
    input_0."CITY",
    input_0."SELLER_ORDER_ID",
    input_0."MKT_UTMI_CAMPAIGN",
    input_0."MKT_UTMI_PAGE",
    input_0."MKT_UTMI_PART",
    input_0."ACTIVE",
    input_0."IS_KIT",
    input_0."Channel",
    input_0."LAST_UPDATE_DATE",
    input_0."INSERT_DATE",
    input_0."FAMILY_GROUP",
    input_0."AFFILIATE_ID",
    input_0."SOURCE",
    input_0."SELLER_INSTANCE_ID",
    input_0."COD_SALES_CHANNEL",
    input_0."CUSTOMER_ID",
    input_0."ADDRESS_TYPE",
    input_0."ORDER_SEQUENCE",
    input_0."IS_TRADE_IN",
    input_0."IS_SAMSUNG_CARE",
    input_0."REFERENCE_DATE",
    input_0."VALUE",
    input_0."REFERENCE_CURRENCY",
    input_1."BRAND",
    input_1."PAYMENT_TYPE",
    input_1."PAYMENT_VALUE_LOCAL",
    input_1."PAYMENT_ID",
    input_1."INSTALLMENT",
    input_1."ACQUIRER"
  FROM "layer_0_Join_6" AS input_0
  LEFT OUTER JOIN (
    SELECT
      "PAYMENT_TYPE",
      "BRAND",
      "ID",
      "ORDER_ID",
      "VALUE" AS "PAYMENT_VALUE_LOCAL",
      "PAYMENT_ID",
      "INSTALLMENT",
      "ACQUIRER"
    FROM "U_PRJ_ECOM".FT_ECOM_ORDER_PAYMENT
  ) AS input_1
    ON input_0."ID" = input_1."ORDER_ID"
  ;

  -- Node: Projection
  PERFORM DROP TABLE IF EXISTS "layer_0_Projection" CASCADE;
  PERFORM CREATE LOCAL TEMPORARY TABLE "layer_0_Projection" ON COMMIT PRESERVE ROWS AS 
  SELECT
    "MARKET_NAME" AS "Market_Name",
    "CATEGORY" AS "Category",
    "PRODUCT_GROUP" AS "Product_Group",
    "SKU" AS "Sku",
    "DIVISION" AS "Division",
    "BIRTHDAY" AS "Birthday",
    "GENDER" AS "Gender",
    "NAME" AS "Name",
    "OPT_IN" AS "Opt_In",
    "CUSTOMER_CREATION_DATE" AS "Customer_Creation_Date",
    "PRODUCT_NAME" AS "Product_Name",
    "REFERENCE_CODE" AS "Reference_Code",
    "QUANTITY" AS "Units",
    "EAN",
    "ITEM_DISCOUNT" AS "Item_Discount",
    "SHIPPING_ESTIMATE_DATE" AS "Shipping_Estimate_Date",
    "CARRIER" AS "Carrier",
    "PRICE" AS "Price",
    "SHIPPING_COST_ITEM" AS "Shipping_Cost_Item",
    "EXTERNAL_ORDER_ID" AS "Order_Id",
    "SUBSIDIARY_ID" AS "Subsidiary_Id",
    "CREATION_DATETIME" AS "Creation_Datetime",
    "STATUS" AS "Status",
    "INTERNAL_STATUS" AS "Internal_Status",
    "ORDER_VALUE" AS "Order_Value",
    "DISCOUNT" AS "Discount",
    "STATUS_PAYMENT_PENDING_DATE" AS "Status_Payment_Pending_Date",
    "STATUS_PAYMENT_APPROVED_DATE" AS "Status_Payment_Approved_Date",
    "STATUS_PAYMENT_DENIED_DATE" AS "Status_Payment_Denied_Date",
    "STATUS_START_HANDLING_DATE" AS "Status_Start_Handling_Date",
    "STATUS_HANDLING_SHIPPING_DATE" AS "Status_Handling_Shipping_Date",
    "STATUS_INVOICED_DATE" AS "Status_Invoiced_Date",
    "STATUS_DELIVERED_DATE" AS "Status_Delivered_Date",
    "STATUS_CANCELED_DATE" AS "Status_Canceled_Date",
    "CANCELLATION_REASON" AS "Cancellation_Reason",
    "COMPLETE" AS "Complete",
    "ACQUIRER_MESSAGE" AS "Acquirer_Message",
    "SHIPPING_COST" AS "Shipping_Cost",
    "VENDOR" AS "Vendor",
    "INVOICE_NUMBER" AS "Invoice_Number",
    "HOSTNAME" AS "Hostname",
    "SELLER_ID" AS "Seller_Id",
    "SELLER_NAME" AS "Seller_Name",
    "MKT_UTM_COUPON" AS "Mkt_Utm_Coupon",
    "MKT_UTM_CAMPAIGN" AS "Mkt_Utm_Campaign",
    "MKT_UTM_MEDIUM" AS "Mkt_Utm_Medium",
    "MKT_UTM_PARTNER" AS "Mkt_Utm_Partner",
    "MKT_UTM_SRC" AS "Mkt_Utm_Src",
    "SUBSIDIARY" AS "Subsidiary",
    "CREATION_DATE" AS "Creation_Date",
    "ID",
    "FLAGSHIP" AS "Flagship",
    "MKT_CAMPAIGN_TAGS" AS "Mkt_Campaign_Tags",
    "TRADE_POLICY" AS "Trade_Policy",
    "COUNTRY" AS "Country",
    "ADDRESS_STATE" AS "Address_State",
    "CITY" AS "City",
    "SELLER_ORDER_ID" AS "Seller_Order_Id",
    "MKT_UTMI_CAMPAIGN" AS "Mkt_Utmi_Campaign",
    "MKT_UTMI_PAGE" AS "Mkt_Utmi_Page",
    "MKT_UTMI_PART" AS "Mkt_Utmi_Part",
    "ACTIVE" AS "Active",
    "IS_KIT" AS "Is_Kit",
    "Channel",
    "LAST_UPDATE_DATE" AS "Last_Update_Date",
    "INSERT_DATE" AS "Insert_Date",
    "FAMILY_GROUP" AS "Family_Group",
    "BRAND" AS "Brand",
    "PAYMENT_TYPE" AS "Payment_Type",
    "PAYMENT_VALUE_LOCAL" AS "Payment_Value_Local",
    "PAYMENT_ID" AS "Payment_Id",
    "AFFILIATE_ID",
    "SOURCE",
    "SELLER_INSTANCE_ID",
    "COD_SALES_CHANNEL",
    "CUSTOMER_ID",
    "INSTALLMENT",
    "ACQUIRER",
    "ADDRESS_TYPE",
    "ORDER_SEQUENCE",
    "IS_TRADE_IN",
    "IS_SAMSUNG_CARE",
    "REFERENCE_DATE",
    "VALUE" AS "Tax_Converter",
    "REFERENCE_CURRENCY",
    (
      (
        "Units" * "Price"
      ) - "Item_Discount"
    ) + "Shipping_Cost" AS "Total_Item",
    (
      (
        (
          "Units" * "Price"
        ) - "Item_Discount"
      ) + "Shipping_Cost"
    ) / "Tax_Converter" AS "Total_Item_USD"
  FROM "layer_0_Join_7"
  ;

  -- Materialize final result
  PERFORM CREATE TABLE IF NOT EXISTS OW_SEDA_S.VIEWCV_CV_PAYMENT_RAW_DATA_SAMSUNGBR_V2 AS
    SELECT * FROM "layer_0_Projection" WHERE 1=0;
  PERFORM TRUNCATE TABLE OW_SEDA_S.VIEWCV_CV_PAYMENT_RAW_DATA_SAMSUNGBR_V2;
  PERFORM INSERT INTO OW_SEDA_S.VIEWCV_CV_PAYMENT_RAW_DATA_SAMSUNGBR_V2
  SELECT * FROM "layer_0_Projection";

  PERFORM COMMIT;
  RAISE NOTICE 'Successfully loaded OW_SEDA_S.VIEWCV_CV_PAYMENT_RAW_DATA_SAMSUNGBR_V2';

END;
$$;