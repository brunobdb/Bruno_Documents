CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_CV_ECOM_ORDERS_CUSTOMERS_PRODUCTS_TEST" AS
SELECT
  "ID",
  "EXTERNAL_ORDER_ID" AS "Order_Id",
  "SUBSIDIARY_ID" AS "Subsidiary_Id",
  "CREATION_DATETIME" AS "Creation_Datetime",
  "CREATION_DATE" AS "Creation_Date",
  "STATUS" AS "Status",
  "INTERNAL_STATUS" AS "Internal_Status",
  "ORDER_VALUE" AS "Order_Value",
  "DISCOUNT" AS "Discount",
  "STATUS_PAYMENT_PENDING_DATE" AS "Status_Payment_Pending_Date",
  "STATUS_PAYMENT_APPROVED_DATE" AS "Status_Payment_Approved_Date",
  "STATUS_PAYMENT_DENIED_DATE" AS "Status_Payment_Denied_Date",
  "STATUS_START_HANDLING_DATE" AS "Status_Start_Handling_Date",
  "STATUS_HANDLING_SHIPPING_DATE" AS "Status_Handling_Shipping_Date",
  "STATUS_INVOICED_DATE" AS "Status_Invoiced_Date",
  "STATUS_DELIVERED_DATE" AS "Status_Delivered_Date",
  "STATUS_CANCELED_DATE" AS "Status_Canceled_Date",
  "CANCELLATION_REASON" AS "Cancellation_Reason",
  "COMPLETE" AS "Complete",
  "ACQUIRER_MESSAGE" AS "Acquirer_Message",
  "SHIPPING_COST" AS "Shipping_Cost",
  "VENDOR" AS "Vendor",
  "INVOICE_NUMBER" AS "Invoice_Number",
  "HOSTNAME" AS "Hostname",
  "MKT_UTM_SRC" AS "Mkt_Utm_Src",
  "MKT_UTM_PARTNER" AS "Mkt_Utm_Partner",
  "MKT_UTM_MEDIUM" AS "Mkt_Utm_Medium",
  "MKT_UTM_CAMPAIGN" AS "Mkt_Utm_Campaign",
  "MKT_UTM_COUPON" AS "Mkt_Utm_Coupon",
  "MKT_UTMI_PART" AS "Mkt_Utmi_Part",
  "MKT_UTMI_PAGE" AS "Mkt_Utmi_Page",
  "MKT_UTMI_CAMPAIGN" AS "Mkt_Utmi_Campaign",
  "SELLER_NAME" AS "Seller_Name",
  "SELLER_ID" AS "Seller_Id",
  "MKT_CAMPAIGN_TAGS" AS "Mkt_Campaign_Tags",
  "Channel",
  "TRADE_POLICY" AS "Trade_Policy",
  "SELLER_ORDER_ID" AS "Seller_Order_Id",
  "REFERENCE_DATE" AS "Reference_Date",
  "REFERENCE_CURRENCY" AS "Reference_Currency",
  "VALUE" AS "Tax_Converter",
  "PRODUCT_NAME" AS "Product_Name",
  "REFERENCE_CODE" AS "Reference_Code",
  "QUANTITY" AS "Units",
  "EAN",
  "ITEM_DISCOUNT" AS "Item_Discount",
  "SHIPPING_ESTIMATE_DATE" AS "Shipping_Estimate_Date",
  "CARRIER" AS "Carrier",
  "PRICE" AS "Price",
  "SHIPPING_COST_ITEM" AS "Shipping_Cost_Item",
  "ACTIVE" AS "Active",
  "IS_KIT" AS "Is_Kit",
  "SUBSIDIARY" AS "Subsidiary",
  "SKU" AS "Sku",
  "DIVISION" AS "Division",
  "FAMILY_GROUP" AS "Family_Group",
  "PRODUCT_GROUP" AS "Product_Group",
  "CATEGORY" AS "Category",
  "MARKET_NAME" AS "Market_Name",
  "FLAGSHIP" AS "Flagship",
  "BIRTHDAY" AS "Birthday",
  "GENDER" AS "Gender",
  "NAME" AS "Name",
  "OPT_IN" AS "Opt_In",
  "CUSTOMER_CREATION_DATE" AS "Customer_Creation_Date",
  "COUNTRY" AS "Country",
  "ADDRESS_STATE" AS "Address_State",
  "CITY" AS "City",
  "LAST_UPDATE_DATE" AS "Last_Update_Date",
  "INSERT_DATE" AS "Insert_Date",
  (
    (
      "Units" * "Price"
    ) - "Item_Discount"
  ) + "Shipping_Cost_Item" AS "Total_Item",
  (
    (
      (
        "Units" * "Price"
      ) - "Item_Discount"
    ) + "Shipping_Cost_Item"
  ) * "Tax_Converter" AS "Total_Item_USD"
FROM (
  SELECT
    input_0."MARKET_NAME",
    input_0."CATEGORY",
    input_0."PRODUCT_GROUP",
    input_0."SKU",
    input_0."DIVISION",
    input_0."VALUE",
    input_0."REFERENCE_DATE",
    input_0."REFERENCE_CURRENCY",
    input_0."BIRTHDAY",
    input_0."GENDER",
    input_0."NAME",
    input_0."OPT_IN",
    input_0."CUSTOMER_CREATION_DATE",
    input_0."PRODUCT_NAME",
    input_0."REFERENCE_CODE",
    input_0."QUANTITY",
    input_0."EAN",
    input_0."ITEM_DISCOUNT",
    input_0."SHIPPING_ESTIMATE_DATE",
    input_0."CARRIER",
    input_0."PRICE",
    input_0."SHIPPING_COST_ITEM",
    input_0."EXTERNAL_ORDER_ID",
    input_0."SUBSIDIARY_ID",
    input_0."CREATION_DATETIME",
    input_0."STATUS",
    input_0."INTERNAL_STATUS",
    input_0."ORDER_VALUE",
    input_0."DISCOUNT",
    input_0."STATUS_PAYMENT_PENDING_DATE",
    input_0."STATUS_PAYMENT_APPROVED_DATE",
    input_0."STATUS_PAYMENT_DENIED_DATE",
    input_0."STATUS_START_HANDLING_DATE",
    input_0."STATUS_HANDLING_SHIPPING_DATE",
    input_0."STATUS_INVOICED_DATE",
    input_0."STATUS_DELIVERED_DATE",
    input_0."STATUS_CANCELED_DATE",
    input_0."CANCELLATION_REASON",
    input_0."COMPLETE",
    input_0."ACQUIRER_MESSAGE",
    input_0."SHIPPING_COST",
    input_0."VENDOR",
    input_0."INVOICE_NUMBER",
    input_0."HOSTNAME",
    input_0."SELLER_ID",
    input_0."SELLER_NAME",
    input_0."MKT_UTM_COUPON",
    input_0."MKT_UTM_CAMPAIGN",
    input_0."MKT_UTM_MEDIUM",
    input_0."MKT_UTM_PARTNER",
    input_0."MKT_UTM_SRC",
    input_0."SUBSIDIARY",
    input_0."CREATION_DATE",
    input_0."ID",
    input_0."FLAGSHIP",
    input_0."MKT_CAMPAIGN_TAGS",
    input_0."TRADE_POLICY",
    input_0."COUNTRY",
    input_0."ADDRESS_STATE",
    input_0."CITY",
    input_0."SELLER_ORDER_ID",
    input_0."MKT_UTMI_CAMPAIGN",
    input_0."MKT_UTMI_PAGE",
    input_0."MKT_UTMI_PART",
    input_0."Channel",
    input_0."LAST_UPDATE_DATE",
    input_0."INSERT_DATE",
    input_0."FAMILY_GROUP",
    input_1."ACTIVE",
    input_1."IS_KIT"
  FROM (
    SELECT
      input_0."VALUE",
      input_0."REFERENCE_DATE",
      input_0."REFERENCE_CURRENCY",
      input_0."BIRTHDAY",
      input_0."GENDER",
      input_0."NAME",
      input_0."OPT_IN",
      input_0."CUSTOMER_CREATION_DATE",
      input_0."PRODUCT_NAME",
      input_0."REFERENCE_CODE",
      input_0."QUANTITY",
      input_0."EAN",
      input_0."ITEM_DISCOUNT",
      input_0."SHIPPING_ESTIMATE_DATE",
      input_0."CARRIER",
      input_0."PRICE",
      input_0."SHIPPING_COST_ITEM",
      input_0."EXTERNAL_ORDER_ID",
      input_0."SUBSIDIARY_ID",
      input_0."CREATION_DATETIME",
      input_0."STATUS",
      input_0."INTERNAL_STATUS",
      input_0."ORDER_VALUE",
      input_0."DISCOUNT",
      input_0."STATUS_PAYMENT_PENDING_DATE",
      input_0."STATUS_PAYMENT_APPROVED_DATE",
      input_0."STATUS_PAYMENT_DENIED_DATE",
      input_0."STATUS_START_HANDLING_DATE",
      input_0."STATUS_HANDLING_SHIPPING_DATE",
      input_0."STATUS_INVOICED_DATE",
      input_0."STATUS_DELIVERED_DATE",
      input_0."STATUS_CANCELED_DATE",
      input_0."CANCELLATION_REASON",
      input_0."COMPLETE",
      input_0."ACQUIRER_MESSAGE",
      input_0."SHIPPING_COST",
      input_0."VENDOR",
      input_0."INVOICE_NUMBER",
      input_0."HOSTNAME",
      input_0."SELLER_ID",
      input_0."SELLER_NAME",
      input_0."MKT_UTM_COUPON",
      input_0."MKT_UTM_CAMPAIGN",
      input_0."MKT_UTM_MEDIUM",
      input_0."MKT_UTM_PARTNER",
      input_0."MKT_UTM_SRC",
      input_0."SUBSIDIARY",
      input_0."CREATION_DATE",
      input_0."ID",
      input_0."MKT_CAMPAIGN_TAGS",
      input_0."TRADE_POLICY",
      input_0."COUNTRY",
      input_0."ADDRESS_STATE",
      input_0."CITY",
      input_0."SELLER_ORDER_ID",
      input_0."MKT_UTMI_CAMPAIGN",
      input_0."MKT_UTMI_PAGE",
      input_0."MKT_UTMI_PART",
      input_0."Channel",
      input_0."LAST_UPDATE_DATE",
      input_0."INSERT_DATE",
      input_1."MARKET_NAME",
      input_1."CATEGORY",
      input_1."PRODUCT_GROUP",
      input_1."SKU",
      input_1."DIVISION",
      input_1."FLAGSHIP",
      input_1."FAMILY_GROUP"
    FROM (
      SELECT
        input_0."BIRTHDAY",
        input_0."GENDER",
        input_0."NAME",
        input_0."OPT_IN",
        input_0."CUSTOMER_CREATION_DATE",
        input_0."PRODUCT_NAME",
        input_0."REFERENCE_CODE",
        input_0."QUANTITY",
        input_0."EAN",
        input_0."ITEM_DISCOUNT",
        input_0."SHIPPING_ESTIMATE_DATE",
        input_0."CARRIER",
        input_0."PRICE",
        input_0."SHIPPING_COST_ITEM",
        input_0."EXTERNAL_ORDER_ID",
        input_0."SUBSIDIARY_ID",
        input_0."CREATION_DATETIME",
        input_0."STATUS",
        input_0."INTERNAL_STATUS",
        input_0."ORDER_VALUE",
        input_0."DISCOUNT",
        input_0."STATUS_PAYMENT_PENDING_DATE",
        input_0."STATUS_PAYMENT_APPROVED_DATE",
        input_0."STATUS_PAYMENT_DENIED_DATE",
        input_0."STATUS_START_HANDLING_DATE",
        input_0."STATUS_HANDLING_SHIPPING_DATE",
        input_0."STATUS_INVOICED_DATE",
        input_0."STATUS_DELIVERED_DATE",
        input_0."STATUS_CANCELED_DATE",
        input_0."CANCELLATION_REASON",
        input_0."COMPLETE",
        input_0."ACQUIRER_MESSAGE",
        input_0."SHIPPING_COST",
        input_0."VENDOR",
        input_0."INVOICE_NUMBER",
        input_0."HOSTNAME",
        input_0."SELLER_ID",
        input_0."SELLER_NAME",
        input_0."MKT_UTM_COUPON",
        input_0."MKT_UTM_CAMPAIGN",
        input_0."MKT_UTM_MEDIUM",
        input_0."MKT_UTM_PARTNER",
        input_0."MKT_UTM_SRC",
        input_0."SUBSIDIARY",
        input_0."CREATION_DATE",
        input_0."ID",
        input_0."MKT_CAMPAIGN_TAGS",
        input_0."TRADE_POLICY",
        input_0."COUNTRY",
        input_0."ADDRESS_STATE",
        input_0."CITY",
        input_0."SELLER_ORDER_ID",
        input_0."MKT_UTMI_CAMPAIGN",
        input_0."MKT_UTMI_PAGE",
        input_0."MKT_UTMI_PART",
        input_0."Channel",
        input_0."LAST_UPDATE_DATE",
        input_0."INSERT_DATE",
        input_1."VALUE",
        input_1."REFERENCE_DATE",
        input_1."REFERENCE_CURRENCY"
      FROM (
        SELECT
          input_0."PRODUCT_NAME",
          input_0."REFERENCE_CODE",
          input_0."QUANTITY",
          input_0."EAN",
          input_0."ITEM_DISCOUNT",
          input_0."SHIPPING_ESTIMATE_DATE",
          input_0."CARRIER",
          input_0."PRICE",
          input_0."SHIPPING_COST_ITEM",
          input_0."EXTERNAL_ORDER_ID",
          input_0."SUBSIDIARY_ID",
          input_0."CREATION_DATE" AS "CREATION_DATETIME",
          input_0."STATUS",
          input_0."INTERNAL_STATUS",
          input_0."ORDER_VALUE",
          input_0."DISCOUNT",
          input_0."STATUS_PAYMENT_PENDING_DATE",
          input_0."STATUS_PAYMENT_APPROVED_DATE",
          input_0."STATUS_PAYMENT_DENIED_DATE",
          input_0."STATUS_START_HANDLING_DATE",
          input_0."STATUS_HANDLING_SHIPPING_DATE",
          input_0."STATUS_INVOICED_DATE",
          input_0."STATUS_DELIVERED_DATE",
          input_0."STATUS_CANCELED_DATE",
          input_0."CANCELLATION_REASON",
          input_0."COMPLETE",
          input_0."ACQUIRER_MESSAGE",
          input_0."SHIPPING_COST",
          input_0."VENDOR",
          input_0."INVOICE_NUMBER",
          input_0."HOSTNAME",
          input_0."SELLER_ID",
          input_0."SELLER_NAME",
          input_0."MKT_UTM_COUPON",
          input_0."MKT_UTM_CAMPAIGN",
          input_0."MKT_UTM_MEDIUM",
          input_0."MKT_UTM_PARTNER",
          input_0."MKT_UTM_SRC",
          input_0."SUBSIDIARY",
          input_0."ID",
          input_0."MKT_CAMPAIGN_TAGS",
          input_0."TRADE_POLICY",
          input_0."COUNTRY",
          input_0."ADDRESS_STATE",
          input_0."CITY",
          input_0."SELLER_ORDER_ID",
          input_0."MKT_UTMI_CAMPAIGN",
          input_0."MKT_UTMI_PAGE",
          input_0."MKT_UTMI_PART",
          input_0."Channel",
          input_0."LAST_UPDATE_DATE",
          input_0."INSERT_DATE",
          input_1."BIRTHDAY",
          input_1."GENDER",
          input_1."NAME",
          input_1."OPT_IN",
          input_1."CREATION_DATE" AS "CUSTOMER_CREATION_DATE",
          TO_DATE(("CREATION_DATETIME")::VARCHAR, 'YYYY-MM-DD') AS "CREATION_DATE"
        FROM (
          SELECT
            input_0."PRODUCT_NAME",
            input_0."REFERENCE_CODE",
            input_0."QUANTITY",
            input_0."EAN",
            input_0."ITEM_DISCOUNT",
            input_0."SHIPPING_ESTIMATE_DATE",
            input_0."CARRIER",
            input_0."PRICE",
            input_0."SHIPPING_COST_ITEM",
            input_0."EXTERNAL_ORDER_ID",
            input_0."SUBSIDIARY_ID",
            input_0."CREATION_DATE",
            input_0."STATUS",
            input_0."INTERNAL_STATUS",
            input_0."ORDER_VALUE",
            input_0."CUSTOMER_ID",
            input_0."DISCOUNT",
            input_0."STATUS_PAYMENT_PENDING_DATE",
            input_0."STATUS_PAYMENT_APPROVED_DATE",
            input_0."STATUS_PAYMENT_DENIED_DATE",
            input_0."STATUS_START_HANDLING_DATE",
            input_0."STATUS_HANDLING_SHIPPING_DATE",
            input_0."STATUS_INVOICED_DATE",
            input_0."STATUS_DELIVERED_DATE",
            input_0."STATUS_CANCELED_DATE",
            input_0."CANCELLATION_REASON",
            input_0."COMPLETE",
            input_0."ACQUIRER_MESSAGE",
            input_0."SHIPPING_COST",
            input_0."VENDOR",
            input_0."INVOICE_NUMBER",
            input_0."HOSTNAME",
            input_0."SELLER_ID",
            input_0."SELLER_NAME",
            input_0."MKT_UTM_COUPON",
            input_0."MKT_UTM_CAMPAIGN",
            input_0."MKT_UTM_MEDIUM",
            input_0."MKT_UTM_PARTNER",
            input_0."MKT_UTM_SRC",
            input_0."ID",
            input_0."MKT_CAMPAIGN_TAGS",
            input_0."TRADE_POLICY",
            input_0."MKT_UTMI_PART",
            input_0."MKT_UTMI_PAGE",
            input_0."MKT_UTMI_CAMPAIGN",
            input_0."SELLER_ORDER_ID",
            input_0."CITY",
            input_0."ADDRESS_STATE",
            input_0."COUNTRY",
            input_0."Channel",
            input_0."LAST_UPDATE_DATE",
            input_0."INSERT_DATE",
            input_1."SUBSIDIARY"
          FROM (
            SELECT
              input_0."ID",
              input_0."EXTERNAL_ORDER_ID",
              input_0."SUBSIDIARY_ID",
              input_0."CREATION_DATE",
              input_0."STATUS",
              input_0."INTERNAL_STATUS",
              input_0."ORDER_VALUE",
              input_0."CUSTOMER_ID",
              input_0."DISCOUNT",
              input_0."STATUS_PAYMENT_PENDING_DATE",
              input_0."STATUS_PAYMENT_APPROVED_DATE",
              input_0."STATUS_PAYMENT_DENIED_DATE",
              input_0."STATUS_START_HANDLING_DATE",
              input_0."STATUS_HANDLING_SHIPPING_DATE",
              input_0."STATUS_INVOICED_DATE",
              input_0."STATUS_DELIVERED_DATE",
              input_0."STATUS_CANCELED_DATE",
              input_0."CANCELLATION_REASON",
              input_0."COMPLETE",
              input_0."ACQUIRER_MESSAGE",
              input_0."SHIPPING_COST",
              input_0."VENDOR",
              input_0."INVOICE_NUMBER",
              input_0."HOSTNAME",
              input_0."SELLER_ID",
              input_0."SELLER_NAME",
              input_0."MKT_UTM_COUPON",
              input_0."MKT_UTM_CAMPAIGN",
              input_0."MKT_UTM_MEDIUM",
              input_0."MKT_UTM_PARTNER",
              input_0."MKT_UTM_SRC",
              input_0."ID" AS "ID_1",
              input_0."EXTERNAL_ORDER_ID" AS "EXTERNAL_ORDER_ID_1",
              input_0."SUBSIDIARY_ID" AS "SUBSIDIARY_ID_1",
              input_0."CREATION_DATE" AS "CREATION_DATE_1",
              input_0."STATUS" AS "STATUS_1",
              input_0."INTERNAL_STATUS" AS "INTERNAL_STATUS_1",
              input_0."ORDER_VALUE" AS "ORDER_VALUE_1",
              input_0."CUSTOMER_ID" AS "CUSTOMER_ID_1",
              input_0."DISCOUNT" AS "DISCOUNT_1",
              input_0."STATUS_PAYMENT_PENDING_DATE" AS "STATUS_PAYMENT_PENDING_DATE_1",
              input_0."STATUS_PAYMENT_APPROVED_DATE" AS "STATUS_PAYMENT_APPROVED_DATE_1",
              input_0."STATUS_PAYMENT_DENIED_DATE" AS "STATUS_PAYMENT_DENIED_DATE_1",
              input_0."STATUS_START_HANDLING_DATE" AS "STATUS_START_HANDLING_DATE_1",
              input_0."STATUS_HANDLING_SHIPPING_DATE" AS "STATUS_HANDLING_SHIPPING_DATE_1",
              input_0."STATUS_INVOICED_DATE" AS "STATUS_INVOICED_DATE_1",
              input_0."STATUS_DELIVERED_DATE" AS "STATUS_DELIVERED_DATE_1",
              input_0."STATUS_CANCELED_DATE" AS "STATUS_CANCELED_DATE_1",
              input_0."CANCELLATION_REASON" AS "CANCELLATION_REASON_1",
              input_0."COMPLETE" AS "COMPLETE_1",
              input_0."ACQUIRER_MESSAGE" AS "ACQUIRER_MESSAGE_1",
              input_0."SHIPPING_COST" AS "SHIPPING_COST_1",
              input_0."VENDOR" AS "VENDOR_1",
              input_0."INVOICE_NUMBER" AS "INVOICE_NUMBER_1",
              input_0."HOSTNAME" AS "HOSTNAME_1",
              input_0."SELLER_ID" AS "SELLER_ID_1",
              input_0."SELLER_NAME" AS "SELLER_NAME_1",
              input_0."MKT_UTM_COUPON" AS "MKT_UTM_COUPON_1",
              input_0."MKT_UTM_CAMPAIGN" AS "MKT_UTM_CAMPAIGN_1",
              input_0."MKT_UTM_MEDIUM" AS "MKT_UTM_MEDIUM_1",
              input_0."MKT_UTM_PARTNER" AS "MKT_UTM_PARTNER_1",
              input_0."MKT_UTM_SRC" AS "MKT_UTM_SRC_1",
              input_0."COUNTRY",
              input_0."ADDRESS_STATE",
              input_0."CITY",
              input_0."SELLER_ORDER_ID",
              input_0."MKT_UTMI_CAMPAIGN",
              input_0."MKT_UTMI_PAGE",
              input_0."MKT_UTMI_PART",
              input_0."TRADE_POLICY",
              input_0."MKT_CAMPAIGN_TAGS",
              input_0."Channel",
              input_0."LAST_UPDATE_DATE",
              input_0."INSERT_DATE",
              input_1."PRODUCT_NAME",
              input_1."REFERENCE_CODE",
              input_1."QUANTITY",
              input_1."EAN",
              input_1."DISCOUNT" AS "ITEM_DISCOUNT",
              input_1."SHIPPING_ESTIMATE_DATE",
              input_1."CARRIER",
              input_1."PRICE",
              input_1."SHIPPING_COST" AS "SHIPPING_COST_ITEM"
            FROM (
              SELECT
                "ID",
                "EXTERNAL_ORDER_ID",
                "SUBSIDIARY_ID",
                "CREATION_DATE",
                "STATUS",
                "INTERNAL_STATUS",
                "ORDER_VALUE",
                "CUSTOMER_ID",
                "DISCOUNT",
                "STATUS_PAYMENT_PENDING_DATE",
                "STATUS_PAYMENT_APPROVED_DATE",
                "STATUS_PAYMENT_DENIED_DATE",
                "STATUS_START_HANDLING_DATE",
                "STATUS_HANDLING_SHIPPING_DATE",
                "STATUS_INVOICED_DATE",
                "STATUS_DELIVERED_DATE",
                "STATUS_CANCELED_DATE",
                "CANCELLATION_REASON",
                "COMPLETE",
                "ACQUIRER_MESSAGE",
                "SHIPPING_COST",
                "VENDOR",
                "INVOICE_NUMBER",
                "HOSTNAME",
                "SELLER_ID",
                "SELLER_NAME",
                "MKT_UTM_COUPON",
                "MKT_UTM_CAMPAIGN",
                "MKT_UTM_MEDIUM",
                "MKT_UTM_PARTNER",
                "MKT_UTM_SRC",
                "COUNTRY",
                "ADDRESS_STATE",
                "CITY",
                "SELLER_ORDER_ID",
                "MKT_UTMI_CAMPAIGN",
                "MKT_UTMI_PAGE",
                "MKT_UTMI_PART",
                "TRADE_POLICY",
                "MKT_CAMPAIGN_TAGS",
                "AFFILIATE_ID",
                "LAST_UPDATE_DATE",
                "INSERT_DATE",
                "COD_SALES_CHANNEL",
                CASE
                  WHEN "SUBSIDIARY_ID" = 3 AND "AFFILIATE_ID" = 'MLC'
                  THEN 'MERCADO LIBRE'
                  WHEN "SUBSIDIARY_ID" = 3
                  THEN "TRADE_POLICY"
                  WHEN "AFFILIATE_ID" IN ('MRC', 'MCL')
                  THEN 'MERCADO LIVRE'
                  WHEN "AFFILIATE_ID" IN ('SSG', 'SAMSUNG', 'SSP')
                  THEN 'SAMSUNG'
                  WHEN "AFFILIATE_ID" = 'BWW'
                  THEN 'B2W'
                  WHEN "AFFILIATE_ID" = 'VVJ'
                  THEN 'VIA VAREJO'
                  WHEN "AFFILIATE_ID" = 'VVT'
                  THEN 'VIVO'
                  WHEN "AFFILIATE_ID" = 'SNG'
                  THEN 'EPP B2B2C'
                  WHEN "AFFILIATE_ID" = 'SMG'
                  THEN 'EPP FUNCIONÁRIOS'
                  WHEN "AFFILIATE_ID" = 'CDR'
                  THEN 'CREDITAS'
                  WHEN "AFFILIATE_ID" = 'BNT'
                  THEN 'INTER'
                  WHEN "AFFILIATE_ID" = 'NVM'
                  THEN 'NOVO MUNDO'
                  WHEN "AFFILIATE_ID" = 'ZMM'
                  THEN 'ZOOM'
                  WHEN "AFFILIATE_ID" = 'PSG'
                  THEN 'PORTO'
                  WHEN "AFFILIATE_ID" IN ('SPV', 'SVC')
                  THEN 'SSG P/VC'
                  WHEN "AFFILIATE_ID" = 'CRF'
                  THEN 'CARREFOUR'
                  WHEN "AFFILIATE_ID" = 'PLC'
                  THEN 'OI'
                  WHEN "AFFILIATE_ID" = 'DDV'
                  THEN 'INDEVA'
                  WHEN "AFFILIATE_ID" = 'MGZ'
                  THEN 'MAGALU'
                  WHEN "AFFILIATE_ID" = 'RDT'
                  THEN 'RICARDO'
                  WHEN "AFFILIATE_ID" = 'HTG'
                  THEN 'HOMETOGO'
                  WHEN "AFFILIATE_ID" = 'BCR'
                  THEN 'BALCAO RURAL'
                  WHEN "AFFILIATE_ID" = 'LTM'
                  THEN 'IUPP/ITAU'
                  WHEN "AFFILIATE_ID" = 'KBM'
                  THEN 'KABUM'
                  WHEN "AFFILIATE_ID" = 'CLR'
                  THEN 'CLARO'
                  WHEN "AFFILIATE_ID" = 'NTS'
                  THEN 'NETSHOES'
                  WHEN "AFFILIATE_ID" = 'SMS'
                  THEN 'C.CERTA'
                  WHEN "AFFILIATE_ID" = 'LRM'
                  THEN 'L.MERLIN'
                  WHEN "AFFILIATE_ID" = 'SSC'
                  THEN 'SSG ITAUCARD'
                  ELSE "AFFILIATE_ID"
                END AS "Channel"
              FROM "U_PRJ_ECOM".FT_ECOM_ORDER
            ) AS input_0
            INNER JOIN (
              SELECT
                "ORDER_ID",
                "PRODUCT_NAME",
                "REFERENCE_CODE",
                "QUANTITY",
                "EAN",
                "DISCOUNT",
                "SHIPPING_ESTIMATE_DATE",
                "CARRIER",
                "PRICE",
                "SHIPPING_COST"
              FROM "U_PRJ_ECOM".FT_ECOM_ORDER_ITEM
            ) AS input_1
              ON input_0."ID" = input_1."ORDER_ID"
          ) AS input_0
          INNER JOIN (
            SELECT
              "ID",
              "SUBSIDIARY"
            FROM "U_PRJ_ECOM".DIM_SUBSIDIARY
          ) AS input_1
            ON input_0."SUBSIDIARY_ID" = input_1."ID"
        ) AS input_0
        INNER JOIN (
          SELECT
            "ID",
            "BIRTHDAY",
            "GENDER",
            "NAME",
            "OPT_IN",
            "SUBSIDIARY_ID",
            "CREATION_DATE"
          FROM "U_PRJ_ECOM".DIM_CUSTOMER
        ) AS input_1
          ON input_0."CUSTOMER_ID" = input_1."ID"
          AND input_0."SUBSIDIARY_ID" = input_1."SUBSIDIARY_ID"
      ) AS input_0
      LEFT OUTER JOIN (
        SELECT
          "SUBSIDIARY_ID",
          "REFERENCE_CURRENCY",
          "REFERENCE_DATE",
          "VALUE"
        FROM "U_PRJ_ECOM".DIM_EXCHANGE_RATE
      ) AS input_1
        ON input_0."CREATION_DATE" = input_1."REFERENCE_DATE"
        AND input_0."SUBSIDIARY_ID" = input_1."SUBSIDIARY_ID"
    ) AS input_0
    LEFT OUTER JOIN (
      SELECT
        "MARKET_NAME",
        "CATEGORY",
        "PRODUCT_GROUP",
        "SKU",
        "DIVISION",
        "FLAGSHIP",
        "FAMILY_GROUP"
      FROM "U_PRJ_ECOM".DIM_PRODUCT_CATEGORY
    ) AS input_1
      ON input_0."REFERENCE_CODE" = input_1."SKU"
  ) AS input_0
  LEFT OUTER JOIN (
    SELECT
      "REFERENCE_CODE",
      "ACTIVE",
      "IS_KIT",
      "SKU_ORIGIN",
      "SUBSIDIARY_ID"
    FROM "U_PRJ_ECOM".DIM_ECOM_SKU
  ) AS input_1
    ON input_0."REFERENCE_CODE" = input_1."REFERENCE_CODE"
    AND input_0."SUBSIDIARY_ID" = input_1."SUBSIDIARY_ID"
) AS Join_6