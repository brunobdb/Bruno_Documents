CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_CV_ECOM_INVENTORY_HISTORY_SELA" AS
SELECT
  "SUBSIDIARY",
  "PRODUCT_NAME",
  "SKU_NAME",
  "REFERENCE_CODE",
  "PRODUCT_ID",
  "SKU_ID",
  "IMG_URL",
  "DESCRIPTION",
  "ACTIVE",
  "FAMILY_ID",
  "COST_PRICE",
  "BASE_PRICE",
  "PHYSICAL_STOCK",
  "LOGICAL_STOCK",
  "HAS_UNLIMITED_STOCK",
  "IS_KIT",
  "SKU_ORIGIN",
  "SUBSIDIARY_ID",
  "PARENT_SKU",
  "LAST_UPDATE_DATE",
  "DELETED",
  "DELETED_AT",
  "SELLER_INSTANCE_ID",
  "IS_VISIBLE"
FROM (
  SELECT
    input_0."PRODUCT_NAME",
    input_0."SKU_NAME",
    input_0."REFERENCE_CODE",
    input_0."PRODUCT_ID",
    input_0."SKU_ID",
    input_0."IMG_URL",
    input_0."DESCRIPTION",
    input_0."ACTIVE",
    input_0."FAMILY_ID",
    input_0."COST_PRICE",
    input_0."BASE_PRICE",
    input_0."PHYSICAL_STOCK",
    input_0."LOGICAL_STOCK",
    input_0."HAS_UNLIMITED_STOCK",
    input_0."IS_KIT",
    input_0."SKU_ORIGIN",
    input_0."SUBSIDIARY_ID",
    input_0."PARENT_SKU",
    input_0."LAST_UPDATE_DATE",
    input_0."DELETED",
    input_0."DELETED_AT",
    input_0."SELLER_INSTANCE_ID",
    input_0."IS_VISIBLE",
    input_1."SUBSIDIARY"
  FROM (
    SELECT
      "PRODUCT_NAME",
      "SKU_NAME",
      "REFERENCE_CODE",
      "PRODUCT_ID",
      "SKU_ID",
      "IMG_URL",
      "DESCRIPTION",
      "ACTIVE",
      "FAMILY_ID",
      "COST_PRICE",
      "BASE_PRICE",
      "PHYSICAL_STOCK",
      "LOGICAL_STOCK",
      "HAS_UNLIMITED_STOCK",
      "IS_KIT",
      "SKU_ORIGIN",
      "PARENT_SKU",
      "SUBSIDIARY_ID",
      "LAST_UPDATE_DATE",
      "DELETED",
      "DELETED_AT",
      "SELLER_INSTANCE_ID",
      "IS_VISIBLE"
    FROM "U_PRJ_ECOM".DIM_ECOM_SKU
  ) AS input_0
  INNER JOIN (
    SELECT
      "ID",
      "SUBSIDIARY"
    FROM "U_PRJ_ECOM".DIM_SUBSIDIARY
  ) AS input_1
    ON input_0."SUBSIDIARY_ID" = input_1."ID"
) AS Join_1