CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_CV_ECOM_INVENTORY_HISTORY_NEW" AS
SELECT
  "IS_VISIBLE",
  "LAST_UPDATE_DATE",
  "SUBSIDIARY_ID",
  "SUBSIDIARY",
  "REFERENCE_CODE",
  "PRODUCT_NAME",
  "SKU_NAME",
  "FAMILY_ID",
  "SKU_ORIGIN",
  "IS_KIT",
  "PHYSICAL_STOCK",
  "LOGICAL_STOCK",
  "HAS_UNLIMITED_STOCK",
  "IMG_URL",
  "PRODUCT_ID",
  "SKU_ID",
  "ACTIVE",
  "DESCRIPTION",
  "DELETED",
  "DELETED_AT",
  "SELLER_INSTANCE_ID",
  "COST_PRICE",
  "BASE_PRICE"
FROM (
  SELECT
    "IS_VISIBLE",
    "LAST_UPDATE_DATE",
    "SUBSIDIARY_ID",
    "SUBSIDIARY",
    "REFERENCE_CODE",
    "PRODUCT_NAME",
    "SKU_NAME",
    "FAMILY_ID",
    "SKU_ORIGIN",
    "IS_KIT",
    "PHYSICAL_STOCK",
    "LOGICAL_STOCK",
    "HAS_UNLIMITED_STOCK",
    "IMG_URL",
    "PRODUCT_ID",
    "SKU_ID",
    "ACTIVE",
    "DESCRIPTION",
    "DELETED",
    "DELETED_AT",
    "SELLER_INSTANCE_ID",
    "COST_PRICE",
    "BASE_PRICE"
  FROM (
    SELECT
      input_0."IS_VISIBLE",
      input_0."LAST_UPDATE_DATE",
      input_0."SUBSIDIARY_ID",
      input_0."REFERENCE_CODE",
      input_0."PRODUCT_NAME",
      input_0."SKU_NAME",
      input_0."FAMILY_ID",
      input_0."SKU_ORIGIN",
      input_0."IS_KIT",
      input_0."PHYSICAL_STOCK",
      input_0."LOGICAL_STOCK",
      input_0."HAS_UNLIMITED_STOCK",
      input_0."IMG_URL",
      input_0."PRODUCT_ID",
      input_0."SKU_ID",
      input_0."ACTIVE",
      input_0."DESCRIPTION",
      input_0."DELETED",
      input_0."DELETED_AT",
      input_0."SELLER_INSTANCE_ID",
      input_0."COST_PRICE",
      input_0."BASE_PRICE",
      input_1."SUBSIDIARY"
    FROM (
      SELECT
        "REFERENCE_CODE",
        "PRODUCT_NAME",
        "SKU_NAME",
        "IMG_URL",
        "SKU_ID",
        "PRODUCT_ID",
        "FAMILY_ID",
        "SKU_ORIGIN",
        "IS_KIT",
        "HAS_UNLIMITED_STOCK",
        "LOGICAL_STOCK",
        "PHYSICAL_STOCK",
        "PARENT_SKU",
        "SUBSIDIARY_ID",
        "LAST_UPDATE_DATE",
        "IS_VISIBLE",
        "ACTIVE",
        "DESCRIPTION",
        "DELETED",
        "DELETED_AT",
        "SELLER_INSTANCE_ID",
        "COST_PRICE",
        "BASE_PRICE"
      FROM "U_PRJ_ECOM".DIM_ECOM_SKU
    ) AS input_0
    INNER JOIN (
      SELECT
        "ID",
        "SUBSIDIARY"
      FROM "U_PRJ_ECOM".DIM_SUBSIDIARY
    ) AS input_1
      ON input_0."SUBSIDIARY_ID" = input_1."ID"
  ) AS Join_1
  UNION ALL
  SELECT
    "IS_VISIBLE",
    "LAST_UPDATE_DATE",
    "SUBSIDIARY_ID",
    "SUBSIDIARY",
    "REFERENCE_CODE",
    "PRODUCT_NAME",
    "SKU_NAME",
    "FAMILY_ID",
    "SKU_ORIGIN",
    "IS_KIT",
    "PHYSICAL_STOCK",
    "LOGICAL_STOCK",
    "HAS_UNLIMITED_STOCK",
    "IMG_URL",
    "PRODUCT_ID",
    "SKU_ID",
    "ACTIVE",
    "DESCRIPTION",
    "DELETED",
    "DELETED_AT",
    "SELLER_INSTANCE_ID",
    "COST_PRICE",
    "BASE_PRICE"
  FROM (
    SELECT
      input_0."SUBSIDIARY",
      input_1."REFERENCE_CODE",
      input_1."PRODUCT_NAME",
      input_1."SKU_NAME",
      input_1."IMG_URL",
      input_1."SKU_ID",
      input_1."PRODUCT_ID",
      input_1."FAMILY_ID",
      input_1."SKU_ORIGIN",
      input_1."IS_KIT",
      input_1."HAS_UNLIMITED_STOCK",
      input_1."LOGICAL_STOCK",
      input_1."PHYSICAL_STOCK",
      input_1."SUBSIDIARY_ID",
      input_1."LAST_UPDATE_DATE",
      input_1."IS_VISIBLE",
      input_1."ACTIVE",
      input_1."DESCRIPTION",
      input_1."DELETED",
      input_1."DELETED_AT",
      input_1."SELLER_INSTANCE_ID",
      input_1."COST_PRICE",
      input_1."BASE_PRICE"
    FROM (
      SELECT
        "ID",
        "SUBSIDIARY"
      FROM "U_PRJ_ECOM".DIM_SUBSIDIARY
    ) AS input_0
    INNER JOIN (
      SELECT
        "PRODUCT_NAME",
        "SKU_NAME",
        "REFERENCE_CODE",
        "PRODUCT_ID",
        "SKU_ID",
        "IMG_URL",
        "DESCRIPTION",
        "ACTIVE",
        "FAMILY_ID",
        "COST_PRICE",
        "BASE_PRICE",
        "PHYSICAL_STOCK",
        "LOGICAL_STOCK",
        "HAS_UNLIMITED_STOCK",
        "IS_KIT",
        "SKU_ORIGIN",
        "PARENT_SKU",
        "SUBSIDIARY_ID",
        "LAST_UPDATE_DATE",
        "DELETED",
        "DELETED_AT",
        "SELLER_INSTANCE_ID",
        "IS_VISIBLE"
      FROM "OW_SEDA_S".DIM_ECOM_SKU
    ) AS input_1
      ON input_0."ID" = input_1."SUBSIDIARY_ID"
  ) AS Join_2
) AS Union_1