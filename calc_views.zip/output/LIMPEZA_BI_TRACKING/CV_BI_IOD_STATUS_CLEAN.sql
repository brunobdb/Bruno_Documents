CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_CV_BI_IOD_STATUS_CLEAN" AS
SELECT
  COALESCE(
    CASE WHEN UPPER(epp.cod) = 'SVC' THEN 'Downgraded' ELSE epp.cod END,
    'Regular Sales'
  ) AS sales_category,
  LISTAGG(ace.value USING PARAMETERS separator=', ') WITHIN GROUP (ORDER BY iod."G/I DATE") AS value,
  LISTAGG(ace.category USING PARAMETERS separator=', ') WITHIN GROUP (ORDER BY iod."G/I DATE") AS category,
  iod."LAST CARRIER NAME" AS Last_Carrier_Name,
  iod."G/I DATE" AS G_I_DATE,
  iod."REQUEST DATE" AS Request_Date,
  LISTAGG(iod."MATERIAL CODE" USING PARAMETERS separator=', ') WITHIN GROUP (ORDER BY iod."G/I DATE") AS Material_Code,
  iod."NF NO.(INT)" AS NF_No_Int,
  iod."LAST IOD REGISTRATION" AS Last_IOD_Registration,
  iod."SHIPPING TYPE" AS Shipping_Type,
  iod."DEPARTURE DATE" AS Departure_Date,
  iod."FOLLOW UP NAME" AS Follow_Up_Name,
  LISTAGG(iod."ITEM" USING PARAMETERS separator=', ') WITHIN GROUP (ORDER BY iod."G/I DATE") AS "ITEM",
  iod."DELAY DAYS(1ST BOOK)" AS Delay_Days_1_Book,
  iod."NOTE",
  iod."BOOKING TYPE" AS Booking_Type,
  iod."MANIFEST NO." AS Manifest_No,
  iod."FIRST ARRIVAL DATE" AS First_Arrival_Date,
  iod."UPDATED BY" AS Updated_By,
  iod."ITEM GROUP" AS Item_Group,
  iod."RANGE (1ST BOOK)" AS Range_1st_Book,
  iod."CONTAINER",
  iod."SOLD-TO PARTY CODE" AS Sold_to_Party_Code,
  iod."SHIPMENT NO." AS Shipment_No,
  iod."LAST ARRIVAL DATE" AS Last_Arrival_Date,
  iod."UPDATED ON" AS Updated_On,
  SUM(
    CASE
      WHEN TRIM(iod."CATEGORY") = 'Health&Medical' OR TRIM(iod."CATEGORY") = 'Computer'
      THEN iod."QUANTITY"
      ELSE iod."QUANTITY"
    END
  ) AS "QUANTITY",
  iod."DELAY DAYS(LAST BOOK)" AS Delay_Days_Last_Book,
  iod."SOLD-TO PARTY" AS Sold_to_Party,
  CASE
    WHEN UPPER(epp.cod) = 'SVC'
    THEN iod."DO NO." + iod."MATERIAL CODE"
    WHEN UPPER(epp.cod) = 'EPP' AND d.qt > 1
    THEN iod."DO NO." + iod."MATERIAL CODE"
    ELSE iod."DO NO."
  END AS "DO_NO",
  iod."1ST IOD REGISTRATION" AS "1ST_IOD_REGISTRATION",
  iod."RETURN DO" AS Return_DO,
  SUM(
    CASE
      WHEN TRIM(iod."CATEGORY") = 'AC : AirConditioner'
      THEN iod."ITEM AMT"
      WHEN TRIM(iod."CATEGORY") = 'Health&Medical' OR TRIM(iod."CATEGORY") = 'Computer'
      THEN iod."ITEM AMT"
      WHEN UPPER(epp.cod) = 'EPP'
      THEN iod."ITEM AMT" / d.qt
      ELSE iod."ITEM AMT"
    END
  ) AS "ITEM_AMT",
  iod."RANGE (LAST BOOK)" AS Range_Last_Book,
  iod."SHIP-TO PARTY CODE" AS Ship_to_Party_Code,
  iod."ORDER STATUS" AS Order_Status,
  iod."IOD DATE" AS IOD_Date,
  iod."G/R DATE" AS G_R_Date,
  iod."CARRIER CODE" AS Carrier_Code,
  iod."DELAY DAYS(GI+LT)" AS Delay_Days_GI_LT,
  iod."SHIP-TO PARTY" AS Ship_to_Party,
  iod."BOOKING STATUS" AS Booking_Status,
  iod."1ST BOOKING DATE" AS "1ST_BOOKING_DATE",
  iod."GR QUANTITY" AS GR_Quantity,
  iod."CARRIER",
  iod."RANGE (GI + LT)" AS Range_GI_LT,
  iod."CITY",
  iod."LAST RECEIVED OCCUR." AS Last_Received_Occur,
  iod."COMMON DIVISION" AS Common_Division,
  iod."LAST BOOKING DATE" AS Last_Booking_Date,
  iod."RET GR NF AMT" AS Ret_GR_NF_Amt,
  COALESCE(iod."SUB CARRIER CODE", iod."CARRIER CODE") AS "SUB_CARRIER_CODE",
  iod."STANDARD LEAD TIME MASTER" AS Standard_Lead_Time_Master,
  iod."STATE",
  iod."RESPONSIBLE_2",
  iod."DIVISION",
  iod."TSS ETA" AS TSS_ETA,
  iod."CUSTOMER PO" AS Customer_PO,
  COALESCE(iod."SUB CARRIER", iod."CARRIER") AS "SUB_CARRIER",
  iod."LAST VALID OCCUR." AS Last_Valid_Occur,
  iod."PLANNED TRUCK TYPE" AS Planned_Truck_Type,
  iod."OCCURRENCE",
  iod."CATEGORY" AS "DIVISION_NAME",
  iod."NF SERIES" AS NF_Series,
  iod."3PL FINAL ETA" AS "3PL_FINAL_ETA",
  iod."LAST CARRIER CODE" AS Last_Carrier_Code,
  iod."RESPONSIBLE",
  iod."ETD",
  iod."OCCURRENCE_2",
  iod."SOURCE CODE" AS Source_Code,
  iod."NF NO." AS NF_No,
  iod."PRE-BOOKING DATE" AS Pre_Booking_Date,
  CASE WHEN UPPER(iod."ITEM") LIKE '%BAT%' THEN 'Battery' ELSE 'Non-Battery' END AS Battery,
  CASE
    WHEN UPPER(iod."ITEM") LIKE '%BUDS%'
    OR UPPER(iod."ITEM") LIKE '%GEAR%'
    OR UPPER(iod."ITEM") LIKE '%WATCH%'
    OR UPPER(iod."ITEM") LIKE '%FIT%'
    OR UPPER(iod."ITEM") LIKE '%ICONX%'
    THEN 'Wearables'
    ELSE 'Non-Wearables'
  END AS Wearables
FROM VW_BI_IOD_TOTAL AS iod
INNER JOIN (
  SELECT
    "DO NO.",
    COUNT(1) AS qt
  FROM OW_SEDA_S.VW_BI_IOD_TOTAL
  GROUP BY
    "DO NO."
) AS d
  ON iod."DO NO." = d."DO NO."
LEFT JOIN MAP_APOIO_EPP AS epp
  ON RIGHT('0000000000' || iod."SOLD-TO PARTY CODE", 10) = RIGHT('0000000000' || epp."EPP_SOLDS", 10)
LEFT JOIN MAP_APOIO_ACESSORY AS ace
  ON LEFT((iod."MATERIAL CODE")::VARCHAR, 3) = ace.value
GROUP BY
  UPPER(epp.cod),
  COALESCE(
    CASE WHEN UPPER(epp.cod) = 'SVC' THEN 'Downgraded' ELSE epp.cod END,
    'Regular Sales'
  ),
  iod."LAST CARRIER NAME",
  iod."G/I DATE",
  iod."REQUEST DATE",
  iod."NF NO.(INT)",
  iod."LAST IOD REGISTRATION",
  iod."SHIPPING TYPE",
  iod."DEPARTURE DATE",
  iod."FOLLOW UP NAME",
  iod."DELAY DAYS(1ST BOOK)",
  iod."NOTE",
  iod."BOOKING TYPE",
  iod."MANIFEST NO.",
  iod."FIRST ARRIVAL DATE",
  iod."UPDATED BY",
  iod."ITEM GROUP",
  iod."RANGE (1ST BOOK)",
  iod."CONTAINER",
  iod."SOLD-TO PARTY CODE",
  iod."SHIPMENT NO.",
  iod."LAST ARRIVAL DATE",
  iod."UPDATED ON",
  iod."QUANTITY",
  iod."DELAY DAYS(LAST BOOK)",
  iod."SOLD-TO PARTY",
  CASE
    WHEN UPPER(epp.cod) = 'SVC'
    THEN iod."DO NO." + iod."MATERIAL CODE"
    WHEN UPPER(epp.cod) = 'EPP' AND d.qt > 1
    THEN iod."DO NO." + iod."MATERIAL CODE"
    ELSE iod."DO NO."
  END,
  iod."1ST IOD REGISTRATION",
  iod."RETURN DO",
  iod."ITEM AMT",
  iod."RANGE (LAST BOOK)",
  iod."SHIP-TO PARTY CODE",
  iod."ORDER STATUS",
  iod."IOD DATE",
  iod."G/R DATE",
  iod."CARRIER CODE",
  iod."DELAY DAYS(GI+LT)",
  iod."SHIP-TO PARTY",
  iod."BOOKING STATUS",
  iod."1ST BOOKING DATE",
  iod."GR QUANTITY",
  iod."CARRIER",
  iod."RANGE (GI + LT)",
  iod."CITY",
  iod."LAST RECEIVED OCCUR.",
  iod."COMMON DIVISION",
  iod."LAST BOOKING DATE",
  iod."RET GR NF AMT",
  COALESCE(iod."SUB CARRIER CODE", iod."CARRIER CODE"),
  iod."STANDARD LEAD TIME MASTER",
  iod."STATE",
  iod."RESPONSIBLE_2",
  iod."DIVISION",
  iod."TSS ETA",
  iod."CUSTOMER PO",
  COALESCE(iod."SUB CARRIER", iod."CARRIER"),
  iod."LAST VALID OCCUR.",
  iod."PLANNED TRUCK TYPE",
  iod."OCCURRENCE",
  iod."CATEGORY",
  iod."NF SERIES",
  iod."3PL FINAL ETA",
  iod."LAST CARRIER CODE",
  iod."RESPONSIBLE",
  iod."ETD",
  iod."OCCURRENCE_2",
  iod."SOURCE CODE",
  iod."NF NO.",
  iod."PRE-BOOKING DATE",
  CASE WHEN UPPER(iod."ITEM") LIKE '%BAT%' THEN 'Battery' ELSE 'Non-Battery' END,
  CASE
    WHEN UPPER(iod."ITEM") LIKE '%BUDS%'
    OR UPPER(iod."ITEM") LIKE '%GEAR%'
    OR UPPER(iod."ITEM") LIKE '%WATCH%'
    OR UPPER(iod."ITEM") LIKE '%FIT%'
    OR UPPER(iod."ITEM") LIKE '%ICONX%'
    THEN 'Wearables'
    ELSE 'Non-Wearables'
  END,
  d.qt