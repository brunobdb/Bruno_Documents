CREATE OR REPLACE VIEW "OW_SEDA_S"."VIEWCV_CV_CELLO_TRACKING_IOD" AS
SELECT
  "Manifest_No_",
  "Shipment_No_",
  "DO_No_",
  "Order_Status",
  "Booking_Status",
  "Common_Division",
  "Division",
  "Source_Code",
  "Material_Code",
  "Item",
  "Item_Group",
  "Quantity",
  "Item_Amt",
  "Carrier_Code",
  "Carrier",
  "Sub_Carrier_Code",
  "Sub_Carrier",
  "Last_Carrier_Code",
  "Last_Carrier_Name",
  "Shipping_Type",
  "Booking_Type",
  "Sold-to_Party_Code",
  "Sold-to_Party",
  "Ship-to_Party_Code",
  "Ship-to_Party",
  "City",
  "State",
  "Planned_Truck_Type",
  "NF_Series",
  "NF_No_",
  "NF_No_(Int)",
  "Delay_Days_1st_Book",
  "Range_(1st_Book)",
  "Delay_Days_Last_Book",
  "Range_(Last_Book)",
  "Delay_Days_GI+LT",
  "Range_(GI_+_LT)",
  "Standard_Lead_Time_Master",
  "Last_Valid_Occur_",
  "Responsible",
  "Last_Received_Occur_",
  "Responsible_2",
  "Occurrence",
  "Occurrence_2",
  "Request_Date",
  "Follow_Up_Name",
  "Updated_By",
  "Updated_On",
  "Return_DO",
  "G_R_Date",
  "GR_Quantity",
  "Ret_GR_NF_Amt",
  "Customer_PO",
  "3PL_Final_ETA",
  "Pre-Booking_Date",
  "Note",
  "Container",
  "Source_System",
  "Division_Name1" AS "Division_Name",
  "GI_I_DATE",
  "Departure_Date1" AS "Departure_Date",
  "First_Arrival_Date1" AS "First_Arrival_Date",
  "ETD_1" AS "ETD",
  "TSS_ETA1" AS "TSS_ETA",
  "Last_Booking_Date1" AS "Last_Booking_Date",
  "1st_Booking_Date1" AS "1st_Booking_Date",
  "Last_Arrival_Date_1" AS "Last_Arrival_Date",
  "Last_IOD_Registration_1" AS "Last_IOD_Registration",
  "1st_IOD_Registration_1" AS "1st_IOD_Registration",
  "IOD_Date_1" AS "IOD_Date"
FROM (
  SELECT
    "Manifest_No." AS "Manifest_No_",
    "Shipment_No." AS "Shipment_No_",
    "DO_No." AS "DO_No_",
    "Order_Status" AS "Order_Status",
    "Booking_Status" AS "Booking_Status",
    "Common_Division" AS "Common_Division",
    "Division",
    "Division_Name" AS "Division_Name",
    "Source_Code" AS "Source_Code",
    "Material_Code" AS "Material_Code",
    "Item",
    "Item_Group" AS "Item_Group",
    "Quantity",
    "Item_Amt" AS "Item_Amt",
    "Carrier_Code" AS "Carrier_Code",
    "Carrier",
    "Sub_Carrier_Code" AS "Sub_Carrier_Code",
    "Sub_Carrier" AS "Sub_Carrier",
    "Last_Carrier_Code" AS "Last_Carrier_Code",
    "Last_Carrier_Name" AS "Last_Carrier_Name",
    "Shipping_Type" AS "Shipping_Type",
    "Booking_Type" AS "Booking_Type",
    "Sold-to_Party_Code" AS "Sold-to_Party_Code",
    "Sold-to_Party" AS "Sold-to_Party",
    "Ship-to_Party_Code" AS "Ship-to_Party_Code",
    "Ship-to_Party" AS "Ship-to_Party",
    "City",
    "State",
    "Planned_Truck_Type" AS "Planned_Truck_Type",
    "ETD",
    "G_I_Date" AS "G_I_Date",
    "Departure_Date" AS "Departure_Date",
    "First_Arrival_Date" AS "First_Arrival_Date",
    "Last_Arrival_Date" AS "Last_Arrival_Date",
    "1st_IOD_Registration" AS "1st_IOD_Registration",
    "IOD_Date" AS "IOD_Date",
    "1st_Booking_Date" AS "1st_Booking_Date",
    "Last_Booking_Date" AS "Last_Booking_Date",
    "TSS_ETA" AS "TSS_ETA",
    "NF_Series" AS "NF_Series",
    "NF_No." AS "NF_No_",
    "NF No._Int" AS "NF_No_(Int)",
    "Delay Days_1st_Book" AS "Delay_Days_1st_Book",
    "Range_(1st_Book)" AS "Range_(1st_Book)",
    "Delay Days_Last_Book" AS "Delay_Days_Last_Book",
    "Range_(Last_Book)" AS "Range_(Last_Book)",
    "Delay Days_GI+LT" AS "Delay_Days_GI+LT",
    "Range_(GI_+_LT)" AS "Range_(GI_+_LT)",
    "Standard_Lead_Time_Master" AS "Standard_Lead_Time_Master",
    "Last_Valid_Occur." AS "Last_Valid_Occur_",
    "Responsible",
    "Last_Received_Occur." AS "Last_Received_Occur_",
    "Responsible_2",
    "Occurrence",
    "Occurrence_2",
    "Request_Date" AS "Request_Date",
    "Follow_Up_Name" AS "Follow_Up_Name",
    "Updated_By" AS "Updated_By",
    "Updated_On" AS "Updated_On",
    "Return_DO" AS "Return_DO",
    "G_R_Date" AS "G_R_Date",
    "GR_Quantity" AS "GR_Quantity",
    "Ret_GR_NF_Amt" AS "Ret_GR_NF_Amt",
    "Customer_PO" AS "Customer_PO",
    "3PL_Final_ETA" AS "3PL_Final_ETA",
    "Pre-Booking_Date" AS "Pre-Booking_Date",
    "Last_IOD_Registration" AS "Last_IOD_Registration",
    "Note",
    "Container",
    "Source_System",
    CASE
      WHEN "Division_Name" = 'CTV'
      THEN 'CTV : Color TV'
      WHEN "Division_Name" = 'DVC'
      THEN 'DVC : Digtl.VideoCam'
      WHEN "Division_Name" = 'HV'
      THEN 'HV : BD/DVDP'
      WHEN "Division_Name" = 'HA'
      THEN 'HA : HTS'
      WHEN "Division_Name" = 'STB'
      THEN 'STB : Set-Top Box'
      WHEN "Division_Name" = 'AC'
      THEN 'AC : AirConditioner'
      WHEN "Division_Name" = 'REF'
      THEN 'REF : Refrigerator '
      WHEN "Division_Name" = 'WM'
      THEN 'WM : WashingMachine'
      WHEN "Division_Name" = 'VC'
      THEN 'VC : VacuumCleaner'
      WHEN "Division_Name" = 'MWO'
      THEN 'MWO : MicroWaveOven'
      WHEN "Division_Name" = 'SmartHome & LED Lamp'
      THEN 'ACC'
      WHEN "Division_Name" = 'Enterprise'
      THEN 'Internet Infra'
      WHEN "Division_Name" = 'HDD'
      THEN 'HDD : HardDisKDrive'
      WHEN "Division_Name" = 'ODD'
      THEN 'ODD : Opt.DiscDrive'
      WHEN "Division_Name" = 'DSC:Digital StillCam'
      THEN 'DSC : DigitalStl.Cam'
      ELSE "Division_Name"
    END AS "Division_Name1",
    TO_DATE(("ETD")::VARCHAR, 'YYYY-MM-DD') AS "ETD_1",
    TO_DATE(("G_I_Date")::VARCHAR, 'YYYY-MM-DD') AS "GI_I_DATE",
    TO_DATE(("Departure_Date")::VARCHAR, 'YYYY-MM-DD') AS "Departure_Date1",
    TO_DATE(("First_Arrival_Date")::VARCHAR, 'YYYY-MM-DD') AS "First_Arrival_Date1",
    TO_TIMESTAMP(("TSS_ETA")::VARCHAR, 'YYYYMMDDHH24MISS') AS "TSS_ETA1",
    TO_TIMESTAMP(("Last_Booking_Date")::VARCHAR, 'YYYYMMDDHH24MISS') AS "Last_Booking_Date1",
    TO_TIMESTAMP(("1st_Booking_Date")::VARCHAR, 'YYYYMMDDHH24MISS') AS "1st_Booking_Date1",
    TO_TIMESTAMP(("Last_Arrival_Date")::VARCHAR, 'YYYYMMDDHH24MISS') AS "Last_Arrival_Date_1",
    TO_TIMESTAMP(("Last_IOD_Registration")::VARCHAR, 'YYYYMMDDHH24MISS') AS "Last_IOD_Registration_1",
    TO_TIMESTAMP(("1st_IOD_Registration")::VARCHAR, 'YYYYMMDDHH24MISS') AS "1st_IOD_Registration_1",
    TO_DATE(("IOD_Date")::VARCHAR, 'YYYY-MM-DD') AS "IOD_Date_1"
  FROM "OW_SEDA_S".FT_CELLO_BI_TRACKING
) AS Projection_1